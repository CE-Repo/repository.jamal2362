# gronkh.tv plugin for Kodi

gronkhtv - ein KODI Plugin für gronkh.tv.

Git repo: https://github.com/jamal2362/plugin.video.gronkhtv

_Diese Website und das Addon gehören nicht zu Gronkh.tv oder stehen in irgendeiner Beziehung zu ihnen._


_Kodi® (früher bekannt als XBMC™) ist eine registrierte Marke (registered trademark) der XBMC Foundation.
Diese Website steht in keiner Beziehung zu Kodi, Team Kodi doer der XBMC Foundation._

_Kodi® (formerly known as XBMC™) is a registered trademark of the XBMC Foundation.
This website and addon is not affiliated with Kodi, Team Kodi, or the XBMC Foundation._