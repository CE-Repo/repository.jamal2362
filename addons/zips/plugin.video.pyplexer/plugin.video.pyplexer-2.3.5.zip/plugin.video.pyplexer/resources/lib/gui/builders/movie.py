# -*- coding: utf-8 -*-

import datetime
import json

from core.constants import COMBINED_SECTIONS
from core.constants import CONFIG
from core.constants import MODES
from core.context import GUIItem
from core.logger import Logger
from core.strings import i18n
from gui.builders.common import get_clearlogo_image
from gui.builders.common import get_fanart_images
from gui.builders.common import get_landscape_image
from gui.builders.common import get_media_data
from gui.builders.common import get_metadata
from gui.builders.common import get_thumb_image
from gui.builders.common import is_watchlisted
from gui.context_menu import ContextMenu
from gui.list_item import create_gui_item

LOG = Logger()


def create_movie_item(context, item, library=False):
    metadata = get_metadata(context, item.data)
    LOG.debug('Media attributes are %s' % json.dumps(metadata['attributes'], indent=4))
    # Required listItem entries for Kodi

    try:
        date_added = str(datetime.datetime.fromtimestamp(int(item.data.get('addedAt', 86400))))
    except ValueError:
        # ValueError: timestamp out of range for platform localtime()/gmtime() function
        date_added = str(datetime.datetime.fromtimestamp(86400))

    info_labels = {
        'plot': item.data.get('summary', ''),
        'title': item.data.get('title', i18n('Unknown')),
        'sorttitle': item.data.get('titleSort',
                                   item.data.get('title', i18n('Unknown'))),
        'rating': float(item.data.get('rating', 0)),
        'studio': [item.data.get('studio', '')],
        'mpaa': item.data.get('contentRating', ''),
        'year': int(item.data.get('year', 0)),
        'date': item.data.get('originallyAvailableAt', '1970-01-01'),
        'premiered': item.data.get('originallyAvailableAt', '1970-01-01'),
        'tagline': item.data.get('tagline', ''),
        'dateadded': date_added,
        'mediatype': 'movie',
        'playcount': int(int(item.data.get('viewCount', 0)) > 0),
        'cast': metadata['cast'],
        'director': metadata['director'],
        'genre': metadata['genre'],
        'set': ' / '.join(metadata['collections']),
        'writer': metadata['writer'],
    }

    prefix_server = (context.params.get('mode') in COMBINED_SECTIONS and
                     context.settings.prefix_server_in_combined() and
                     not context.params.get('no_server_prefix'))

    if prefix_server:
        info_labels['title'] = '%s: %s' % (item.server.get_name(), info_labels['title'])

    if item.data.get('primaryExtraKey') is not None:
        info_labels['trailer'] = 'plugin://' + CONFIG['id'] + '/?url=%s%s?mode=%s' % \
                                 (item.server.get_url_location(),
                                  item.data.get('primaryExtraKey', ''),
                                  MODES.PLAYLIBRARY)
        LOG.debug('Trailer plugin url added: %s' % info_labels['trailer'])

    # Gather some data
    view_offset = item.data.get('viewOffset', 0)
    duration = int(metadata['attributes'].get('duration', item.data.get('duration', 0))) / 1000

    # Extra data required to manage other properties
    fanart_images = get_fanart_images(context, item.server, item.data)
    extra_data = {
        'type': 'Video',
        'source': 'movies',
        'thumb': get_thumb_image(context, item.server, item.data),
        'fanart_image': fanart_images[0] if fanart_images else '',
        'fanart_images': fanart_images,
        'landscape': get_landscape_image(context, item.data),
        'clearlogo': get_clearlogo_image(context, item.server, item.data),
        'key': item.data.get('key', ''),
        'ratingKey': str(item.data.get('ratingKey', 0)),
        'guid': item.data.get('guid', ''),
        'watchlisted': is_watchlisted(context, item.data),
        'duration': duration,
        'resume': int(int(view_offset) / 1000)
    }

    if item.up_next is False:
        extra_data['parameters'] = {
            'up_next': str(item.up_next).lower()
        }

    if item.tree.get('playlistType'):
        playlist_key = str(item.tree.get('ratingKey', 0))
        if item.data.get('playlistItemID') and playlist_key:
            extra_data.update({
                'playlist_item_id': item.data.get('playlistItemID'),
                'playlist_title': item.tree.get('title'),
                'playlist_url': '/playlists/%s/items' % playlist_key
            })

    if item.tree.tag == 'MediaContainer':
        extra_data.update({
            'library_section_uuid': item.tree.get('librarySectionUUID')
        })

    # Add extra media flag data
    if not context.settings.skip_flags():
        extra_data.update(get_media_data(metadata['attributes'], metadata.get('media'),
                                         item.data,
                                         for_player=bool(context.params.get('player_labels'))))

    # Build any specific context menu entries
    context_menu = None
    if not context.settings.skip_context_menus():
        context_menu = ContextMenu(context, item.server, item.url, extra_data).menu

    # http:// <server> <path> &mode=<mode>
    extra_data['mode'] = MODES.PLAYLIBRARY
    if library:
        extra_data['path_mode'] = MODES.TXT_MOVIES_LIBRARY

    item_url = item.server.join_url(item.server.get_url_location(), extra_data['key'])

    gui_item = GUIItem(item_url, info_labels, extra_data, context_menu)
    gui_item.is_folder = False
    return create_gui_item(context, gui_item)
