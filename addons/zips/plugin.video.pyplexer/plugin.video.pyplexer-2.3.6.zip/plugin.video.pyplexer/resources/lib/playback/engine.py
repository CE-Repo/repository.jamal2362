# -*- coding: utf-8 -*-

from urllib.parse import unquote

import xbmc  # pylint: disable=import-error
import xbmcgui  # pylint: disable=import-error
import xbmcplugin  # pylint: disable=import-error
import xbmcvfs  # pylint: disable=import-error
from infotagger.listitem import ListItemInfoTag  # pylint: disable=import-error

from core.common import get_handle
from core.common import is_resuming_video
from core.constants import CONFIG
from core.constants import StreamControl
from core.context import Item
from core.logger import Logger
from core.strings import i18n
from core.utils import get_file_type
from core.utils import get_xml
from core.utils import write_pickled
from gui.builders.common import get_banner_image
from gui.builders.common import get_fanart_image
from gui.builders.common import get_thumb_image
from gui.builders.track import create_track_item
from playback.quality import CANCELLED
from playback.quality import QualitySearch
from playback.quality import describe
from playback.quality import media_details
from playback.quality import part_index_for_media

LOG = Logger()


def monitor_channel_transcode_playback(context, server, session_id):
    # Logic may appear backward, but this does allow for a failed start to be detected
    # First while loop waiting for start
    if context.settings.playback_monitor_disabled():
        return

    count = 0
    monitor = xbmc.Monitor()
    player = xbmc.Player()

    LOG.debug('Not playing yet...sleeping for up to 20 seconds at 2 second intervals')
    while not player.isPlaying() and not monitor.abortRequested():
        count += 1
        if count >= 10:
            # Waited 20 seconds and still no movie playing - assume it isn't going to..
            return
        if monitor.waitForAbort(2.0):
            return

    LOG.debug('Waiting for playback to finish')
    while player.isPlaying() and not monitor.abortRequested():
        if monitor.waitForAbort(0.5):
            break

    LOG.debug('Playback Stopped')
    LOG.debug('Stopping PMS transcode job with session: %s' % session_id)
    server.stop_transcode_session(session_id)


def play_media_id_from_uuid(context, data):
    server = context.plex_network.get_server_from_uuid(data['server_uuid'])
    data['url'] = server.get_formatted_url('/library/metadata/%s' % data['media_id'])
    play_library_media(context, data)


def _to_seconds(milliseconds, default=0):
    """Plex reports times in milliseconds, Kodi wants whole seconds."""
    try:
        return int(int(milliseconds) / 1000)
    except (TypeError, ValueError):
        return default


def play_library_media(context, data):
    up_next = True
    if '&upnext=false' in data['url']:
        up_next = False
        data['url'] = data['url'].replace('&upnext=false', '')

    server = context.plex_network.get_server_from_url(data['url'])
    media_id = data['url'].split('?')[0].split('&')[0].split('/')[-1]

    if 'includeMarkers' not in data['url']:
        data['url'] += '&' if '?' in data['url'] else '?'
        data['url'] += 'includeMarkers=1'

    tree = get_xml(context, data['url'])
    if tree is None:
        return

    stream = StreamData(context, server, tree).stream

    stream_data = stream.get('full_data', {})
    stream_media = stream.get('media', {})

    if data.get('force') and stream['type'] == 'music':
        play_playlist(context, server, stream)
        return

    if switch_to_better_quality(context, server, stream, data, media_id, up_next):
        return

    preferred_index = data.get('media_index')
    if preferred_index is not None:
        preferred_index = part_index_for_media(stream.get('details'), preferred_index)

    url = MediaSelect(context, server, stream, preferred_index=preferred_index).media_url

    if url is None:
        return

    transcode = is_transcode_required(context, stream.get('details'), data.get('transcode', False))
    try:
        transcode_profile = int(data.get('transcode_profile') or 0)
    except (TypeError, ValueError):
        transcode_profile = 0

    url, session = get_playback_url_and_session(server, url, stream, transcode, transcode_profile)

    details = {
        'resume': _to_seconds(stream_media.get('viewOffset')),
        'duration': _to_seconds(stream_media.get('duration')),
    }

    if isinstance(data.get('force'), int):
        details['resume'] = _to_seconds(data['force']) if data['force'] > 0 else data['force']

    details['resuming'] = is_resuming_video()

    LOG.debug('Resume has been set to %s' % details['resume'])

    list_item = create_playback_item(url, stream, stream_data, details)

    if stream['type'] in ['music', 'video']:
        server.settings = None  # can't pickle xbmcaddon.Addon()
        write_pickled('playback_monitor.pickle', {
            'details': details,
            'media_id': media_id,
            'playing_file': url,
            'session': session,
            'server': server,
            'stream': stream,
            'up_next': up_next,
            'callback_args': {
                'transcode': transcode,
                'transcode_profile': transcode_profile
            }
        })

    xbmcplugin.setResolvedUrl(get_handle(), True, list_item)

    set_now_playing_properties(server, media_id)


def switch_to_better_quality(context, server, stream, data, media_id, up_next):  # pylint: disable=too-many-positional-arguments
    """Look for a better version of this title before playback starts.

    A local pick is handed back through data['media_index'].  True means the
    caller has to stop: either playback was restarted for a copy held as its
    own item, or the viewer dismissed the dialog and nothing should play.
    """
    if stream['type'] != 'video' or data.get('quality_checked'):
        return False

    if not context.settings.quality_search():
        return False

    try:
        choice = QualitySearch(context, server, stream, media_id=media_id).run()
    except Exception as error:  # pylint: disable=broad-except
        LOG.debug('Search for a better quality failed: %s' % error)
        return False

    if choice is CANCELLED:
        LOG.debug('Version dialog dismissed, playback is not started')
        xbmcplugin.setResolvedUrl(get_handle(), False, xbmcgui.ListItem())
        return True

    if not choice:
        return False

    if (choice['server_uuid'] == server.get_uuid() and
            str(choice['media_id']) == str(media_id)):
        # another version of the very same item, MediaSelect can play it
        data['media_index'] = choice['media_index']
        return False

    # a copy held as its own item, either in another library here or on
    # another server; playback restarts for that item
    other_server = context.plex_network.get_server_from_uuid(choice['server_uuid'])
    url = other_server.get_formatted_url('/library/metadata/%s' % choice['media_id'])
    if not up_next:
        url += '&upnext=false' if '?' in url else '?upnext=false'

    force = data.get('force')
    if isinstance(force, bool):
        force = False

    LOG.debug('Playing the selected version from %s' % other_server.get_name())
    play_library_media(context, {
        'url': url,
        'force': force,
        'transcode': data.get('transcode', False),
        'transcode_profile': data.get('transcode_profile'),
        'media_index': choice['media_index'],
        'quality_checked': True,
    })
    return True


def create_playback_item(url, streams, data, details):
    if not data:
        data = {}

    stream_art = streams.get('art', {})

    list_item = xbmcgui.ListItem(path=url, offscreen=True)

    if data:
        fanart = stream_art.get('fanart', '')
        if not fanart:
            fanart = stream_art.get('section_art', '')

        thumb = stream_art.get('thumb', '')
        if not thumb:
            thumb = stream_art.get('section_art', '')
        if not thumb:
            thumb = stream_art.get('fanart', '')

        poster = ''
        if data.get('mediatype', '') == 'movie':
            poster = thumb
        elif data.get('mediatype', '') == 'episode':
            poster = stream_art.get('season_thumb', '')
            if not poster:
                poster = stream_art.get('show_thumb', '')

        list_item.setArt({
            'icon': thumb,
            'thumb': thumb,
            'poster': poster,
            'fanart': fanart,
            'banner': stream_art.get('banner')
        })

    info_tag = ListItemInfoTag(list_item, streams['type'])
    info_tag.set_info(data)
    time_dict = {
        'TotalTime': int(details['duration']),
    }
    if details.get('resuming') and details.get('resume'):
        time_dict['ResumeTime'] = int(details['resume'])
        data['playcount'] = '0'

        LOG.debug('Playback from resume point: %s' % details['resume'])

    info_tag.set_resume_point(time_dict)

    if streams['type'] == 'music':
        list_item.setProperty('culrc.source', i18n('Plex powered by LyricFind'))

    return list_item


def set_now_playing_properties(server, media_id):
    window = xbmcgui.Window(10000)
    window.setProperty('plugin.video.pyplexer-nowplaying.server', server.get_location())
    window.setProperty('plugin.video.pyplexer-nowplaying.id', media_id)


def get_playback_url_and_session(server, url, streams, transcode, transcode_profile):
    protocol = url.split(':', 1)[0]

    if protocol == 'file':
        LOG.debug('We are playing a local file')
        return url.split(':', 1)[1], None

    if protocol.startswith('http'):
        LOG.debug('We are playing a stream')
        if transcode:
            LOG.debug('We will be transcoding the stream')
            return server.get_universal_transcode(streams['extra']['path'],
                                                  transcode_profile=transcode_profile)

        return server.get_formatted_url(url), None

    return url, None


def is_transcode_required(context, stream_details, default=False):
    if context.settings.always_transcode():
        return True

    if not stream_details:
        return default

    codec = stream_details[0].get('codec')
    try:
        bit_depth = int(stream_details[0].get('bitDepth', 8))
    except (TypeError, ValueError):
        bit_depth = None

    try:
        height = int(stream_details[0].get('height') or 0)
    except (TypeError, ValueError):
        height = 0

    if codec and (context.settings.transcode_hevc() and codec.lower() == 'hevc'):
        return True
    if height > 1088 and context.settings.transcode_g1080():
        return True
    if bit_depth and (context.settings.transcode_g8bit() and bit_depth > 8):
        return True

    return default


class StreamData:

    def __init__(self, context, server, tree):
        self.context = context
        self.server = server
        self.tree = tree

        self._content = None

        self.data = {
            'contents': 'type',  # What type of data we are holding
            'audio': {},  # Audio data held in a dict
            'audio_count': 0,  # Number of audio streams
            'subtitle': {},  # Subtitle data (embedded) held as a dict
            'sub_count': 0,  # Number of subtitle streams
            'parts': [],  # The different media locations
            'parts_count': 0,  # Number of media locations
            'media': {},  # Resume/duration data for media
            'details': [],  # Bitrate, resolution and container for each part
            'sub_offset': -1,  # Stream index for selected subs
            'audio_offset': -1,  # Stream index for select audio
            'full_data': {},  # Full metadata extract if requested
            'type': 'video',  # Type of metadata
            'intro_markers': [],
            'extra': {},
        }

        self.update_data()

    def update_data(self):
        LOG.debug('Gathering stream info')

        if not self._get_content():
            return

        self.data['media']['viewOffset'] = self._content.get('viewOffset', 0)
        self.data['media']['duration'] = self._content.get('duration', 12 * 60 * 60)

        if self.data['type'] == 'video':
            self._get_video_data()

        if self.data['type'] == 'music':
            self._get_track_data()

        self._get_art()

        self._get_media_details()

        if (self.data['type'] == 'video' and
                self.context.settings.stream_control() == StreamControl().PLEX):
            self._get_audio_and_subtitles()
        else:
            LOG.debug('Stream selection is set OFF')

    @property
    def stream(self):
        LOG.debug(self.data)
        return self.data

    def _get_content(self):
        content = self.tree.find('Video')
        if content is not None:
            self.data['type'] = 'video'
            self.data['extra']['path'] = content.get('key')
            # used to find the same title on the other servers of the account
            self.data['extra']['guid'] = content.get('guid')
            # an episode is found through its show, and the guid of the show
            # holds up where a localised title does not
            self.data['extra']['show_guid'] = content.get('grandparentGuid')
            # which library the item is playing from, for the version dialog
            self.data['extra']['library'] = (content.get('librarySectionTitle') or
                                             self.tree.get('librarySectionTitle') or '')
            self._content = content
            return True

        content = self.tree.find('Track')
        if content is not None:
            self.data['type'] = 'music'
            self.data['extra']['path'] = content.get('key')
            self._content = content
            return True

        content = self.tree.find('Photo')
        if content is not None:
            self.data['type'] = 'picture'
            self.data['extra']['path'] = content.get('key')
            self._content = content
            return True

        LOG.debug('No content data found')
        self._content = None
        return False

    def _get_video_data(self):
        self.data['full_data'] = {
            'plot': self._content.get('summary', ''),
            'title': self._content.get('title', i18n('Unknown')),
            'sorttitle': self._content.get('titleSort',
                                           self._content.get('title', i18n('Unknown'))),
            'rating': float(self._content.get('rating', 0)),
            'studio': [self._content.get('studio', '')],
            'mpaa': self._content.get('contentRating', ''),
            'year': int(self._content.get('year', 0)),
            'tagline': self._content.get('tagline', ''),
            'mediatype': 'video'
        }

        if self._content.get('type') == 'movie':
            self.data['full_data']['mediatype'] = 'movie'
        elif self._content.get('type') == 'episode':
            self.data['full_data']['episode'] = int(self._content.get('index', 0))
            self.data['full_data']['aired'] = self._content.get('originallyAvailableAt', '')
            self.data['full_data']['tvshowtitle'] = \
                self._content.get('grandparentTitle', self.tree.get('grandparentTitle', ''))
            self.data['full_data']['season'] = int(
                self._content.get('parentIndex', self.tree.get('parentIndex', 0))
            )
            self.data['full_data']['mediatype'] = 'episode'

        if not self.context.settings.skip_metadata():
            tree_genres = self._content.findall('Genre')
            if tree_genres is not None:
                self.data['full_data']['genre'] = \
                    list(map(lambda x: x.get('tag', ''), tree_genres))

        self.data['intro_markers'] = self._get_intro_markers()

    def _get_track_data(self):

        track_title = '%s. %s' % \
                      (str(self._content.get('index', 0)).zfill(2),
                       self._content.get('title', i18n('Unknown')))
        lyrics = self._get_lyrics()

        self.data['full_data'] = {
            'TrackNumber': int(self._content.get('index', 0)),
            'discnumber': int(self._content.get('parentIndex', 0)),
            'title': track_title,
            'rating': float(self._content.get('rating', 0)),
            'album': self._content.get('parentTitle', self.tree.get('parentTitle', '')),
            'artist': self._content.get('grandparentTitle',
                                        self.tree.get('grandparentTitle', '')),
            'duration': int(self._content.get('duration', 0)) / 1000,
            'lyrics': lyrics,
        }

        self.data['extra']['album'] = self._content.get('parentKey')
        self.data['extra']['index'] = self._content.get('index')

    def _get_intro_markers(self):
        for marker in self._content.iter('Marker'):
            if (marker.get('type') == 'intro' and
                    marker.get('startTimeOffset') and marker.get('endTimeOffset')):
                return [marker.get('startTimeOffset'), marker.get('endTimeOffset')]

        return []

    def _get_lyrics(self):
        lyrics = []

        lyric_priorities = self.context.settings.get_lyrics_priorities()
        if not lyric_priorities:
            return ''

        for stream in self._content.iter('Stream'):
            if (stream.get('provider') == 'com.plexapp.agents.lyricfind' and
                    stream.get('streamType') == '4'):
                lyric = {
                    'codec': stream.get('codec', ''),
                    'title': stream.get('displayTitle', ''),
                    'format': stream.get('format', ''),
                    'id': stream.get('id', ''),
                    'key': stream.get('key', ''),
                    'provider': stream.get('provider', 'com.plexapp.agents.lyricfind'),
                    'streamType': stream.get('streamType', '4'),
                }
                lyric['priority'] = lyric_priorities.get(lyric.get('codec', 'none'), 0)
                lyrics.append(lyric)

        if lyrics:
            lyrics = sorted(lyrics, key=lambda l: l['priority'], reverse=True)
            return self.server.get_lyrics(lyrics[0]['id'])

        return ''

    def _get_art(self):
        art = {
            'banner': '',
            'fanart': '',
            'season_thumb': '',
            'section_art': '',
            'show_thumb': '',
            'thumb': '',
        }

        if self.context.settings.skip_images():
            self.data['art'] = art
            return

        art.update({
            'banner': get_banner_image(self.context, self.server, self.tree),
            'fanart': get_fanart_image(self.context, self.server, self._content),
            'season_thumb': '',
            'section_art': get_fanart_image(self.context, self.server, self.tree),
            'show_thumb': '',
            'thumb': get_thumb_image(self.context, self.server, self._content),
        })

        if '/:/resources/show-fanart.jpg' in art['section_art']:
            art['section_art'] = art.get('fanart', '')

        if art['fanart'] == '':
            art['fanart'] = art.get('section_art', '')

        if (self._content.get('grandparentThumb', '') and
                '/:/resources/show.png' not in self._content.get('grandparentThumb', '')):
            art['show_thumb'] = \
                get_thumb_image(self.context, self.server, {
                    'thumb': self._content.get('grandparentThumb', '')
                })

        if (art.get('season_thumb', '') and
                '/:/resources/show.png' not in art.get('season_thumb', '')):
            art['season_thumb'] = get_thumb_image(self.context, self.server, {
                'thumb': art.get('season_thumb')
            })

        # get ALL SEASONS or TVSHOW thumb
        if (not art.get('season_thumb', '') and self._content.get('parentThumb', '') and
                '/:/resources/show.png' not in self._content.get('parentThumb', '')):
            art['season_thumb'] = \
                get_thumb_image(self.context, self.server, {
                    'thumb': self._content.get('parentThumb', '')
                })

        elif not art.get('season_thumb', '') and art['show_thumb']:
            art['season_thumb'] = art['show_thumb']

        self.data['art'] = art

    def _get_media_details(self):
        media = self._content.findall('Media')

        self.data['details'] = []
        self.data['parts'] = []
        self.data['parts_count'] = 0

        for details in media:

            # one shared details dict per Media, so the parts of a version stay
            # recognisable as belonging together
            version_details = media_details(details, self._content)

            parts = details.findall('Part')

            # Get the media locations (file and web) for later on
            append_parts = self.data['parts'].append
            append_details = self.data['details'].append
            for part in parts:
                append_parts((part.get('key'), part.get('file')))
                append_details(version_details)
                self.data['parts_count'] += 1

    def _get_audio_and_subtitles(self):
        default_to_forced = self.context.settings.default_forced_subtitles()

        audio_offset = 0
        sub_offset = 0

        self.data['contents'] = 'all'
        self.data['audio_count'] = 0
        self.data['sub_count'] = 0

        tags = self.tree.iter('Stream')

        forced_subtitle = False
        for bits in tags:
            stream = dict(bits.items())

            # Audio Streams
            if stream['streamType'] == '2':
                self.data['audio_count'] += 1
                audio_offset += 1
                if stream.get('selected') == '1':
                    LOG.debug('Found preferred audio id: %s ' % stream['id'])
                    self.data['audio'] = stream
                    self.data['audio_offset'] = audio_offset

            # Subtitle Streams
            elif stream['streamType'] == '3':

                if forced_subtitle:
                    continue

                if sub_offset == -1:
                    sub_offset = int(stream.get('index', -1))
                elif 0 < int(stream.get('index', -1)) < sub_offset:
                    sub_offset = int(stream.get('index', -1))

                forced_subtitle = stream.get('forced') == '1' and default_to_forced
                selected = stream.get('selected') == '1'

                if forced_subtitle or selected:
                    LOG.debug('Found %s subtitles id : %s ' %
                              ('preferred' if not forced_subtitle else 'forced', stream['id']))
                    self.data['sub_count'] += 1
                    self.data['subtitle'] = stream
                    if stream.get('key'):
                        self.data['subtitle']['key'] = self.server.get_formatted_url(stream['key'])
                    else:
                        self.data['sub_offset'] = int(stream.get('index')) - sub_offset


class MediaSelect:
    def __init__(self, context, server, data, preferred_index=None):  # pylint: disable=too-many-positional-arguments
        self.context = context
        self.server = server
        self.data = data
        self.preferred_index = preferred_index

        self.dvd_playback = False

        self._media_index = None
        self._media_url = None

        self.update_selection()

    def update_selection(self):
        self._select_media()
        self._get_media_url()

    @property
    def media_url(self):
        return self._media_url

    @media_url.setter
    def media_url(self, value):
        self._media_url = value

    def _select_media(self):
        force_dvd = self.context.settings.force_dvd()

        count = self.data['parts_count']
        options = self.data['parts']
        details = self.data['details']

        if not options:
            LOG.debug('No playable media parts found')
            self._media_index = None
            return

        if self.preferred_index is not None and 0 <= self.preferred_index < len(options):
            # the version has already been chosen, don't ask a second time
            LOG.debug('Using preselected media part %s' % self.preferred_index)
            selected = options[self.preferred_index]
            if force_dvd and any('.ifo' in (part or '').lower() for part in selected):
                self.dvd_playback = True

            self._media_index = self.preferred_index
            return

        if count > 1:

            dialog_options = []
            dvd_index = []
            append_dialog_options = dialog_options.append
            append_dvd_index = dvd_index.append
            index_count = 0
            for items in options:

                if items[1]:
                    name = items[1].split('/')[-1]
                else:
                    name = '%s - %s' % (items[0].split('.')[-1],
                                        describe(details[index_count]))

                if force_dvd and '.ifo' in name.lower():
                    LOG.debug('Found IFO DVD file in ' + name)
                    name = 'DVD Image'
                    append_dvd_index(index_count)

                append_dialog_options(name)
                index_count += 1

            LOG.debug('Create selection dialog box - we have a decision to make!')
            dialog = xbmcgui.Dialog()
            result = dialog.select(i18n('Select media to play'), dialog_options)

            if result == -1:  # dialog cancelled, nothing to play
                LOG.debug('Media selection cancelled')
                self._media_index = None
                return

            if result in dvd_index:
                LOG.debug('DVD Media selected')
                self.dvd_playback = True

            self._media_index = result

        else:
            # options[0] is a (key, file) tuple; the original ``'.ifo' in
            # options[0]`` tested tuple membership and so never matched
            if force_dvd and any('.ifo' in (part or '').lower() for part in options[0]):
                self.dvd_playback = True

            self._media_index = 0

    def _get_media_url(self):
        if self._media_index is None:
            self.media_url = None
            return

        stream = self.data['parts'][self._media_index][0]
        filename = self.data['parts'][self._media_index][1]

        if self._http(filename, stream):
            return

        file_type = get_file_type(filename)

        if self._auto(filename, file_type, stream):
            return

        if self._smb_afp(filename, file_type):
            return

        LOG.debug('No option detected, streaming is safest to choose')
        self.media_url = self.server.get_formatted_url(stream)

    def _http(self, filename, stream):
        if filename is None or self.context.settings.get_stream() == '1':  # http
            LOG.debug('Selecting stream')
            self.media_url = self.server.get_formatted_url(stream)
            return True

        return False

    def _auto(self, filename, file_type, stream):
        if self.context.settings.get_stream() == '0':  # auto
            # check if the file can be found locally
            if file_type in ['NIX', 'WIN']:
                LOG.debug('Checking for local file')
                if xbmcvfs.exists(filename):
                    LOG.debug('Local file exists')
                    self.media_url = 'file:%s' % filename
                    return True

            LOG.debug('No local file')
            if self.dvd_playback:
                LOG.debug('Forcing SMB for DVD playback')
                self.context.settings.set_stream('2')
            else:
                self.media_url = self.server.get_formatted_url(stream)
                return True

        return False

    def _smb_afp(self, filename, file_type):
        if self.context.settings.get_stream() in ['2', '3']:  # smb / AFP

            filename = unquote(filename)
            if self.context.settings.get_stream() == '2':
                protocol = 'smb'
            else:
                protocol = 'afp'

            LOG.debug('Selecting smb/unc')
            if file_type == 'UNC':
                self.media_url = '%s:%s' % (protocol, filename.replace('\\', '/'))
            else:
                # Might be OSX type, in which case, remove Volumes and replace with server
                server = self.server.get_location().split(':')[0]
                login_string = ''
                override_info = self.context.settings.override_info()

                if override_info.get('override'):
                    if override_info.get('ip_address'):
                        server = override_info.get('ip_address')
                        LOG.debug('Overriding server with: %s' % server)

                    if override_info.get('user_id'):
                        login_string = '%s:%s@' % (override_info.get('user_id'),
                                                   override_info.get('password'))
                        LOG.debug('Adding AFP/SMB login info for user: %s' %
                                  override_info.get('user_id'))

                if filename.find('Volumes') > 0:
                    self.media_url = '%s:/%s' % \
                                     (protocol, filename.replace('Volumes', login_string + server))
                else:
                    if file_type == 'WIN':
                        self.media_url = ('%s://%s%s/%s' %
                                          (protocol, login_string, server,
                                           filename[3:].replace('\\', '/')))
                    else:
                        # else assume its a file local to server available over smb/samba.
                        # Add server name to file path.
                        if override_info.get('override') and override_info.get('root'):
                            filename = self._strip_nas_root(filename, override_info.get('root'))
                        self.media_url = '%s://%s%s%s' % (protocol, login_string, server, filename)

            return self.media_url is not None

        return False

    @staticmethod
    def _strip_nas_root(filename, root):
        # Discard everything before the root folder so only the NAS-side
        # path (root onward) remains; server/share prefix is added by the caller.
        marker = '/' + root + '/'
        position = filename.find(marker)
        if position == -1:
            LOG.debug('NAS root override "%s" not found in path %s' % (root, filename))
            return filename

        LOG.debug('Altering path %s so root is: %s' % (filename, root))
        return filename[position:]


def play_playlist(context, server, data):
    LOG.debug('Creating new playlist')
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    playlist.clear()

    url = server.join_url(server.get_url_location(), data['extra'].get('album'), 'children')
    tree = get_xml(context, url)

    if tree is None:
        return

    track_tags = tree.findall('Track')
    add_to_playlist = playlist.add
    item_constructor = xbmcgui.ListItem

    for track in track_tags:
        LOG.debug('Adding playlist item')
        item = Item(server, None, tree, track)
        track = create_track_item(context, item, listing=False)
        url = track[0]
        details = track[1]
        list_item = item_constructor(details.get('title', i18n('Unknown')), offscreen=True)

        thumb = data['full_data'].get('thumbnail', CONFIG['icon'])
        if 'thumbnail' in data['full_data']:
            del data['full_data']['thumbnail']  # not a valid info label

        list_item.setArt({
            'icon': thumb,
            'thumb': thumb
        })
        info_tag = ListItemInfoTag(list_item, 'music')
        info_tag.set_info(details)
        add_to_playlist(url, list_item)

    index = int(data['extra'].get('index', 0)) - 1
    LOG.debug('Playlist complete.  Starting playback from track %s [playlist index %s] ' %
              (data['extra'].get('index', 0), index))
    xbmc.Player().playselected(index)
