# -*- coding: utf-8 -*-

import json
from copy import deepcopy
from urllib.parse import urlparse
from urllib.parse import urlunparse

import xbmc  # pylint: disable=import-error
import xbmcgui  # pylint: disable=import-error

from core.logger import Logger
from core.server_config import ServerConfigStore
from core.strings import i18n
from plex.network import Plex
from storage.data_cache import DATA_CACHE

LOG = Logger()
WINDOW = xbmcgui.Window(10000)


def run(context):
    manager = ServerManager(context)
    manager.run()


class ServerManager:

    def __init__(self, context):
        self._dialog = xbmcgui.Dialog()

        self.context = context
        self.context.plex_network = Plex(context.settings, load=True)

        self.servers = list(context.plex_network.get_server_list())
        self.master = context.settings.master_server()

        self.server_configs = ServerConfigStore()

        self.server = None
        self.server_config = None
        self.access_urls = None
        self.test_results = None

    def run(self):
        server_data = self._get_server_data()
        if not server_data.get('labels'):
            self._refresh()
            return

        server_labels = server_data.get('labels', [])
        server_test_results = server_data.get('test_results', [])

        chosen_server = self._dialog.select(i18n('Manage Servers'), server_labels)
        if chosen_server < 0:
            self._refresh()
            return

        self.server = self.servers[chosen_server]
        self.server_config = self.server_configs.get_config(self.server.get_uuid())
        self.access_urls = self.server_configs.access_urls(self.server.get_uuid())
        self.test_results = server_test_results[chosen_server]

        management_choices = self._management_choices()
        management_choice = self._dialog.select(i18n('Manage Servers'), management_choices)
        if management_choice < 0:
            self._refresh()
            return

        self._process_management(management_choice)

        self._refresh()

    def _get_server_data(self):
        display_list = []
        test_results = []
        append_server = display_list.append
        append_test = test_results.append

        for server in self.servers:
            name = server.get_name()
            log_status = server.get_status()
            status_label = i18n(log_status)

            if server.is_secure():
                log_secure = 'SSL'
                secure_label = i18n(log_secure)
            else:
                log_secure = 'Not Secure'
                secure_label = i18n(log_secure)

            # ``settings`` may contain xbmcaddon.Addon, which cannot be copied
            # or JSON-encoded. It is runtime state and provides no useful
            # information in the server diagnostics dump.
            device_dump = deepcopy({key: value for key, value in server.__dict__.items()
                                    if key != 'settings'})
            device_dump['token'] = 'XXXXXXXXXX'
            headers = device_dump.get('plex_identification_header')
            if isinstance(headers, dict):
                headers['X-Plex-Token'] = 'XXXXXXXXXX'
            if self.context.settings.privacy():
                if isinstance(headers, dict):
                    headers['X-Plex-User'] = 'XXXXXXX'

            LOG.debug('Device: %s [%s] [%s]' % (name, log_status, log_secure))
            LOG.debugplus('Full device dump [%s]' %
                          json.dumps(device_dump, indent=4, default=str))

            server_label = '%s [%s] [%s]' % (name, status_label, secure_label)
            if name == self.master:
                server_label = '[COLOR=lightgreen]%s[/COLOR]' % server_label

            append_server(server_label)
            append_test(device_dump.get('connection_test_results', []))

        return {
            'labels': display_list,
            'test_results': test_results,
        }

    def _management_choices(self):
        management_choices = []
        append_choice = management_choices.append

        if self.server.get_name() != self.master:
            append_choice(i18n('Set as Master'))

        append_choice(i18n('Connection Test Results'))

        if self.server_configs.ssl_certificate_verification(self.server.get_uuid()):
            append_choice('[COLOR=lightgreen]%s[/COLOR]' % i18n('Certificate Verification'))
        else:
            append_choice('[COLOR=orange]%s[/COLOR]' % i18n('Certificate Verification'))

        append_choice(i18n('Custom access urls'))

        return management_choices

    def _process_management(self, choice):
        if self.server.get_name() == self.master:
            choice += 1  # Choice 0 - 'Set as Master' not available on Master server

        if choice == 0:
            LOG.debug('Setting master server to: %s' % self.server.get_name())
            self.context.settings.set_master_server(self.server.get_name())

        elif choice == 1:
            self._show_connection_test()

        elif choice == 2:
            self._certificate_verification()

        elif choice == 3:
            self._custom_access_urls()

    def _certificate_verification(self):
        self.server_configs.toggle_certificate_verification(self.server.get_uuid())

    def _custom_access_urls(self):
        choices = []
        append_choice = choices.append

        append_choice(i18n('Add custom access url'))
        for url in self.access_urls:
            append_choice(url)

        choice = self._dialog.select(i18n('Custom access urls'), choices)
        if choice < 0:
            self._refresh()
            return

        if choice == 0:
            self._add_custom_access_url()
        else:
            self._modify_custom_access_url(choice - 1)  # shift index to compensate for 'add' choice

    def _add_custom_access_url(self, url_index=None):
        default = ''
        heading = i18n('Add custom access url')

        if url_index is not None:
            default = self.access_urls[url_index]
            heading = i18n('Edit custom access url')

        url = ''
        keyboard = xbmc.Keyboard(default, heading)
        keyboard.setHeading(heading)
        keyboard.doModal()
        if keyboard.isConfirmed():
            url = keyboard.getText()
            url = url.strip()

        if not url:
            return

        url = self._normalise_url(url)
        if not url:
            # silently dropping the input left the user with a url that never
            # showed up anywhere and no idea why
            self._dialog.ok(heading, '%s\n%s' % (i18n('Not a valid url'),
                                                 'http://192.168.0.10:32400/'))
            return

        self.server_configs.add_access_url(self.server.get_uuid(), url, url_index)
        self._refresh(clear_cache=True)
        WINDOW.setProperty('plugin.video.pyplexer-refresh.servers', 'true')

    def _modify_custom_access_url(self, url_index):
        choice = self._dialog.yesno(
            i18n('Custom access urls'),
            self.access_urls[url_index],
            nolabel=i18n('Delete'),
            yeslabel=i18n('Edit')
        )

        if choice:
            self._add_custom_access_url(url_index)
        else:
            self.server_configs.delete_access_url(self.server.get_uuid(), url_index)
            self._refresh(clear_cache=True)
            WINDOW.setProperty('plugin.video.pyplexer-refresh.servers', 'true')

    def _show_connection_test(self):
        addresses = []
        append_address = addresses.append
        for address in self.test_results:
            append_address('[COLOR %s]%s://%s/[/COLOR]' %
                           ('lightgreen' if address[3] else 'pink', address[1], address[2]))

        self._dialog.select(i18n('Connection Test Results'), addresses)

    @staticmethod
    def _normalise_url(url):
        """Return the url the connection test can use, or empty when unusable.

        A server is typed in as ``http://host:32400``, which has no path at
        all - demanding one rejected exactly the input everybody enters.  The
        path the requests are built on top of is filled in instead.
        """
        try:
            result = urlparse(url)
        except Exception:  # pylint: disable=broad-except
            return ''

        if not result.scheme or not result.netloc:
            return ''

        if result.scheme not in ('http', 'https'):
            return ''

        return urlunparse((result.scheme, result.netloc, result.path or '/',
                           '', '', ''))

    @staticmethod
    def _refresh(clear_cache=False):
        if clear_cache:
            DATA_CACHE.delete_cache(True)
        xbmc.executebuiltin('Container.Refresh')
