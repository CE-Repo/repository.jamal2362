# -*- coding: utf-8 -*-

import xbmcplugin  # pylint: disable=import-error

from core.common import get_handle
from core.constants import MODES
from core.context import GUIItem
from core.strings import i18n
from gui.list_item import create_gui_item
from plex.network import Plex
from processing.pagination import paginate_local_items


def run(context, url):
    context.plex_network = Plex(context.settings, load=True)
    server = context.plex_network.get_server_from_url(url)

    sections = server.get_sections()

    items = []
    for section in sections:
        if section.is_movie():
            items += movie_widgets(context, server, section)

        if section.is_show():
            items += tvshow_widgets(context, server, section)

    if items:
        items += all_server_widgets(context)

    items = paginate_local_items(context, items)

    if items:
        xbmcplugin.addDirectoryItems(get_handle(), items, len(items))

    xbmcplugin.endOfDirectory(get_handle(), cacheToDisc=context.settings.cache_directory())


def movie_widgets(context, server, section):
    items = []
    append_item = items.append
    details = {
        'title': '%s: %s' % (section.get_title(), i18n('On Deck'))
    }
    extra_data = {
        'mode': MODES.TXT_MOVIES_ON_DECK,
        'parameters': {
            'server_uuid': server.get_uuid()
        }
    }
    gui_item = GUIItem(section.get_path(), details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': '%s: %s' % (section.get_title(), i18n('Recently Added'))
    }
    extra_data = {
        'mode': MODES.TXT_MOVIES_RECENT_ADDED,
        'parameters': {
            'server_uuid': server.get_uuid()
        }
    }
    gui_item = GUIItem(section.get_path(), details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': '%s: %s' % (section.get_title(), i18n('Recently Released'))
    }
    extra_data = {
        'mode': MODES.TXT_MOVIES_RECENT_RELEASE,
        'parameters': {
            'server_uuid': server.get_uuid()
        }
    }
    gui_item = GUIItem(section.get_path(), details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': '%s: %s' % (section.get_title(), i18n('Random'))
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.MOVIES_RANDOM,
        'parameters': {
            'server_uuid': server.get_uuid()
        }
    }
    gui_item = GUIItem(section.get_path(), details, extra_data)
    append_item(create_gui_item(context, gui_item))

    return items


def tvshow_widgets(context, server, section):
    items = []
    append_item = items.append

    details = {
        'title': '%s: %s' % (section.get_title(), i18n('On Deck'))
    }
    extra_data = {
        'mode': MODES.TXT_TVSHOWS_ON_DECK,
        'parameters': {
            'server_uuid': server.get_uuid()
        }
    }
    gui_item = GUIItem(section.get_path(), details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': '%s: %s' % (section.get_title(), i18n('Recently Added'))
    }
    extra_data = {
        'mode': MODES.TXT_TVSHOWS_RECENT_ADDED,
        'parameters': {
            'server_uuid': server.get_uuid()
        }
    }
    gui_item = GUIItem(section.get_path(), details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': '%s: %s' % (section.get_title(), i18n('Recently Aired'))
    }
    extra_data = {
        'mode': MODES.TXT_TVSHOWS_RECENT_AIRED,
        'parameters': {
            'server_uuid': server.get_uuid()
        }
    }
    gui_item = GUIItem(section.get_path(), details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': '%s: %s' % (section.get_title(), i18n('Recently Added Shows'))
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.SHOWS_RECENTLY_ADDED,
        'parameters': {
            'server_uuid': server.get_uuid()
        }
    }
    gui_item = GUIItem(section.get_path(), details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': '%s: %s' % (section.get_title(), i18n('Random'))
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.TVSHOWS_RANDOM,
        'parameters': {
            'server_uuid': server.get_uuid()
        }
    }
    gui_item = GUIItem(section.get_path(), details, extra_data)
    append_item(create_gui_item(context, gui_item))

    return items


def all_server_widgets(context):
    items = []
    append_item = items.append

    details = {
        'title': i18n('All Servers: TV Shows On Deck')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.TVSHOWS_ON_DECK
    }

    gui_item = GUIItem('/library/onDeck', details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Servers: Movies On Deck')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.MOVIES_ON_DECK
    }

    gui_item = GUIItem('/library/onDeck', details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Servers: Recently Added Episodes')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.EPISODES_RECENTLY_ADDED
    }

    gui_item = GUIItem('/library/recentlyAdded', details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Servers: Recently Added Movies')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.MOVIES_RECENTLY_ADDED
    }

    gui_item = GUIItem('/library/recentlyAdded', details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Servers: Recently Added Shows')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.SHOWS_RECENTLY_ADDED
    }

    gui_item = GUIItem('/library/recentlyAdded', details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Servers: Random Movies')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.MOVIES_RANDOM
    }

    gui_item = GUIItem('/library/random_movies', details, extra_data)
    append_item(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Servers: Random Shows')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.TVSHOWS_RANDOM
    }

    gui_item = GUIItem('/library/random_shows', details, extra_data)
    append_item(create_gui_item(context, gui_item))

    return items
