# -*- coding: utf-8 -*-

import xbmcplugin  # pylint: disable=import-error

from core.common import get_handle
from core.constants import MODES
from core.context import GUIItem
from core.logger import Logger
from core.strings import i18n
from gui.list_item import create_gui_item
from plex.network import Plex
from processing.pagination import paginate_local_items

LOG = Logger()


def run(context):
    context.plex_network = Plex(context.settings, load=True)
    xbmcplugin.setContent(get_handle(), 'files')

    server_list = context.plex_network.get_active_server_list()
    LOG.debug('Using list of %s servers: %s' % (len(server_list), server_list))

    items = get_menu_items(context)

    items = paginate_local_items(context, items)

    if items:
        xbmcplugin.addDirectoryItems(get_handle(), items, len(items))

    xbmcplugin.endOfDirectory(get_handle(), cacheToDisc=context.settings.cache_directory())


def get_menu_items(context):
    items = []

    details = {
        'title': i18n('Continue Watching')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.CONTINUE_WATCHING
    }

    gui_item = GUIItem('/library/onDeck', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('TV Shows on Deck')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.TVSHOWS_ON_DECK
    }

    gui_item = GUIItem('/library/onDeck', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Movies on Deck')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.MOVIES_ON_DECK
    }

    gui_item = GUIItem('/library/onDeck', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Recently Added Episodes')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.EPISODES_RECENTLY_ADDED
    }

    gui_item = GUIItem('/library/recentlyAdded', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Recently Added Shows')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.SHOWS_RECENTLY_ADDED
    }

    gui_item = GUIItem('/library/recentlyAdded', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Recently Added Movies')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.MOVIES_RECENTLY_ADDED
    }

    gui_item = GUIItem('/library/recentlyAdded', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Movies')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.MOVIES_ALL
    }

    gui_item = GUIItem('/library/all_movies', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Shows')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.TVSHOWS_ALL
    }

    gui_item = GUIItem('/library/all_shows', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Artists')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.ARTISTS_ALL
    }

    gui_item = GUIItem('/library/all_artists', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('All Photos')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.PHOTOS_ALL
    }

    gui_item = GUIItem('/library/all_photos', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Random Movies')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.MOVIES_RANDOM
    }

    gui_item = GUIItem('/library/random_movies', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Random Shows')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.TVSHOWS_RANDOM
    }

    gui_item = GUIItem('/library/random_shows', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Search Movies...')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.MOVIES_SEARCH_ALL
    }

    gui_item = GUIItem('/library/search_all_movies', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Search Shows...')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.TVSHOWS_SEARCH_ALL
    }

    gui_item = GUIItem('/library/search_all_shows', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Search Episodes...')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.EPISODES_SEARCH_ALL
    }

    gui_item = GUIItem('/library/search_all_episodes', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Search Artists...')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.ARTISTS_SEARCH_ALL
    }

    gui_item = GUIItem('/library/search_all_artists', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Search Albums...')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.ALBUMS_SEARCH_ALL
    }

    gui_item = GUIItem('/library/search_all_albums', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    details = {
        'title': i18n('Search Tracks...')
    }
    extra_data = {
        'type': 'Folder',
        'mode': MODES.TRACKS_SEARCH_ALL
    }

    gui_item = GUIItem('/library/search_all_tracks', details, extra_data)
    items.append(create_gui_item(context, gui_item))

    return items
