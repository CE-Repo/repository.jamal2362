# -*- coding: utf-8 -*-

import xbmcplugin  # pylint: disable=import-error

from core.common import get_handle
from core.context import Item
from core.logger import Logger
from core.utils import get_xml
from gui.builders.season import create_season_item
from processing.episodes import process_episodes
from processing.pagination import add_page_navigation
from processing.pagination import paged_listing_url

LOG = Logger()


def process_seasons(context, url, rating_key=None, library=False):
    xbmcplugin.setContent(get_handle(), 'seasons')

    if not url.startswith(('http', 'file')) and rating_key:
        # Get URL, XML and parse
        server = context.plex_network.get_server_from_uuid(url)
        url = server.join_url(server.get_url_location(),
                              'library/metadata/%s/children' % str(rating_key))
    else:
        server = context.plex_network.get_server_from_url(url)

    tree = get_xml(context, paged_listing_url(context, url))
    if tree is None:
        return

    will_flatten = False
    if context.settings.flatten_seasons() == '1':
        # check for a single season
        if int(tree.get('size', 0)) == 1:
            LOG.debug('Flattening single season show')
            will_flatten = True

    all_season_disabled = context.settings.all_season_disabled()

    items = []
    append_item = items.append
    # For all the directory tags
    seasons = tree.iter('Directory')

    for season in seasons:

        if will_flatten:
            url = server.join_url(server.get_url_location(), season.get('key'))
            process_episodes(context, url)
            return

        if all_season_disabled and season.get('index') is None:
            continue

        item = Item(server, url, tree, season)
        append_item(create_season_item(context, item, library=library))

    add_page_navigation(context, url, tree, items)

    if items:
        xbmcplugin.addDirectoryItems(get_handle(), items, len(items))

    xbmcplugin.endOfDirectory(get_handle(), cacheToDisc=context.settings.cache_directory())
