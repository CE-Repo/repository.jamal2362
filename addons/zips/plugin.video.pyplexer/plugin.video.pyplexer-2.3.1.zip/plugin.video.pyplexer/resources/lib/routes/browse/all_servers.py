# -*- coding: utf-8 -*-

import xml.etree.ElementTree as ETree

import xbmcplugin  # pylint: disable=import-error

from artwork.fanart_tv import prefer_artwork
from core.common import get_handle
from core.constants import MODES
from core.context import Item
from core.logger import Logger
from gui.builders.artist import create_artist_item
from gui.builders.movie import create_movie_item
from gui.builders.photo import create_photo_item
from gui.builders.show import create_show_item
from plex.network import Plex
from processing.pagination import PAGE_SIZE
from processing.pagination import add_page_navigation
from processing.pagination import page_number

LOG = Logger()


def run(context):
    context.plex_network = Plex(context.settings, load=True)

    section_type = get_section_type(context)
    all_sections = context.plex_network.all_sections()

    content_type = None
    items = []
    total = 0
    skip = (page_number(context) - 1) * PAGE_SIZE
    remaining = PAGE_SIZE

    LOG.debug('Using list of %s sections: %s' % (len(all_sections), all_sections))

    for section in all_sections:

        if section.get_type() == section_type:
            if content_type is None:
                content_type = get_content_type(section)

            section_items, section_total = _list_content(
                context,
                context.plex_network.get_server_from_uuid(section.get_server_uuid()),
                section.get_path(),
                skip,
                max(1, remaining)
            )
            total += section_total

            if skip >= section_total:
                skip -= section_total
                continue

            skip = 0
            if remaining:
                items += section_items[:remaining]
                remaining -= min(remaining, len(section_items))

    container = ETree.Element('MediaContainer', {
        'size': str(len(items)),
        'totalSize': str(total),
    })
    add_page_navigation(context, 'http://pyplexer/all', container, items)

    if items:
        add_sort_methods(content_type)
        xbmcplugin.setContent(get_handle(), content_type)
        xbmcplugin.addDirectoryItems(get_handle(), items, len(items))

    xbmcplugin.endOfDirectory(get_handle(), cacheToDisc=False)


def add_sort_methods(content_type):
    if content_type == 'movies':
        xbmcplugin.addSortMethod(get_handle(),
                                 xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_DATEADDED)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_VIDEO_RATING)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_VIDEO_RUNTIME)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_MPAA_RATING)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_UNSORTED)
    elif content_type == 'tvshows':
        xbmcplugin.addSortMethod(get_handle(),
                                 xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_VIDEO_RATING)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_MPAA_RATING)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_UNSORTED)
    elif content_type == 'artists':
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_ARTIST_IGNORE_THE)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_LASTPLAYED)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_UNSORTED)
    else:
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_DATE)
        xbmcplugin.addSortMethod(get_handle(), xbmcplugin.SORT_METHOD_VIDEO_YEAR)


def get_section_type(context):
    mode = int(context.params.get('mode', -1))

    if mode == MODES.MOVIES_ALL:
        return 'movie'

    if mode == MODES.TVSHOWS_ALL:
        return 'show'

    if mode == MODES.ARTISTS_ALL:
        return 'artist'

    if mode == MODES.PHOTOS_ALL:
        return 'photo'

    return ''


def get_content_type(section):
    if section.get_type() == 'show':
        return 'tvshows'

    if section.get_type() == 'movie':
        return 'movies'

    if section.get_type() == 'artist':
        return 'artists'

    if section.get_type() == 'photo':
        return 'images'

    return 'files'


def _list_content(context, server, section, start, size):
    section_id = [int(part) for part in section.split('/') if part.isdigit()][0]

    tree = server.get_section_all(section=section_id, start=start, size=size)
    if tree is None:
        return [], 0

    try:
        total = int(tree.get('totalSize') or tree.get('size') or 0)
    except (TypeError, ValueError):
        total = 0

    section_type = get_section_type(context)
    iter_type = 'Video' if section_type == 'movie' else 'Directory'
    branches = list(tree.iter(iter_type))

    if not branches:
        return [], total

    if section_type in ('movie', 'show'):
        prefer_artwork(context, branches, section_type, server)

    items = []
    for content in branches:

        item = Item(server, server.get_url_location(), tree, content)
        if content.get('type') == 'show':
            items.append(create_show_item(context, item))
        elif content.get('type') == 'movie':
            items.append(create_movie_item(context, item))
        elif content.get('type') == 'artist':
            items.append(create_artist_item(context, item))
        elif content.get('type') == 'photo':
            items.append(create_photo_item(context, item))

    return items, max(total, start + len(items))
