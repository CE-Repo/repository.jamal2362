# LCD4Linux for CoreELEC / Kodi

Shows what Kodi is playing on a small USB display — title, artist, cover art,
a progress bar with elapsed and remaining time, plus a clock, CPU load,
temperature and anything else Kodi knows. Every pixel on screen is described
by a JSON layout file, so it can be rearranged freely.

![Music playback](resources/screenshots/default-music.png)
![Video playback](resources/screenshots/default-video.png)
![Large cover](resources/screenshots/bigcover.png)
![Dashboard](resources/screenshots/dashboard.png)

## Will it work with my display?

Two kinds of output, selected under *Settings → Display → Connection*:

| | Hardware | Resolution |
|---|---|---|
| **Samsung SPF** | The photo frames — SPF-72H, SPF-87H, SPF-107H and relatives — in their "mini monitor" mode | 800×480 … 1024×600 |
| **Network display** | No USB panel at all: any browser in full screen, typically an old tablet on the wall | your choice |

Wiring, mode switching and the tablet setup are in **[docs/SETUP.md](docs/SETUP.md)**.

## Install

1. Download the repository as a ZIP (`Code → Download ZIP`) or grab a release.
   The folder inside the ZIP must be named `script.lcd4linux`.
2. Kodi → *Add-ons* → *Install from zip file* → pick the ZIP.
3. Plug in the frame. The service starts on its own and looks for it.
4. *Add-ons → Program add-ons → LCD4Linux* opens the menu: choose a layout,
   show a test pattern, check the status, open the settings.

Straight onto the box instead:

```sh
cd /storage/.kodi/addons
git clone https://github.com/CE-Repo/script.lcd4linux.git
systemctl restart kodi
```

A Samsung frame is switched into its "mini monitor" mode by the add-on and
should light up on its own; give it the better part of a minute after power
on. For a browser instead, set *Output* to **Network display** and open
`http://<box>:8050/display` on the tablet.

## What it does

* **No dependencies.** USB access is `libusb` through ctypes; the PNG and JPEG
  decoders, the JPEG encoder the Samsung frames need, and the font renderer
  are all part of the add-on. No `pyusb`, no Pillow, no compiler — nothing
  outside the add-on has to be installed.
* **Sends only what changed.** Both outputs take complete JPEGs, so only the
  block rows that actually changed are re-encoded; a ticking clock costs a
  fraction of a full frame.
* **Type at any size.** The faces are outlines, rasterised at whatever size
  a layout asks for — by FreeType where the box has it, by a built-in
  rasteriser otherwise. Nothing is resampled from a neighbouring size, and
  the four bundled families cost 220 kB rather than nine megabytes of
  pre-rendered bitmaps.
* **Every Google Fonts family**, 1825 of them, picked from a dialog with a
  search box and a preview drawn by the add-on itself. The index ships with
  it, so searching needs no internet; a face is fetched the first time it is
  used and then kept, and the whole set a layout needs can be cached up
  front. Or drop your own `.ttf` into the fonts folder.
* **20 bundled layouts**, each in 480×320, 800×480 and 1024×600 plus portrait.
  You pick the name, the add-on picks the size that fits the attached display.
* **A layout editor in the browser** at `http://<box>:8050/` — drag elements
  around, with a preview drawn by the same renderer that feeds the display.
  Pick several at once to recolour or realign them in one go, copy them into
  another layout with `Ctrl+C` / `Ctrl+V`, and drag the layer list to reorder.
  Elements can be turned to any angle and can be made to keep their
  proportion while they are resized. There is an
  [offline editor](https://github.com/CE-Repo/editor.lcd4linux) too, for
  building a layout on a laptop with no box in reach.
* **Every Font Awesome Free icon**, about two thousand of them, picked from a
  dialog with a search box. Each one is fetched once and then kept in the
  add-on's own cache, so a box with no internet connection still draws them;
  the whole set can be cached up front in three requests.
* **Every Kodi InfoLabel** is available (`${info:MusicPlayer.Album}`), as is
  every Kodi condition (`Player.HasVideo`).
* **Words that know when to leave.** `{Track ${player.track}}` writes the
  caption only while there is a number, so nothing is left standing on the
  display once the value behind it is gone.
* **Media details in plain words.** Kodi reports `hevc`, `truehd_atmos` and
  `8`; the display shows H.265, Dolby TrueHD Atmos and 7.1, along with the
  dynamic range (Dolby Vision, HDR10+, HDR10, HLG, SDR) and a resolution that
  really reads `2160p` rather than `4K`, the live video and audio bitrate, and
  the clearlogo of the film, the series or the artist. On CoreELEC, with the
  optional `script.module.sidedata` installed, also the Dolby Vision profile
  and its enhancement layer: `Dolby Vision Profile 7.6 FEL`. The tables follow
  [TinyPPI](https://github.com/CE-Repo/script.tinyppi), so a box running both
  add-ons names the same film the same way.
* **Multiple pages** with conditions and automatic rotation — music, video,
  clock and system pages that appear when they are relevant.
* **English and German** on the display, following Kodi's own language.
* **Works without hardware**: render any layout to PNG on a PC.

## Documentation

| | |
|---|---|
| **[docs/SETUP.md](docs/SETUP.md)** | Connecting a Samsung frame or a browser/tablet. Includes powering a Samsung frame on and off, which USB cannot do by itself |
| **[docs/SETTINGS.md](docs/SETTINGS.md)** | Every setting, the actions you can bind to a key, and troubleshooting |
| **[docs/LAYOUT.md](docs/LAYOUT.md)** | The bundled layouts, the browser editor, and the full reference for writing your own |

## Tools

All of these run on a plain PC with Python 3, no Kodi needed:

```sh
python3 tools/preview.py --out preview.png        # render a layout to PNG
python3 tools/webeditor.py                        # the layout editor, standalone
python3 tools/scale_layout.py mine.json 1024 600  # convert to another size
python3 tools/selftest.py                         # check fonts, decoders, layouts
```

`tools/contact_sheet.py` builds the overview images, `tools/make_thumbs.py` the
pictures for the layout chooser, `tools/mkicons.py` rebuilds the Font Awesome
index, `tools/mkgfonts.py` the Google Fonts one, and `tools/mkfonts.py` the
bundled faces (the only one that needs fontTools).

## Licence

MIT — see [LICENSE](LICENSE).

The bundled faces come from the [DejaVu fonts](https://dejavu-fonts.github.io/)
(Bitstream Vera licence), see
[resources/fonts/LICENSE-DejaVu.txt](resources/fonts/LICENSE-DejaVu.txt), with
the media transport signs taken from
[Noto Sans Symbols 2](https://fonts.google.com/noto/specimen/Noto+Sans+Symbols+2)
(SIL Open Font License), see
[resources/fonts/LICENSE-NotoSansSymbols2.txt](resources/fonts/LICENSE-NotoSansSymbols2.txt).

Any family from [Google Fonts](https://fonts.google.com/) can be used; those
are under the SIL Open Font License or Apache 2.0, see
[fonts.google.com/attribution](https://fonts.google.com/attribution). The
add-on bundles only the index of names in
`resources/fonts/googlefonts.json` (rebuilt with `tools/mkgfonts.py`) and
fetches the faces it needs, with their licences, into `<addon data>/gfonts/`.

The `icon` widget can draw the [Font Awesome Free](https://fontawesome.com/)
set; the icons are licensed under CC BY 4.0, see
[resources/icons/LICENSE-FontAwesome.txt](resources/icons/LICENSE-FontAwesome.txt).
The add-on bundles only the index of names in
`resources/icons/fontawesome.json` (rebuilt with `tools/mkicons.py`) and
fetches the outlines it needs into `<addon data>/icons/`.

The Samsung SPF protocol follows lcd4linux's `drv_SamsungSPF.c`, which builds
on `playusb` by Andre Puschmann and the work of Grace Woo. The add-on takes
its name from the [lcd4linux](https://lcd4linux.bulix.org/) project.
