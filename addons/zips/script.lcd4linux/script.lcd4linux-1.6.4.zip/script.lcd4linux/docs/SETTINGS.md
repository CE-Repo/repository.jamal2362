# Settings, actions and troubleshooting

*Add-ons → Program add-ons → LCD4Linux* opens the menu; *Settings* from there,
or the usual context menu on the add-on, opens this dialog.

The dialog hides whatever does not apply: pick an *Output* and only that
mode's options remain visible.

---

## Display → Connection

| Setting | Meaning |
|---|---|
| Output | `USB display` (a Samsung SPF photo frame), `Network display (browser or tablet)`, `Preview file only` (writes `preview.png` into the add-on data folder) or `Disabled` |
| Samsung model | `Automatic` takes the frame it finds; pick a model only when several frames are connected |
| Display number | which frame to use when several are connected |
| Reconnect interval | how long to wait before looking again after the display disappeared (20 s) |
| Start-up grace period | how long after the service starts the display is looked for every few seconds (180 s). For panels that boot slower than Kodi — a Samsung frame needs about half a minute. No "display missing" warning appears during this time |

## Display → JPEG

Both outputs send whole JPEG frames, so these apply to a Samsung frame and to
a browser alike.

| Setting | Meaning |
|---|---|
| JPEG quality | 40–100, default 85. Lower is faster and sends less |
| Reduced colour resolution (4:2:0) | on: faster and smaller. Off: sharper coloured text, about twice the encoding time |

## Display → Picture

| Setting | Meaning |
|---|---|
| Rotation | 0/90/180/270 degrees, for portrait mounting |
| Mirror horizontally | for mirrored mounting |
| Override display size | only when the frame reports a wrong resolution. In network mode width and height are always editable, since nothing reports a size there |

## Display → Brightness

| Setting | Meaning |
|---|---|
| Brightness (software) | 10–100%, the picture is darkened before sending |
| Dim while idle | Dims whenever nothing is playing. Paused still counts as playing |
| Idle brightness (software) | 0–100%; 0% is a black picture |
| Clear the display when Kodi stops | Black picture on shutdown |

Neither a Samsung frame nor a browser has a backlight to control, so the
picture is darkened rather than the lamp dimmed. It costs no extra CPU time —
the darkening lives in the JPEG encoder's colour tables.

## Layout

Active layout, the chooser, a user layout folder, the page interval, and the
buttons *Preview current layout*, *Show test pattern*, *Display status* and
*Reload service*.

*Choose layout…* shows a preview image per design without closing the
settings. Bundled images ship as `resources/thumbs/<design>.png` and are used
as they are — they only change when the add-on is updated. Layouts from your
own folder are drawn from the file, cached in `<addon data>/thumbs/`, and
drawn again whichever time you edit them. Which rule applies is decided by the
folder a layout lies in, not by its name.

Drawing a preview takes seconds, so the dialog does not wait for it: the
running service does it in the background and the entry shows up without a
picture until then. With the service stopped the chooser draws it itself,
behind a progress bar.

The three sizes of one design (`default.json`, `default-800x480.json`,
`default-1024x600.json`) appear as a single entry, because loading picks the
right one anyway.

## Layout → Symbol cache

The `icon` widget can draw any symbol of the Font Awesome Free set, about two
thousand of them. Only the *index* — the names and the words they can be found
by — ships with the add-on, which is what the editor's search dialog works on;
the outlines are fetched the first time a symbol is used and then kept in
`<addon data>/icons/`.

| Setting | Meaning |
|---|---|
| Download Font Awesome symbols | off means only the built-in shapes and what is already cached are drawn (default on) |
| Manage the symbol cache | how much is cached, and the buttons below |
| Symbol source | where outlines come from; empty uses the Font Awesome CDN (expert level) |

*Manage the symbol cache* offers three things:

* **Download every symbol for offline use** — the whole free set, about
  1.6 MB, in three requests. Worth doing before a box goes somewhere without
  internet.
* **Download only what the layouts use** — reads every layout on the box and
  fetches the handful of symbols they name.
* **Empty the symbol cache** — gives the space back. Symbols still in use are
  fetched again the next time they are drawn.

The editor's icon dialog has the same two cache buttons, and its footer says
how much of the set is available offline.

Nothing here ever holds up the display: the renderer draws what the cache has
and hands a missing symbol to a background thread, so a frame is never waiting
on an HTTP request. A symbol that could not be fetched is retried every five
minutes rather than on every frame, and after a network failure all downloads
pause for a minute.

`Symbol source` takes a URL with the placeholders `%(version)s`, `%(style)s`
and `%(name)s`, for a mirror on the local network.

## Layout → Font cache

The same arrangement for type. Any of the 1825 Latin families on
[Google Fonts](https://fonts.google.com/) can be named in a layout; only the
*index* ships with the add-on, which is what the editor's font dialog
searches, and a face is downloaded the first time something draws with it and
kept in `<addon data>/gfonts/` together with its licence.

| Setting | Meaning |
|---|---|
| Download fonts from Google Fonts | off means only the four bundled families and whatever is already cached are drawn (default on) |
| Manage the font cache | how much is cached, and the buttons below |
| Font source | where faces come from; empty uses the Google Fonts API (expert level) |

*Manage the font cache* offers two things:

* **Download the fonts the layouts use** — reads every layout on the box and
  fetches the faces they name. Worth doing before a box goes somewhere without
  internet.
* **Empty the font cache** — gives the space back. A face still in use is
  fetched again the next time it is drawn.

A face is 30 to 180 kB, so a handful of families costs less than a megabyte.
As with symbols, nothing holds up the display: text is drawn in a stand-in of
the same kind — a monospaced family stands in as `mono` — until the real face
has arrived, and a face that could not be fetched is retried every five
minutes rather than on every frame.

`Font source` replaces the Google Fonts CSS endpoint, for a mirror on the
local network. It is asked for `?family=<name>:wght@<weight>&subset=latin` and
has to answer with CSS naming a TrueType or OpenType file.

## Layout → Web editor

| Setting | Meaning |
|---|---|
| Layout editor in the browser | switches the web server on and off (default on) |
| Open the web editor | shows the address it is reachable at |
| Port | 8050 by default |
| Reachable from | `the whole network`, or `this box only` for a browser on the box itself |
| Password | empty means no prompt; otherwise any user name plus this password |

The editor draws its own font samples through `GET /api/fontsample`, which
renders a line of text with the bundled faces and answers with a PNG.
It is part of the editor, so it follows the same password and the same
`Reachable from` setting.

## Behaviour

Frame rate while playing and while idle, smooth image scaling, debug logging,
and the **power hooks** that run a shell command when the service starts and
stops — see [SETUP.md](SETUP.md#switching-the-frame-on-and-off).

### Notifications

Every notification has a switch of its own, and **all of them are off by
default**.

| Setting | Shows |
|---|---|
| Display: library scans | video/music library scan and clean started/finished, on the panel |
| Display: sleep, wake and shutdown | Kodi going to sleep, waking up, quitting or restarting, on the panel |
| Display: messages from other add-ons | messages other add-ons broadcast, on the panel |
| Display: messages sent to LCD4Linux | text sent with the `message` command, on the panel |
| Display: page name when switching pages | the new page's name after `next_page`, on the panel |
| Notification duration (s) | how long a message stays on the panel |
| Kodi: warning when the display cannot be opened | a Kodi notification when the panel cannot be opened |
| Kodi: confirmations of menu actions | Kodi notifications after menu actions (reload, layout chosen, downloads…) |
| Kodi: frame mounted/removed | Kodi's own notices for the Samsung frame's short-lived USB drive |

About the last one: a Samsung frame first appears as a USB drive, so CoreELEC
mounts it and Kodi says so, and says so again when the switch to monitor mode
makes the drive disappear. While the setting is off, the service closes Kodi's
notification while the frame is a USB drive and for 20 seconds after; other
notifications are left alone.

## Language

Nothing to set: the add-on follows Kodi. Settings, on-screen messages, bundled
layouts and the names of weekdays and months exist in English and German. For
your own layouts see *Translating fixed words* in [LAYOUT.md](LAYOUT.md).

---

## Controlling it from Kodi

Bind any of these to a key, a favourite or a skin button:

```
RunScript(script.lcd4linux,next_page)        # next page
RunScript(script.lcd4linux,layout)           # choose layout
RunScript(script.lcd4linux,preview)          # show preview
RunScript(script.lcd4linux,test_pattern)     # test pattern
RunScript(script.lcd4linux,status)           # display status
RunScript(script.lcd4linux,reload)           # reload service
RunScript(script.lcd4linux,brightness_up)    # brighter
RunScript(script.lcd4linux,brightness_down)  # darker
```

Another add-on can push a message onto the display:

```python
xbmc.executeJSONRPC(json.dumps({
    "jsonrpc": "2.0", "id": 1, "method": "JSONRPC.NotifyAll",
    "params": {"sender": "script.lcd4linux", "message": "message",
               "data": {"heading": "Doorbell", "message": "Someone is here"}}}))
```

---

## Troubleshooting

**Nothing happens, or "No Samsung photo frame detected"**
Check `lsusb | grep 04e8`. No device means cable, power, or the frame is
plugged into its host port instead of its upstream one. *Display status* in
the menu shows what the service sees.

**Picture shifted or cut off**
Show the *test pattern*: the red frame must touch all four edges. If it does
not, enable *Override display size* and enter the real resolution.

**Stuttering, high CPU load**
Lower *Updates per second while playing* — 2 is usually plenty. Switch off
*Smooth image scaling*, or use `minimal.json`, which uses no images at all. On
a Samsung, also lower the *JPEG quality*; layouts with large flat areas encode
far faster than one with a full-screen background photo.

**Samsung: the frame stays in mass storage mode**
The log says "the frame stayed in USB mass storage mode". The add-on retries by
itself; if that does not help, unplug and replug the frame. Some models only
switch when they are powered on and not running a slideshow.

**Samsung: the picture freezes**
Without the keep-alive the frame drops out of monitor mode. The add-on sends it
after every frame, and it sends an unchanged picture again every two seconds —
a clock without seconds still transmits, just to keep the frame awake.

**Samsung: half a picture over a grey block, then nothing**
The frame's firmware hung after a picture only arrived partly, which is what a
USB transfer that runs into the *USB timeout* leaves behind. The add-on now
resets the frame when that happens and reconnects after the *Reconnect interval*,
instead of sending the next picture into the half-finished one. If it still
happens often, lower *Updates per second while playing* and the *JPEG
quality*, and try another USB port or cable without a hub.

**The display stays on after Kodi exits**
Enable *Clear the display when Kodi stops*.

**Reading the log**
Turn on *Debug logging*; messages appear in `kodi.log` prefixed with
`[script.lcd4linux]`.

**Checking the installation** — fonts, image decoders, protocol and every
layout, on the box or on a PC:

```sh
python3 /storage/.kodi/addons/script.lcd4linux/tools/selftest.py
```

---

## What a frame costs on a Samsung

The frame only accepts complete JPEG images, so the add-on re-encodes only the
block rows that changed. Measured on a desktop at 800×480, quality 85 — an
Amlogic box is roughly 4–6× slower:

| Layout | First frame | Ongoing | JPEG size |
|---|---|---|---|
| `minimal-800x480` | 113 ms | 9 ms | 23 kB |
| `dashboard-800x480` | 137 ms | 30 ms | 27 kB |
| `default-800x480` | 166 ms | 22 ms | 38 kB |
| `bigcover-800x480` | 168 ms | 12 ms | 28 kB |

A full-frame image costs most on the first frame; after that only the rows with
the clock and the progress bar are left. On a slow box, `minimal` is the
cheapest choice.
