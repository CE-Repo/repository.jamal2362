"""Registered type artwork for mixed directory menus, also used by the build tool."""


# Normal artwork remains the default; only these explicit variants are exported.
DIRECTORY_ICON_VARIANTS = {
    'resources/icons/sync/calendar.png': ('tv',),
    'resources/icons/sync/collection.png': ('movie', 'tv', 'both'),
    'resources/icons/sync/currentlywatching.png': ('movie', 'tv', 'both'),
    'resources/icons/sync/dropped.png': ('tv',),
    'resources/icons/sync/inprogress.png': ('movie', 'tv'),
    'resources/icons/sync/mostwatched.png': ('movie', 'tv', 'episode'),
    'resources/icons/sync/recentlywatched.png': ('movie', 'tv', 'episode', 'both'),
    'resources/icons/sync/recommended-mostwatched.png': ('movie', 'tv'),
    'resources/icons/sync/recommended.png': ('movie', 'tv'),
    'resources/icons/sync/towatch.png': ('movie', 'tv'),
    'resources/icons/sync/up-next.png': ('movie', 'tv'),
    'resources/icons/sync/watchlist-anticipated.png': ('movie', 'tv', 'season', 'episode', 'both'),
    'resources/icons/sync/watchlist-released.png': ('movie', 'tv', 'season', 'episode', 'both'),
    'resources/icons/sync/watchlist.png': ('movie', 'tv', 'season', 'episode', 'both'),
    'resources/icons/themoviedb/airing.png': ('tv',),
    'resources/icons/themoviedb/airingnext.png': ('tv',),
    'resources/icons/themoviedb/calendar.png': ('tv',),
    'resources/icons/themoviedb/collection.png': ('movie',),
    'resources/icons/themoviedb/favorites.png': ('movie', 'tv'),
    'resources/icons/themoviedb/genre.png': ('movie', 'tv'),
    'resources/icons/themoviedb/intheatres.png': ('movie',),
    'resources/icons/themoviedb/lists.png': ('both',),
    'resources/icons/themoviedb/mostvoted.png': ('movie', 'tv'),
    'resources/icons/themoviedb/networks.png': ('tv',),
    'resources/icons/themoviedb/popular.png': ('movie', 'tv', 'person'),
    'resources/icons/themoviedb/providers.png': ('movie', 'tv'),
    'resources/icons/themoviedb/rated.png': ('movie', 'tv'),
    'resources/icons/themoviedb/recommended.png': ('movie', 'tv'),
    'resources/icons/themoviedb/revenue.png': ('movie',),
    'resources/icons/themoviedb/search.png': ('movie', 'tv', 'person'),
    'resources/icons/themoviedb/studios.png': ('movie',),
    'resources/icons/themoviedb/tags.png': ('movie',),
    'resources/icons/themoviedb/toprated.png': ('movie', 'tv'),
    'resources/icons/themoviedb/trending-day.png': ('movie', 'tv', 'person'),
    'resources/icons/themoviedb/trending-week.png': ('movie', 'tv', 'person'),
    'resources/icons/themoviedb/upcoming.png': ('movie',),
    'resources/icons/themoviedb/watchlist.png': ('movie', 'tv'),
}


def get_directory_icon_variant(icon, item_type):
    if item_type in DIRECTORY_ICON_VARIANTS.get(icon, ()):
        return f'{icon[:-4]}-{item_type}.png'
    return None
