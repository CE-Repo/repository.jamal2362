# import _strptime  # fix for py2.7 bug with import log shouldnt be a problem in py3.6+
import datetime
import time
import jurialmunkey.tmdate as jurialmunkey_tmdate


get_timestamp = jurialmunkey_tmdate.get_timestamp
set_timestamp = jurialmunkey_tmdate.set_timestamp


def get_time_difference(timestamp=None):
    now = time.time()
    tmp = timestamp or now
    return tmp - now


def get_datetime_from_epoch(timestamp_in_seconds_from_epoch):
    return datetime.datetime.fromtimestamp(timestamp_in_seconds_from_epoch)


def get_datetime_combine(*args, **kwargs):
    return datetime.datetime.combine(*args, **kwargs)


def get_datetime_time(*args, **kwargs):
    return datetime.time(*args, **kwargs)


def get_datetime_utcnow_isoformat():
    return f'{get_datetime_utcnow().isoformat()}Z'


def get_datetime_now():
    return datetime.datetime.now()


def get_datetime_utcnow():
    return datetime.datetime.now(datetime.timezone.utc)


def get_datetime_today():
    return datetime.datetime.today()


def get_timestring_zulu(date_time):
    return date_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')


def get_timestring_zulu_now():
    return get_timestring_zulu(get_datetime_utcnow())


def get_timedelta(*args, **kwargs):
    return datetime.timedelta(*args, **kwargs)


def get_datetime_datetime(*args, **kwargs):
    return datetime.datetime(*args, **kwargs)


def convert_to_timestamp(date_time):
    '''Converts a datetime object to unix timestamp'''
    try:
        return int(time.mktime(date_time.timetuple()))
    except OverflowError:
        return 2145916800  # Y2038 bug in time.mktime on 32bit float systems. Use 2038 Jan 1 UTC for db timestamp instead.


def format_date_obj(time_obj, str_fmt="%A", region_fmt=None):
    if not time_obj:
        return
    if not region_fmt:
        return time_obj.strftime(str_fmt)
    return get_region_date(time_obj, region_fmt)


def format_date(time_str, str_fmt="%A", time_fmt="%Y-%m-%d", time_lim=10, utc_convert=False, region_fmt=None):
    if not time_str:
        return
    time_obj = convert_timestamp(time_str, time_fmt, time_lim, utc_convert=utc_convert)
    return format_date_obj(time_obj, str_fmt=str_fmt, region_fmt=region_fmt)


def date_in_range(date_str, days=1, start_date=0, date_fmt="%Y-%m-%dT%H:%M:%S", date_lim=19, utc_convert=False):
    datetime_object = convert_timestamp(date_str, date_fmt, date_lim, utc_convert=utc_convert)
    return datetime_in_range(datetime_object, days=days, start_date=start_date)


def datetime_in_range(datetime_object, days=1, start_date=0):
    if not datetime_object:
        return
    date_a = datetime.date.today() + datetime.timedelta(days=start_date)
    date_z = date_a + datetime.timedelta(days=days)
    mydate = datetime_object.date()
    if mydate < date_a:
        return
    if mydate >= date_z:
        return
    return datetime_object


def get_region_date(date_obj, region_fmt='dateshort', del_fmt=':%S'):
    from xbmc import getRegion
    xbmc_region = getRegion(region_fmt).replace(del_fmt, '')  # Strip seconds from formatting durations
    date_string = date_obj.strftime(xbmc_region.encode('unicode-escape').decode())  # Avoid UnicodeEncode errors in strftime
    return date_string.encode('raw-unicode-escape').decode('unicode-escape')  # Restore format literals and preserve localized names


def is_future_timestamp(time_str, time_fmt="%Y-%m-%dT%H:%M:%S", time_lim=19, utc_convert=False, use_today=False, days=0):
    time_obj = convert_timestamp(time_str, time_fmt, time_lim, utc_convert)
    if not isinstance(time_obj, datetime.datetime):
        return
    date_obj = datetime.datetime.today() if use_today else datetime.datetime.now()
    if days:
        date_obj = date_obj + datetime.timedelta(days=days)
    if time_obj > date_obj:
        return time_str


def is_unaired_timestamp(date_str, no_date=True):
    """ Checks if premiered date is unaired. If no date passed returns no_date boolean """
    if date_str:
        return is_future_timestamp(date_str, "%Y-%m-%d", 10)
    return no_date


def get_current_date_time(str_fmt='%Y-%m-%d %H:%M'):
    return datetime.datetime.now().strftime(str_fmt)


def get_todays_date(days=0, str_fmt='%Y-%m-%d'):
    date_obj = datetime.datetime.today()
    if days:
        date_obj += datetime.timedelta(days=days)
    return date_obj.strftime(str_fmt)


def get_calendar_name(startdate=0, days=1):
    from tmdbhelper.lib.addon.plugin import get_localized
    if days == 1:
        if startdate == -1:
            return get_localized(32282)  # Yesterday
        if startdate == 0:
            return get_localized(33006)  # Today
        if startdate == 1:
            return get_localized(33007)  # Tomorrow
        return get_todays_date(days=startdate, str_fmt="%A")
    if days == 7:
        if startdate == 0:
            return get_localized(32284)  # This Week
        if startdate == -7:
            return get_localized(32281)  # Last Week
        return
    if days == 14:
        if startdate == 0:
            return get_localized(32285)  # This Fortnight
        if startdate == -14:
            return get_localized(32280)  # Last Fortnight
        return
    if days == 30:
        if startdate == 0:
            return get_localized(32326)  # This Month
        if startdate == -30:
            return get_localized(32327)  # Last Month


def get_days_to_air(datetime_object):
    """ Returns tuple of number of days and bool if object has aired yet """
    days = (datetime_object.date() - get_datetime_today().date()).days
    return abs(days), days < 0


def convert_timestamp_to_local(time_str):
    """Format a UTC ISO timestamp in local time, retaining its offset and precision."""
    if not time_str:
        return
    time_obj = datetime.datetime.fromisoformat(time_str.replace('Z', '+00:00'))
    return time_obj.replace(tzinfo=time_obj.tzinfo or datetime.timezone.utc).astimezone().isoformat()


def convert_timestamp(time_str, time_fmt="%Y-%m-%dT%H:%M:%S", time_lim=19, utc_convert=False):
    from tmdbhelper.lib.addon.logger import kodi_log
    if not time_str:
        return
    time_str = time_str[:time_lim] if time_lim else time_str
    try:
        time_obj = datetime.datetime.strptime(time_str, time_fmt)
    except TypeError:
        try:
            time_obj = datetime.datetime(*(time.strptime(time_str, time_fmt)[0:6]))
        except Exception as exc:
            kodi_log(exc, 1)
            return
    except Exception as exc:
        kodi_log(exc, 1)
        return
    if utc_convert:
        time_obj = time_obj.replace(tzinfo=time_obj.tzinfo or datetime.timezone.utc).astimezone().replace(tzinfo=None)
    return time_obj


def age_difference(birthday, deathday=None):
    try:  # Added Error Checking as strptime doesn't work correctly on LibreElec
        deathday = convert_timestamp(deathday, '%Y-%m-%d', 10) if deathday else datetime.datetime.now()
        birthday = convert_timestamp(birthday, '%Y-%m-%d', 10)
        age = deathday.year - birthday.year
        if birthday.month * 100 + birthday.day > deathday.month * 100 + deathday.day:
            age = age - 1  # In year of death person hadn't had their birthday yet
        return age
    except Exception:
        return
