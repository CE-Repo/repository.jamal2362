# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 U3knOwn

"""The dashboard's HTTP server: a snapshot producer plus a small read-mostly
API served off the add-on's own port.

One producer thread builds a snapshot on a fixed cadence and every connected
browser is pushed the same one over Server-Sent Events, so five open tabs cost
what one costs -- the alternative, polling per request, would run the whole
side-data pass once per client per tick.

Routes are a fixed table, never a path resolved against the filesystem, and
everything that changes the player's state needs the token.  The server is off
until it is switched on in the add-on settings.
"""

import gzip
import json
import os
import secrets
import socket
import sys
import threading
import time
import traceback
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urlparse

import xbmc
import xbmcaddon
import xbmcvfs

from core.maps import AUDIO_LOGO_MAP, HDR_LOGO_MAP, IMAX_LOGO_MAP
from web import library
from web.snapshot import SnapshotBuilder, apply_command, apply_mode, art_path

_ADDON_ID = "script.tinyppi"

# How often the producer rebuilds the snapshot.  Five a second is well inside
# what a browser can paint and keeps the L1 luminance chart moving with the
# picture; the overlay's own 100ms cadence would only spend it on the wire.
_PRODUCE_INTERVAL = 0.2

# Seconds between heartbeat comments on an idle stream.  Without them a
# connection dropped by a router in between looks alive until the next change.
_HEARTBEAT_INTERVAL = 15.0

# Concurrent event streams.  Each holds a thread for as long as its tab is
# open, so the cap is what stops a forgotten phone from accumulating them.
_MAX_STREAMS = 6

# How long a socket may hold a request thread.
#
# Kodi does not care that these threads are daemons: when the service script
# returns, CPythonInvoker spins -- with no timeout of its own -- until every
# other thread of the interpreter is gone.  So a thread parked on a socket is
# a Kodi that will not shut down, and every wait here has to end on its own.
#
# _REQUEST_TIMEOUT bounds a kept-alive connection that has gone quiet between
# requests; _STREAM_WRITE_TIMEOUT bounds a write into a stream whose reader
# stopped reading.  Both are well inside the five seconds Kodi allows a script
# to stop in (PYTHON_SCRIPT_TIMEOUT).
_REQUEST_TIMEOUT      = 15.0
_STREAM_WRITE_TIMEOUT = 4.0

# How long stop() waits for the threads it asked to finish.  Past this the
# add-on has done what it can and holding the service script open any longer
# only makes the shutdown worse.
_JOIN_TIMEOUT = 2.0

# Longest request body accepted (only the two POSTs have one, and both are
# tiny).
_MAX_BODY = 4096

# The artwork kinds the page may ask for, and how big one may be before it is
# treated as something other than a poster.
# ``thumb`` is an episode's own still, which no playing title has: the
# poster of what is on is the show's, and the still belongs to the row in
# the series card's episode list (see web/library.py).
_ART_KINDS = ("poster", "fanart", "thumb")
_MAX_ART   = 8 * 1024 * 1024

# What a browser may keep, and for how long.
#
# The static files are the add-on's own and change only when it is updated, so
# they are sent with a validator rather than an age: the browser asks whether
# its copy is still good and is answered with an empty 304, which over a
# kept-alive connection is a few dozen bytes instead of the whole page.  An age
# would be faster still and would leave a phone holding yesterday's dashboard
# after an update.
_STATIC_CACHE = "no-cache"

# Artwork is the exception: its address carries a tag that changes with the
# picture (see snapshot._art_tags), so the answer to one address can never go
# out of date and a poster is fetched once per film however often the page is
# reopened.
_ART_CACHE   = "private, max-age=604800, immutable"

# Bodies worth compressing, and the size below which it is not worth the CPU.
# Only text: the icons are already small and the JPEGs are already compressed.
_COMPRESSIBLE = ("text/", "application/manifest+json", "application/json",
                 "image/svg+xml")
_MIN_COMPRESS = 600

# Artwork comes from wherever the library points, so its type is read off the
# name; anything unrecognised is sent as the JPEG that a poster almost always
# is, and the browser corrects itself from the bytes.
_ART_TYPES = {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
    ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp",
}
_ART_FALLBACK_TYPE = "image/jpeg"

# Ambiguity-free alphabet: a token is read off a TV and typed on a phone.
_TOKEN_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
_TOKEN_LENGTH   = 8

_MIN_PORT, _MAX_PORT = 1024, 65535
_DEFAULT_PORT = 8099

# The page's own chrome, keyed the way its script names them.  Sent with
# /api/hello so the dashboard speaks whatever language Kodi is set to, the
# same as the row labels that travel with each snapshot.  Four of them are
# the overlay's own strings rather than new ones, so the two always agree on
# what a reading is called.
_UI_STRINGS = {
    "connected":     32448,
    "connecting":    32449,
    "offline":       32450,
    "idle_title":    32451,
    "idle_text":     32452,
    "peak":          32453,
    "average":       32454,
    "fps":           32140,   # FPS
    "chart":         32455,
    "active_area":   32030,   # L5 Active Area
    "vs10":          32467,
    "metadata":      32393,   # Dolby Vision metadata view
    "metadata_section": 32289,  # Metadata
    "no_metadata":      32470,
    "no_metadata_text": 32471,
    # The VS10 output the picture leaves on, not the audio row's sink,
    # which keeps #32055: one string cannot be translated for both.
    "output":        32057,   # Output (picture)
    "copy":          32456,
    "copied":        32457,
    "token_title":   32459,
    "token_text":    32460,
    "save":          32461,
    "cancel":        32462,
    "token_bad":     32463,
    "switching":     32464,
    "switched":      32465,
    "switch_failed": 32466,
    # The summary figures, history chart and transport row.
    "switches":      32478,
    "events":        32479,
    "events_empty":  32480,
    "range_1m":      32481,
    "range_10m":     32482,
    "range_all":     32483,
    "audio_track":   32484,
    "subtitles":     32485,
    "off":           32486,
    "mute":          32488,
    "playpause":     32489,
    "stop":          32490,
    "ev_mode":       32491,
    "controls":      32494,
    "metrics":       32495,
    "player_cache":  32511,
    "warnings":        32514,
    "temperature":     32018,
    "processor":       32014,
    # The theme button and the menu behind a long press on it.
    "theme_dark":      32496,
    "theme_adaptive":  32497,
    "theme_midnight":  32498,
    "theme_menu":      32500,
    "tint_label":      32501,
    "tint_subtle":     32502,
    "tint_standard":   32503,
    "tint_strong":     32504,
    # The playback chart, the title that has just ended, and the one thing a
    # stream can be refused for that is worth naming.
    "last_played":     32507,
    "summary":         32508,
    "busy":            32509,
    # The tab bar.  The two shelves are named by "films" and "series".
    "tab_live":        32582,
    "tab_metadata":    32583,
    "tab_history":     32584,
    # The settings tab: the theme, the token and the reports that used to sit
    # behind the key in the top bar.
    "tab_settings":    32585,
    "token_enter":     32586,
    "report_live":     32587,
    # The two keys either side of play, on a file that has chapters.
    "chapter_previous": 32515,
    "chapter_next":     32516,
    # The volume, which steps rather than slides so that a box passing volume
    # over CEC can send the steps on to an amplifier.
    "volume_down":      32517,
    "volume_up":        32518,
    # The wall clock under the middle of the progress bar, between how far the
    # title has got and how long it runs for.
    "ends_at":          32531,
    # The film library the idle page offers instead of an empty screen.
    "films":            32532,
    "films_empty":      32533,
    "films_search":     32534,
    "films_starting":   32535,
    "films_failed":     32536,
    "films_resume":     32537,
    "films_watched":    32540,
    # The row of films and episodes left half-watched, above both shelves.
    "continue":         32572,
    # The walls of what is still unwatched, under the walls of everything, and
    # the question a press on a title asks.
    "films_unseen":     32573,
    "series_unseen_shows": 32574,
    "mark_watched":     32575,
    "mark_unwatched":   32576,
    "mark_failed":      32577,
    "films_play":       32578,
    "series_open":      32579,
    "play_from_start":  32580,
    "resume_clear":     32581,
    # And the series library beside it: the same shelf with one floor more,
    # so the same strings again plus the few an episode list needs.
    "series":           32541,
    "series_empty":     32542,
    "series_search":    32543,
    "series_back":      32544,
    "series_unseen":    32545,
    "series_season":    32546,
    "series_specials":  32547,
    "series_failed":    32548,
    # The cross inside either search box.
    "search_clear":     32551,
    # How long something runs: the two halves of it, and the minutes alone for
    # anything short of an hour.
    "runtime_hm":       32552,
    "runtime_m":        32553,
    "runtime_h":        32554,
}


def ui_strings(addon=None) -> dict[str, str]:
    """The page's chrome, localized through Kodi's own string table."""
    addon = addon or _addon()
    strings = {key: addon.getLocalizedString(string_id)
               for key, string_id in _UI_STRINGS.items()}
    # Yes and No are Kodi core strings, not entries in this add-on's table.
    # Asking Addon.getLocalizedString for 106/107 returns an empty string and
    # would erase the report values when the hello response reaches the page.
    strings["yes"] = xbmc.getLocalizedString(107) or "Yes"
    strings["no"] = xbmc.getLocalizedString(106) or "No"
    strings["cancel"] = xbmc.getLocalizedString(222) or "Cancel"
    return strings


def _log(message: str, level: int = xbmc.LOGINFO) -> None:
    xbmc.log(f"{_ADDON_ID} --> web: {message}", level=level)


# --- Settings --------------------------------------------------------------

def _addon() -> xbmcaddon.Addon:
    """A fresh Addon, so a setting changed while the service runs is seen."""
    return xbmcaddon.Addon()


def ensure_token(addon=None) -> str:
    """The dashboard's access token, generating one the first time it is
    needed so a freshly enabled server is never left unprotected."""
    addon = addon or _addon()
    token = (addon.getSetting("web_token") or "").strip()
    if not token:
        token = generate_token(addon)
    return token


def generate_token(addon=None) -> str:
    """Mint and store a new token, invalidating whatever was handed out
    before."""
    addon = addon or _addon()
    token = "".join(secrets.choice(_TOKEN_ALPHABET) for _ in range(_TOKEN_LENGTH))
    addon.setSetting("web_token", token)
    return token


def configured_port(addon=None) -> int:
    """The configured port, falling back to the default for anything outside
    the range a non-root process may bind."""
    addon = addon or _addon()
    try:
        port = int(addon.getSetting("web_port") or _DEFAULT_PORT)
    except ValueError:
        return _DEFAULT_PORT
    return port if _MIN_PORT <= port <= _MAX_PORT else _DEFAULT_PORT


def local_address(port: int | None = None) -> str:
    """The URL to reach the dashboard on, as far as this box can tell.

    The route lookup opens no connection -- a UDP socket sends nothing on
    ``connect`` -- so it answers on a box with no internet just as well.
    """
    port = port or configured_port()
    host = ""
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            probe.connect(("203.0.113.1", 9))  # TEST-NET-3, never routed
            host = probe.getsockname()[0]
        finally:
            probe.close()
    except OSError:
        host = ""
    if not host:
        host = xbmc.getInfoLabel("Network.IPAddress") or "<box-ip>"
    return f"http://{host}:{port}/"


# --- Static files ----------------------------------------------------------

def _web_root() -> str:
    return os.path.join(_addon().getAddonInfo("path"), "resources", "web")


def _addon_root() -> str:
    return _addon().getAddonInfo("path")


# Route -> (absolute path, content type).  Built once per server so a request
# can never name a file of its own: an unknown route is a 404, not a lookup.
def _static_routes() -> dict[str, tuple[str, str]]:
    web = _web_root()
    root = _addon_root()
    html = "text/html; charset=utf-8"
    return {
        "/":                      (os.path.join(web, "index.html"), html),
        "/index.html":            (os.path.join(web, "index.html"), html),
        # The Dolby Vision metadata list, once a window of its own and now a
        # tab of the dashboard.  The old address is the same page, which
        # opens on that tab (see tabFromAddress in js/dashboard.js), so a
        # bookmark of either spelling still lands on the list.
        "/metadata":              (os.path.join(web, "index.html"), html),
        "/metadata.html":         (os.path.join(web, "index.html"), html),
        "/css/base.css":          (os.path.join(web, "css", "base.css"), "text/css; charset=utf-8"),
        "/css/live-panels.css":   (os.path.join(web, "css", "live-panels.css"), "text/css; charset=utf-8"),
        "/css/dashboard.css":     (os.path.join(web, "css", "dashboard.css"), "text/css; charset=utf-8"),
        "/css/metadata.css":      (os.path.join(web, "css", "metadata.css"), "text/css; charset=utf-8"),
        "/css/theme.css":         (os.path.join(web, "css", "theme.css"), "text/css; charset=utf-8"),
        "/js/core.js":            (os.path.join(web, "js", "core.js"), "text/javascript; charset=utf-8"),
        "/js/theme.js":           (os.path.join(web, "js", "theme.js"), "text/javascript; charset=utf-8"),
        "/js/cover-tint.js":      (os.path.join(web, "js", "cover-tint.js"), "text/javascript; charset=utf-8"),
        "/js/live-panels.js":     (os.path.join(web, "js", "live-panels.js"), "text/javascript; charset=utf-8"),
        "/js/dashboard.js":       (os.path.join(web, "js", "dashboard.js"), "text/javascript; charset=utf-8"),
        "/js/metadata.js":        (os.path.join(web, "js", "metadata.js"), "text/javascript; charset=utf-8"),
        "/icons/chevron-down.svg": (os.path.join(web, "icons", "chevron-down.svg"), "image/svg+xml"),
        "/icons/download.svg":    (os.path.join(web, "icons", "download.svg"), "image/svg+xml"),
        "/icons/key.svg":         (os.path.join(web, "icons", "key.svg"), "image/svg+xml"),
        "/icons/play.svg":        (os.path.join(web, "icons", "play.svg"), "image/svg+xml"),
        "/icons/pause.svg":       (os.path.join(web, "icons", "pause.svg"), "image/svg+xml"),
        "/icons/stop.svg":        (os.path.join(web, "icons", "stop.svg"), "image/svg+xml"),
        "/icons/chapter-previous.svg": (os.path.join(web, "icons", "chapter-previous.svg"), "image/svg+xml"),
        "/icons/chapter-next.svg": (os.path.join(web, "icons", "chapter-next.svg"), "image/svg+xml"),
        "/icons/volume.svg":      (os.path.join(web, "icons", "volume.svg"), "image/svg+xml"),
        "/icons/volume-muted.svg": (os.path.join(web, "icons", "volume-muted.svg"), "image/svg+xml"),
        "/icons/yes.svg":         (os.path.join(web, "icons", "yes.svg"), "image/svg+xml"),
        "/icons/check.svg":       (os.path.join(web, "icons", "check.svg"), "image/svg+xml"),
        "/icons/star.svg":        (os.path.join(web, "icons", "star.svg"), "image/svg+xml"),
        "/icons/no.svg":          (os.path.join(web, "icons", "no.svg"), "image/svg+xml"),
        "/icons/theme-dark.svg":  (os.path.join(web, "icons", "theme-dark.svg"), "image/svg+xml"),
        "/icons/theme-adaptive.svg": (os.path.join(web, "icons", "theme-adaptive.svg"), "image/svg+xml"),
        "/icons/theme-midnight.svg": (os.path.join(web, "icons", "theme-midnight.svg"), "image/svg+xml"),
        # The six keys of the tab bar.
        "/icons/tab-live.svg":    (os.path.join(web, "icons", "tab-live.svg"), "image/svg+xml"),
        "/icons/tab-metadata.svg": (os.path.join(web, "icons", "tab-metadata.svg"), "image/svg+xml"),
        "/icons/tab-films.svg":   (os.path.join(web, "icons", "tab-films.svg"), "image/svg+xml"),
        "/icons/tab-series.svg":  (os.path.join(web, "icons", "tab-series.svg"), "image/svg+xml"),
        "/icons/tab-history.svg": (os.path.join(web, "icons", "tab-history.svg"), "image/svg+xml"),
        "/icons/tab-settings.svg": (os.path.join(web, "icons", "tab-settings.svg"), "image/svg+xml"),
        "/manifest.webmanifest":  (os.path.join(web, "manifest.webmanifest"), "application/manifest+json"),
        "/icon.png":              (os.path.join(root, "icon.png"), "image/png"),
        "/fanart.png":            (os.path.join(root, "fanart.png"), "image/png"),
        **_media_routes(root),
    }


def _media_routes(root: str) -> dict[str, tuple[str, str]]:
    """The skin graphics the dashboard draws, as routes under ``/media/``.

    Built from the very maps the overlay picks its logos out of, so a format
    wears the same face on the TV and on the phone.  Naming them here keeps the
    route table what it was: an allowlist of files the add-on itself would
    draw, never a path that came in with a request.  A logo that is not
    installed -- the IMAX ones ship separately -- is simply not a route.
    """
    media = os.path.join(root, "resources", "skins", "Default", "media")
    names = set(HDR_LOGO_MAP.values())
    names |= set(AUDIO_LOGO_MAP.values())
    names |= set(IMAX_LOGO_MAP.values())

    routes = {}
    for name in sorted(names):
        path = os.path.join(media, name.replace("/", os.sep))
        if name and os.path.exists(path):
            routes[f"/media/{name}"] = (path, "image/png")
    return routes


class _StaticFiles:
    """The route table's files, read and compressed once.

    A page opening asks for a dozen of them at once, and every one of those
    reads would otherwise come off the box's own flash while the browser waits.
    Each file is read on its first request and kept with its compressed twin
    and a validator; the size and modification time are checked on every
    request, so a file replaced under a running server is picked up rather than
    served from yesterday.

    Shared by every request thread, hence the lock -- held only around the
    dictionary, never around a read.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._files: dict[str, tuple[tuple, tuple]] = {}

    def get(self, path: str, content_type: str) -> tuple | None:
        """``(body, gzipped_or_None, etag)`` for a file, or None when it is
        gone."""
        try:
            stat = os.stat(path)
        except OSError:
            return None
        stamp = (stat.st_mtime_ns, stat.st_size)

        with self._lock:
            held = self._files.get(path)
        if held is not None and held[0] == stamp:
            return held[1]

        try:
            with open(path, "rb") as handle:
                body = handle.read()
        except OSError:
            return None

        packed = None
        if len(body) >= _MIN_COMPRESS and content_type.startswith(_COMPRESSIBLE):
            packed = gzip.compress(body, 6)
            # A file that grows under compression is sent as it is.
            if len(packed) >= len(body):
                packed = None
        # The modification time and the size: the files are the add-on's, and
        # an update rewrites every one of them.
        entry = (body, packed, f'"{stat.st_mtime_ns:x}-{stat.st_size:x}"')

        with self._lock:
            self._files[path] = (stamp, entry)
        return entry


# --- Delta frames ----------------------------------------------------------

# The stream sends one whole snapshot when a browser connects and only what
# moved after that.  Almost nothing does: a title's rows are written once and
# then stand for two hours, while the clock and a handful of figures move five
# times a second -- so a delta is a few dozen bytes where the snapshot it
# replaces is tens of kilobytes, which on a phone is the difference between a
# background tab that costs nothing and one that costs a battery.
#
# The two long lists are diffed by row.  Their *shape* -- which cards exist,
# which rows they hold and what those are called -- decides how: unchanged, and
# only the readings that moved are sent; changed at all, and the whole list
# goes, because a page cannot patch rows into a list it does not have yet.
# Everything else is compared whole and sent whole, each being small.

_DELTA_LISTS = ("groups", "metadata")


def _group_shape(groups: list) -> tuple:
    """Which cards a snapshot has, and which rows under which names."""
    return tuple(
        (group.get("id"), group.get("title"),
         tuple((row.get("id"), row.get("label")) for row in group.get("rows", ())))
        for group in groups
    )


def _group_rows_delta(previous: list, current: list) -> list | None:
    """Changed rows as ``[id, value, detail]``, or None to send the lot."""
    if _group_shape(previous) != _group_shape(current):
        return None
    changed = []
    for was, now in zip(previous, current):
        for old_row, new_row in zip(was.get("rows", ()), now.get("rows", ())):
            if (old_row.get("value") != new_row.get("value")
                    or old_row.get("detail") != new_row.get("detail")):
                changed.append([new_row.get("id"), new_row.get("value"),
                                new_row.get("detail")])
    return changed


def _metadata_shape(rows: list) -> tuple:
    """The metadata list's shape: what each row is and how wide it is.

    A trim row carries cells and every other row a single value (see
    ``snapshot._metadata_row``), so the width tells the two apart as well as
    catching a table that gained a column.
    """
    return tuple(
        (row.get("kind"), row.get("name"),
         len(row["cells"]) if isinstance(row.get("cells"), list) else -1)
        for row in rows
    )


def _metadata_delta(previous: list, current: list) -> list | None:
    """Changed rows as ``[index, value-or-cells]``, or None to send the lot."""
    if _metadata_shape(previous) != _metadata_shape(current):
        return None
    changed = []
    for index, (was, now) in enumerate(zip(previous, current)):
        if was.get("value") != now.get("value") or was.get("cells") != now.get("cells"):
            changed.append([index, now["cells"] if "cells" in now else now.get("value")])
    return changed


def _snapshot_delta(previous: dict, current: dict) -> dict:
    """One delta frame: what ``current`` has that ``previous`` did not."""
    frame: dict = {"seq": current.get("seq", 0)}

    moved = {key: value for key, value in current.items()
             if key != "seq" and key not in _DELTA_LISTS
             and previous.get(key) != value}
    gone = [key for key in previous
            if key not in current and key not in _DELTA_LISTS]
    if moved:
        frame["set"] = moved
    if gone:
        frame["del"] = gone

    for key, rows_delta in (("groups", _group_rows_delta),
                            ("metadata", _metadata_delta)):
        was = previous.get(key) or []
        now = current.get(key) or []
        if was == now:
            continue
        rows = rows_delta(was, now)
        frame[key] = now if rows is None else {"rows": rows}
    return frame


# --- Artwork ---------------------------------------------------------------

def _unwrap_image_url(path: str) -> str:
    """The real file behind a Kodi ``image://`` address.

    Kodi wraps art in a texture URL -- ``image://`` plus the source, percent
    encoded, plus a trailing slash.  The wrapper is a name for its own texture
    cache and not something the file system knows, so it is unwrapped back to
    the path or URL the library actually points at.
    """
    if not path.startswith("image://"):
        return path
    inner = unquote(path[len("image://"):])
    return inner[:-1] if inner.endswith("/") else inner


def _art_sources(path: str) -> tuple[str, ...]:
    """Every address one shelf picture can be read from, smallest first.

    A poster the library scraped is a thousand pixels wide and often two, and
    the tile it is drawn in on a phone is a hundred and twenty.  Every one of
    those pixels crosses the network and is then decoded, and a wall of them is
    what a phone feels as a stutter while it is being scrolled.

    Kodi already keeps a smaller copy of everything it has ever drawn -- that
    is what its texture cache is for -- so the wall is read out of that: the
    plain ``image://`` wrapper, which a poster goes into capped at 1280x720 and
    fanart at 1920x1080.  The unwrapped original is kept as the way back, and
    is what answers on a box whose cache has just been cleared.

    Not ``?size=thumb``, which this asked for first until it turned out to be
    the reason a wall took so long to fill.  The cache is keyed by the whole
    address, options and all, so that is a different entry from the plain one
    -- and one that has never existed, where the plain one was made the first
    time Kodi drew the poster in its own window.  Asking for it made the box
    build a second thumbnail cache for the entire collection a poster at a
    time, and for a library whose art is scraped rather than local, building
    one means fetching the original off the internet again.  A third of the
    pixels is not worth a download per tile.
    """
    if path.startswith("image://"):
        # Kodi's own wrapper already: the address its texture cache is under.
        return (path, _unwrap_image_url(path))
    # A file the library points at directly.  Wrapped here so the cache
    # answers for it too, and the file itself kept as the way back.
    return ("image://" + quote(path, safe="") + "/", path)


def _art_type(path: str) -> str:
    return _ART_TYPES.get(os.path.splitext(path)[1].lower(), _ART_FALLBACK_TYPE)


def _image_type(data: bytes, fallback: str) -> str:
    """What the bytes actually are, rather than what the address suggested.

    The address is no longer a promise: what comes back from the texture cache
    is whatever Kodi chose to store the picture as, which is not always what
    the library scraped it as -- a PNG with nothing transparent in it is kept
    as a JPEG.  A browser handed the wrong type draws nothing at all.
    """
    if data[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return fallback


def _read_art(path: str) -> bytes | None:
    """Read an artwork file through Kodi's own VFS, or None.

    Kodi's VFS rather than ``open``: art lives wherever the library put it,
    which is as often a share or a URL as it is a local file, and only Kodi
    knows how to reach all three.
    """
    handle = None
    try:
        handle = xbmcvfs.File(path)
        data = bytes(handle.readBytes(_MAX_ART))
    except Exception:
        return None
    finally:
        if handle is not None:
            try:
                handle.close()
            except Exception:
                pass
    return data or None


# --- The server ------------------------------------------------------------

class _Producer(threading.Thread):
    """Builds the snapshot on a fixed cadence and wakes the streams waiting
    on it."""

    def __init__(self, stop_event: threading.Event) -> None:
        super().__init__(name="TinyPPI-web-producer", daemon=True)
        # Not ``_stop``: that name is one of Thread's own internals, and
        # shadowing it makes the thread impossible to join -- which is
        # exactly what the shutdown has to be able to do.
        self._stopping  = stop_event
        self._builder   = SnapshotBuilder()
        self._condition = threading.Condition()
        self._snapshot: dict = {"seq": 0, "playing": False, "groups": [],
                                "metrics": {}, "library": 0}
        self._failed    = False

    def wake(self) -> None:
        """Release every waiting stream at once, used on shutdown."""
        with self._condition:
            self._condition.notify_all()

    @property
    def snapshot(self) -> dict:
        with self._condition:
            return self._snapshot

    def history(self) -> dict:
        """The playing title's chart samples and events.

        Reached straight from the request thread: the session keeps a lock of
        its own, which is cheaper than holding up the producer for a list that
        is only asked for when a page opens or an event lands.
        """
        return self._builder.session.history()

    def wait_for(self, seen: int, timeout: float) -> dict | None:
        """Block until a snapshot newer than ``seen`` exists, or the timeout
        runs out (then None, and the caller sends a heartbeat).

        The stop flag is read inside the lock and before every wait, so a
        stream that arrives here just after stop() has notified the condition
        leaves at once instead of sleeping out the heartbeat interval.  That
        race is what used to leave threads running fifteen seconds into a
        shutdown Kodi allows five for.
        """
        deadline = time.monotonic() + timeout
        with self._condition:
            while True:
                if self._snapshot.get("seq", 0) > seen:
                    return self._snapshot
                if self._stopping.is_set():
                    return None
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                self._condition.wait(remaining)

    def run(self) -> None:
        monitor = xbmc.Monitor()
        while not self._stopping.is_set() and not monitor.abortRequested():
            try:
                addon = _addon()
                snapshot = self._builder.build(
                    addon,
                    allow_filename=addon.getSetting("filename") == "true",
                    metadata=addon.getSetting("web_metadata") == "true",
                    control=addon.getSetting("web_allow_control") == "true",
                )
                # Which version of the two shelves a client asking now would be
                # handed.  It rides out with every snapshot because that is the
                # one thing already going to every screen in the house: a page
                # that drew a film as unwatched an hour ago has no other way of
                # hearing that it has since been watched, and reloading the
                # page is not an answer.  Reading it here also runs whatever
                # deferred drop the last stop asked for -- this thread is the
                # clock the add-on does not otherwise have (see
                # ``library.revision``).
                snapshot["library"] = library.revision()
                with self._condition:
                    self._snapshot = snapshot
                    self._condition.notify_all()
            except Exception as exc:  # never let one bad pass end the stream
                self._log_failure(exc)
            if monitor.waitForAbort(_PRODUCE_INTERVAL):
                break
        with self._condition:
            self._condition.notify_all()

    def _log_failure(self, exc: Exception) -> None:
        """Log a failed pass once, so a persistent fault leaves one line in
        the log rather than five a second."""
        if self._failed:
            return
        self._failed = True
        _log(f"snapshot failed, continuing with the last one: {exc}",
             xbmc.LOGWARNING)


class _Handler(BaseHTTPRequestHandler):
    """The route table.  ``server`` carries the producer, the token and the
    static-file map."""

    protocol_version = "HTTP/1.1"
    server_version   = "TinyPPI"
    sys_version      = ""
    # Applied to the socket before the first request line is read, so a
    # connection that is opened and then says nothing cannot hold a thread --
    # and with it Kodi's shutdown -- for good.
    timeout          = _REQUEST_TIMEOUT

    # -- plumbing --

    def log_message(self, fmt: str, *args) -> None:  # noqa: A003 - base API
        _log(fmt % args, xbmc.LOGDEBUG)

    def _send(self, status: HTTPStatus, body: bytes, content_type: str,
              extra: tuple[tuple[str, str], ...] = (),
              cache: str = "no-store") -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        # The default is the live state of a player, which may never be
        # replayed from a cache.  The page itself is another matter, and says
        # so (see _serve_static and _serve_art).
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        for name, value in extra:
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    def _send_unchanged(self, etag: str, cache: str) -> None:
        """Answer a conditional request with an empty 304."""
        self.send_response(HTTPStatus.NOT_MODIFIED)
        self.send_header("ETag", etag)
        self.send_header("Cache-Control", cache)
        self.end_headers()

    def _holds(self, etag: str) -> bool:
        """Whether the request already carries this exact version."""
        offered = self.headers.get("If-None-Match", "")
        return bool(etag) and etag in [
            part.strip().removeprefix("W/") for part in offered.split(",")
        ]

    def _send_json(self, payload: dict, status: HTTPStatus = HTTPStatus.OK,
                   etag: str = "", cache: str = "no-store") -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        extra: tuple[tuple[str, str], ...] = (("ETag", etag),) if etag else ()
        # The chart's history is the one answer here big enough to be worth
        # compressing -- an hour of samples is five arrays of 3600 numbers --
        # and it is asked for whenever a page opens or an event lands.
        if (len(body) >= _MIN_COMPRESS
                and "gzip" in self.headers.get("Accept-Encoding", "")):
            body = gzip.compress(body, 6)
            extra += (("Content-Encoding", "gzip"), ("Vary", "Accept-Encoding"))
        self._send(status, body, "application/json; charset=utf-8", extra,
                   cache=cache)

    def _send_error_json(self, status: HTTPStatus, message: str) -> None:
        self._send_json({"error": message}, status)

    # -- auth --

    def _presented_token(self) -> str:
        header = self.headers.get("X-TinyPPI-Token", "")
        if header:
            return header.strip()
        query = parse_qs(urlparse(self.path).query)
        return (query.get("token") or [""])[0].strip()

    def _authorised(self) -> bool:
        expected = self.server.token
        presented = self._presented_token()
        # compare_digest over equal-length ASCII; a wrong length is a
        # mismatch either way.
        return len(presented) == len(expected) and secrets.compare_digest(
            presented, expected
        )

    # -- routing --

    def do_GET(self) -> None:  # noqa: N802 - base API
        route = urlparse(self.path).path
        if route in self.server.static_routes:
            self._serve_static(route)
            return
        if route in ("/api/state", "/api/stream", "/api/history", "/api/art",
                     "/api/library", "/api/series", "/api/episodes",
                     "/api/continue"):
            if self.server.auth_read and not self._authorised():
                self._send_error_json(HTTPStatus.UNAUTHORIZED, "token required")
                return
            if route == "/api/state":
                self._send_json(self._state_payload())
            elif route == "/api/library":
                self._serve_library()
            elif route == "/api/series":
                self._serve_series()
            elif route == "/api/episodes":
                self._serve_episodes()
            elif route == "/api/continue":
                self._serve_continue()
            elif route == "/api/history":
                # The chart's whole past and the event list, asked for on
                # connect and again whenever the snapshot's event count moves.
                self._send_json(self.server.producer.history())
            elif route == "/api/art":
                self._serve_art()
            else:
                self._serve_stream()
            return
        if route == "/api/hello":
            # Deliberately unauthenticated: it carries no player state, only
            # what the page needs to know before it can ask for any.
            addon = _addon()
            self._send_json({
                "name":        "TinyPPI",
                "version":     addon.getAddonInfo("version"),
                "auth_read":   self.server.auth_read,
                "control":     self.server.allow_control,
                # Whether the idle page has a film library to offer.  Both
                # halves have to be there: reading the library is this
                # setting, and starting one of them is the control setting.
                "library":     self.server.offer_library and self.server.allow_control,
                # And whether it has a series library, which is its own
                # setting: the two shelves are offered separately, so a box can
                # have the one and not the other.
                "series":      self.server.offer_series and self.server.allow_control,
                "interval_ms": int(_PRODUCE_INTERVAL * 1000),
                "strings":     ui_strings(addon),
            })
            return
        self._send_error_json(HTTPStatus.NOT_FOUND, "no such route")

    def do_POST(self) -> None:  # noqa: N802 - base API
        # The body is read first, whatever the request turns out to be: on a
        # kept-alive HTTP/1.1 connection an unread body is parsed as the next
        # request line, so a rejected POST would corrupt the one after it.
        payload = self._read_json_body()
        if payload is None:
            return

        route = urlparse(self.path).path
        if route not in ("/api/mode", "/api/command", "/api/play",
                         "/api/watched", "/api/resume"):
            self._send_error_json(HTTPStatus.NOT_FOUND, "no such route")
            return
        if not self.server.allow_control:
            self._send_error_json(HTTPStatus.FORBIDDEN, "control disabled")
            return
        # Writing always needs the token, whatever reading is set to.
        if not self._authorised():
            self._send_error_json(HTTPStatus.UNAUTHORIZED, "token required")
            return

        if route == "/api/play":
            self._start_film(payload)
            return

        if route == "/api/watched":
            self._mark_watched(payload)
            return

        if route == "/api/resume":
            self._clear_resume(payload)
            return

        if route == "/api/mode":
            mode = str(payload.get("mode", "")).strip()
            if not apply_mode(mode):
                self._send_error_json(HTTPStatus.BAD_REQUEST, "unknown mode")
                return
            _log(f"VS10 mode '{mode}' requested from {self.client_address[0]}")
            self._send_json({"ok": True, "mode": mode})
            return

        action = str(payload.get("action", "")).strip()
        if not apply_command(action, payload.get("value")):
            self._send_error_json(HTTPStatus.BAD_REQUEST, "command failed")
            return
        # A seek or a volume nudge arrives by the dozen while a finger is on
        # the slider; only the ones that change what the player is doing are
        # worth a line at the level a normal log keeps.
        _log(f"'{action}' requested from {self.client_address[0]}",
             xbmc.LOGDEBUG if action in ("seek", "seek_percent", "volume")
             else xbmc.LOGINFO)
        self._send_json({"ok": True, "action": action})

    def _read_json_body(self) -> dict | None:
        """The request body as a dict, or None once an error has been sent."""
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = -1
        if length < 0 or length > _MAX_BODY:
            self._send_error_json(HTTPStatus.BAD_REQUEST, "bad body length")
            return None
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
        except (ValueError, OSError):
            self._send_error_json(HTTPStatus.BAD_REQUEST, "bad JSON")
            return None
        if not isinstance(payload, dict):
            self._send_error_json(HTTPStatus.BAD_REQUEST, "bad JSON")
            return None
        return payload

    # -- responses --

    def _state_payload(self) -> dict:
        payload = dict(self.server.producer.snapshot)
        payload["control"] = self.server.allow_control
        # Whether a stream would be turned away right now.  A browser whose
        # EventSource was refused cannot read why -- the failure reaches it as
        # a bare error -- so it asks here, and this is what tells a full server
        # apart from one that has gone away (see connect() in js/core.js).
        payload["streams_full"] = self.server.streams_full
        return payload

    def _serve_library(self) -> None:
        """Send the films the video database holds."""
        if not (self.server.offer_library and self.server.allow_control):
            # Off in the settings, or a box that will not be told what to play:
            # either way there is no card, and saying so is better than
            # answering with a list nothing can be done with.
            self._send_error_json(HTTPStatus.FORBIDDEN, "library disabled")
            return
        try:
            payload = library.movies()
        except Exception as exc:
            _log(f"reading the video database failed: {exc}", xbmc.LOGWARNING)
            self._send_error_json(HTTPStatus.SERVICE_UNAVAILABLE,
                                  "library unavailable")
            return
        self._send_listing(payload)

    def _start_film(self, payload: dict) -> None:
        """Put a film, or one episode of a series, on the television.

        One route for both because it is one act: something in the library is
        being started.  Which of the two it is, is which id the body carries --
        a series itself is never named here, because a series is not a thing
        that can be played.
        """
        # False asks for the title from the beginning, past any point the
        # library holds to resume it from; anything else resumes as before.
        resume = payload.get("resume") is not False
        episode_id = payload.get("episodeid")
        if episode_id is not None:
            if not self.server.offer_series:
                self._send_error_json(HTTPStatus.FORBIDDEN, "library disabled")
                return
            if not library.play_episode(episode_id, resume):
                self._send_error_json(HTTPStatus.BAD_REQUEST, "playback failed")
                return
            _log(f"episode {episode_id} started from {self.client_address[0]}")
            self._send_json({"ok": True, "episodeid": episode_id})
            return

        if not self.server.offer_library:
            self._send_error_json(HTTPStatus.FORBIDDEN, "library disabled")
            return
        movie_id = payload.get("movieid")
        if not library.play(movie_id, resume):
            self._send_error_json(HTTPStatus.BAD_REQUEST, "playback failed")
            return
        _log(f"film {movie_id} started from {self.client_address[0]}")
        # Nothing is pushed from here: the producer rebuilds five times a
        # second and the page learns the film is on from the next snapshot,
        # the same way it learns about one started from the remote control.
        self._send_json({"ok": True, "movieid": movie_id})

    def _mark_watched(self, payload: dict) -> None:
        """Mark a film, a series or one episode of one as seen or unseen.

        Which of the three it is, is which id the body carries, the same as
        ``/api/play``; ``watched`` says which way.  Behind the same settings as
        the shelf the title came off: a box that offers no series has handed
        out no series to be marked.
        """
        watched = payload.get("watched")
        if not isinstance(watched, bool):
            self._send_error_json(HTTPStatus.BAD_REQUEST, "watched required")
            return
        for key, kind, offered in (
                ("movieid", "movie", self.server.offer_library),
                ("tvshowid", "tvshow", self.server.offer_series),
                ("episodeid", "episode", self.server.offer_series)):
            item_id = payload.get(key)
            if item_id is None:
                continue
            if not offered:
                self._send_error_json(HTTPStatus.FORBIDDEN, "library disabled")
                return
            if not library.set_watched(kind, item_id, watched):
                self._send_error_json(HTTPStatus.BAD_REQUEST, "update failed")
                return
            self._send_json({"ok": True, key: item_id, "watched": watched})
            return
        self._send_error_json(HTTPStatus.BAD_REQUEST, "no title named")

    def _clear_resume(self, payload: dict) -> None:
        """Forget where a film or one episode got to, leaving it unwatched or
        watched as it was.  A series has no resume point of its own."""
        for key, kind, offered in (
                ("movieid", "movie", self.server.offer_library),
                ("episodeid", "episode", self.server.offer_series)):
            item_id = payload.get(key)
            if item_id is None:
                continue
            if not offered:
                self._send_error_json(HTTPStatus.FORBIDDEN, "library disabled")
                return
            if not library.clear_resume(kind, item_id):
                self._send_error_json(HTTPStatus.BAD_REQUEST, "update failed")
                return
            self._send_json({"ok": True, key: item_id})
            return
        self._send_error_json(HTTPStatus.BAD_REQUEST, "no title named")

    def _serve_series(self) -> None:
        """Send the series the video database holds."""
        if not (self.server.offer_series and self.server.allow_control):
            self._send_error_json(HTTPStatus.FORBIDDEN, "library disabled")
            return
        try:
            payload = library.shows()
        except Exception as exc:
            _log(f"reading the video database failed: {exc}", xbmc.LOGWARNING)
            self._send_error_json(HTTPStatus.SERVICE_UNAVAILABLE,
                                  "library unavailable")
            return
        self._send_listing(payload)

    def _serve_episodes(self) -> None:
        """Send the episodes of one series.

        Asked for only when somebody opens that series, which is why it is a
        route of its own rather than part of the shelf: a house with ninety
        series in it would otherwise be sending every episode of all of them to
        draw a wall of ninety posters.
        """
        if not (self.server.offer_series and self.server.allow_control):
            self._send_error_json(HTTPStatus.FORBIDDEN, "library disabled")
            return
        show = (parse_qs(urlparse(self.path).query).get("tvshowid") or [""])[0]
        try:
            payload = library.episodes(show)
        except Exception as exc:
            _log(f"reading the video database failed: {exc}", xbmc.LOGWARNING)
            self._send_error_json(HTTPStatus.SERVICE_UNAVAILABLE,
                                  "library unavailable")
            return
        if payload is None:
            # A series that is not on the shelf the page was drawn from: the
            # library moved under it, and the page reads the shelf again.
            self._send_error_json(HTTPStatus.NOT_FOUND, "no such series")
            return
        self._send_listing(payload)

    def _serve_continue(self) -> None:
        """Send the films and episodes left half-watched, newest first.

        Whichever halves the box offers: a film is on the row only where the
        film shelf is, and an episode only where the series shelf is, because
        a press on one starts it and starting it needs that shelf's setting.
        """
        films = self.server.offer_library
        series = self.server.offer_series
        if not ((films or series) and self.server.allow_control):
            self._send_error_json(HTTPStatus.FORBIDDEN, "library disabled")
            return
        try:
            payload = library.continuing(films=films, series=series)
        except Exception as exc:
            _log(f"reading the video database failed: {exc}", xbmc.LOGWARNING)
            self._send_error_json(HTTPStatus.SERVICE_UNAVAILABLE,
                                  "library unavailable")
            return
        self._send_listing(payload)

    def _send_listing(self, payload: dict) -> None:
        """Send one of the library's lists, under its own tag.

        A validator rather than the whole list every time: the tag changes only
        when the library does, so a phone that opens the page twice in an
        evening is answered the second time with an empty 304.  Which matters
        here more than anywhere else on this server, because these are the
        answers whose size grows with somebody's collection.
        """
        etag = f'"{payload["tag"]}"'
        if self._holds(etag):
            self._send_unchanged(etag, _STATIC_CACHE)
            return
        self._send_json(payload, etag=etag, cache=_STATIC_CACHE)

    def _serve_art(self) -> None:
        """Send the poster or the fanart of what is playing, or of one of the
        films, series or episodes the library cards offer."""
        query = parse_qs(urlparse(self.path).query)
        kind = (query.get("kind") or [""])[0]
        if kind not in _ART_KINDS:
            self._send_error_json(HTTPStatus.NOT_FOUND, "no such artwork")
            return
        # Which of the three shelves the picture is off, if it is off one at
        # all: a request naming none of them is asking for what is playing.
        film    = (query.get("movieid") or [""])[0]
        show    = (query.get("tvshowid") or [""])[0]
        episode = (query.get("episodeid") or [""])[0]
        # The page hangs the picture's own tag on the address, so an answer
        # can be kept for as long as the browser likes: the next film asks a
        # different address rather than the same one twice.
        tag  = (query.get("v") or [""])[0]
        etag = f'"{tag}"' if tag else ""
        cache = _ART_CACHE if tag else "no-store"
        if etag and self._holds(etag):
            self._send_unchanged(etag, cache)
            return

        if film:
            found = self.server.library_artwork(film, kind)
        elif show:
            found = self.server.series_artwork(show, kind)
        elif episode:
            found = self.server.episode_artwork(episode, kind)
        else:
            found = self.server.artwork(kind)
        if found is None:
            # Not every film has a poster, and a library-less file has none at
            # all; the page hides the frame rather than showing a broken one.
            self._send_error_json(HTTPStatus.NOT_FOUND, "no artwork")
            return
        body, content_type = found
        self._send(HTTPStatus.OK, body, content_type,
                   (("ETag", etag),) if etag else (), cache=cache)

    def _serve_static(self, route: str) -> None:
        path, content_type = self.server.static_routes[route]
        found = self.server.static_files.get(path, content_type)
        if found is None:
            self._send_error_json(HTTPStatus.NOT_FOUND, "missing file")
            return
        body, packed, etag = found
        if self._holds(etag):
            self._send_unchanged(etag, _STATIC_CACHE)
            return
        extra = (("ETag", etag), ("Vary", "Accept-Encoding"))
        if packed is not None and "gzip" in self.headers.get("Accept-Encoding", ""):
            body = packed
            extra += (("Content-Encoding", "gzip"),)
        self._send(HTTPStatus.OK, body, content_type, extra, cache=_STATIC_CACHE)

    def _serve_stream(self) -> None:
        """Push snapshots as Server-Sent Events until the client leaves or the
        service shuts down."""
        if self.server.stop_event.is_set():
            # Shutting down: a stream opened now would be one more thread for
            # Kodi to wait on, and the page is told not to come straight back
            # for another (see the bye handler in js/core.js).
            self._send_json({"error": "shutting down", "retry_ms": 20000},
                            HTTPStatus.SERVICE_UNAVAILABLE)
            self.close_connection = True
            return
        if not self.server.claim_stream():
            # A slot frees the moment a forgotten tab is closed or its phone
            # locks (see the visibility handling in js/core.js), so the page is
            # told to come back in a second rather than backing off.
            self._send_json({"error": "too many streams"},
                            HTTPStatus.SERVICE_UNAVAILABLE)
            return
        try:
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            # Nothing between here and the browser may buffer a stream whose
            # point is that it arrives as it happens.
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self._stream_loop()
        except (OSError, ValueError):
            pass  # the client went away; nothing to report
        finally:
            self.server.release_stream()
            self.close_connection = True

    def _stream_loop(self) -> None:
        producer = self.server.producer
        stop     = self.server.stop_event
        seen     = -1
        # The last payload this connection was sent, which every delta after
        # it is measured against.  Per connection rather than per server: two
        # browsers can be at different points, and a page that has just
        # connected must be sent the whole thing whatever the others hold.
        sent: dict | None = None
        last_beat = time.monotonic()
        # A write to a client that has gone quiet must not hold the thread for
        # good; the timeout turns it into the OSError the caller treats as a
        # closed connection.  It is deliberately shorter than the heartbeat:
        # what is being bounded is the write, not the wait between them, and a
        # thread still writing when Kodi stops is a Kodi that hangs.
        self.connection.settimeout(_STREAM_WRITE_TIMEOUT)

        while not stop.is_set():
            snapshot = producer.wait_for(seen, _HEARTBEAT_INTERVAL)
            if stop.is_set():
                break
            now = time.monotonic()
            if snapshot is None:
                if now - last_beat >= _HEARTBEAT_INTERVAL:
                    last_beat = now
                    self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
                continue
            seen = snapshot.get("seq", 0)
            last_beat = now
            payload = dict(snapshot)
            payload["control"] = self.server.allow_control
            if sent is None:
                kind, frame = "state", payload
            else:
                kind, frame = "delta", _snapshot_delta(sent, payload)
            sent = payload
            data = json.dumps(frame, ensure_ascii=False)
            self.wfile.write(f"event: {kind}\ndata: {data}\n\n".encode("utf-8"))
            self.wfile.flush()

        # A parting frame so the page can say it is offline rather than
        # showing a dead connection.  It carries how long to stay away: the
        # server is going down with Kodi, and a reconnect landing in the
        # middle of that is a fresh thread for Kodi to wait on.
        self.wfile.write(b'event: bye\ndata: {"retry_ms": 20000}\n\n')
        self.wfile.flush()


class _Server(ThreadingHTTPServer):
    """Threading HTTP server carrying the dashboard's shared state."""

    daemon_threads      = True
    allow_reuse_address = True

    def __init__(self, address, producer: _Producer, stop_event: threading.Event,
                 token: str) -> None:
        super().__init__(address, _Handler)
        self.producer      = producer
        self.stop_event    = stop_event
        self.token         = token
        self.static_routes = _static_routes()
        self.static_files  = _StaticFiles()
        self.auth_read     = False
        self.allow_control = True
        self.offer_library = True
        self.offer_series  = True
        self._streams      = 0
        self._stream_lock  = threading.Lock()
        # Every thread this server has handed a connection to.  Kodi waits on
        # thread states, not on the daemon flag, so these have to be joined
        # before the service script returns rather than left to the
        # interpreter that Kodi never gets round to tearing down.
        self._workers      = set()
        self._worker_lock  = threading.Lock()
        # One picture per kind, kept between requests: every open tab asks for
        # the same poster, and it can be a megabyte off a share.
        self._art: dict[str, tuple[str, bytes, str]] = {}
        self._art_lock = threading.Lock()

    def verify_request(self, request, client_address) -> bool:
        """Turn away a connection once the shutdown has begun.

        Checked before the request is handed to a thread, so a page that
        reconnects while Kodi is stopping costs a closed socket rather than a
        new thread -- and Kodi's wait for the interpreter's threads can
        actually finish.
        """
        return not self.stop_event.is_set()

    def process_request_thread(self, request, client_address) -> None:
        worker = threading.current_thread()
        with self._worker_lock:
            self._workers.add(worker)
        try:
            super().process_request_thread(request, client_address)
        finally:
            with self._worker_lock:
                self._workers.discard(worker)

    def join_workers(self, timeout: float) -> int:
        """Wait for the request threads to finish, and report how many are
        still running when the time is up."""
        deadline = time.monotonic() + timeout
        with self._worker_lock:
            workers = list(self._workers)
        for worker in workers:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            worker.join(remaining)
        return sum(1 for worker in workers if worker.is_alive())

    def refresh_settings(self, addon=None) -> None:
        """Re-read the settings a request consults, so toggling one applies
        without restarting the server."""
        addon = addon or _addon()
        self.auth_read     = addon.getSetting("web_auth_read") == "true"
        self.allow_control = addon.getSetting("web_allow_control") == "true"
        self.offer_library = addon.getSetting("web_library") == "true"
        self.offer_series  = addon.getSetting("web_series") == "true"

    def artwork(self, kind: str) -> tuple[bytes, str] | None:
        """The artwork bytes and type for ``kind``, or None when there is none.

        Read once per picture rather than once per request: the film only
        changes with the film.  The read happens outside the lock, so a poster
        coming off a slow share holds nothing else up -- two requests racing
        for the same new picture read it twice and agree on the answer.
        """
        path = art_path(kind)
        if not path:
            return None

        with self._art_lock:
            cached = self._art.get(kind)
            if cached is not None and cached[0] == path:
                return cached[1], cached[2]

        source = _unwrap_image_url(path)
        data = _read_art(source)
        if data is None and source != path:
            data = _read_art(path)   # an address only Kodi's VFS understands
        if data is None:
            return None

        content_type = _art_type(source)
        with self._art_lock:
            self._art[kind] = (path, data, content_type)
        return data, content_type

    def library_artwork(self, movie_id: str, kind: str) -> tuple[bytes, str] | None:
        """The poster of one of the library's films, or None.

        Nothing is held here, unlike the playing title's own artwork: a card
        of a thousand posters is a thousand pictures, and keeping them would
        cost the add-on more memory than everything else it does put together.
        The browser is the one that keeps them, and it keeps them well -- the
        address carries the picture's own tag and is answered with a week and
        an immutable, so each poster crosses the network once (see
        _ART_CACHE).  A card only asks for the posters it is showing anyway:
        the rest are fetched as they are scrolled to.
        """
        if not (self.offer_library and self.allow_control):
            return None
        try:
            path = library.art_path(int(movie_id), kind)
        except (TypeError, ValueError):
            return None
        return self._shelf_art(path)

    def series_artwork(self, show_id: str, kind: str) -> tuple[bytes, str] | None:
        """The poster of one of the series on the shelf, or None."""
        if not (self.offer_series and self.allow_control):
            return None
        return self._shelf_art(library.show_art_path(show_id, kind))

    def episode_artwork(self, episode_id: str, kind: str) -> tuple[bytes, str] | None:
        """The still of one episode, or None.

        Only episodes of a series somebody has opened have a still to hand out:
        the rest have never been read, and an address for one of them cannot
        have reached a browser (see web/library.py).
        """
        if not (self.offer_series and self.allow_control):
            return None
        return self._shelf_art(library.episode_art_path(episode_id, kind))

    def _shelf_art(self, path: str) -> tuple[bytes, str] | None:
        """One picture off one of the library shelves, read small and not kept.

        Small because of what it is for: these are the tiles on the idle page,
        drawn a hundred and twenty pixels wide, and the file behind one is the
        poster the library scraped at full size.  Kodi's own smaller copy is
        asked for first and the original only last (see ``_art_sources``).

        Nothing is held here, unlike the playing title's own artwork: the
        browser keeps these far better than this could, and now has a great
        deal less of each to keep.
        """
        if not path:
            return None
        fallback = _art_type(_unwrap_image_url(path))
        for attempt, source in enumerate(_art_sources(path)):
            data = _read_art(source)
            if data is None:
                continue
            if attempt:
                # The cache had nothing, so this is the original going out at
                # whatever size the scraper fetched it.  One line per picture
                # in a debug log is what says a box is serving a wall the slow
                # way -- a cache that has just been cleared, or artwork Kodi
                # has never drawn.
                _log(f"no cached texture for {source}, sending the original")
            return data, _image_type(data, fallback)
        return None

    @property
    def streams_full(self) -> bool:
        with self._stream_lock:
            return self._streams >= _MAX_STREAMS

    def claim_stream(self) -> bool:
        with self._stream_lock:
            if self._streams >= _MAX_STREAMS:
                return False
            self._streams += 1
            return True

    def release_stream(self) -> None:
        with self._stream_lock:
            self._streams = max(0, self._streams - 1)

    def handle_error(self, request, client_address) -> None:
        """A client that hangs up mid-response is routine and stays at debug;
        anything else is a real fault and is logged with its traceback, since
        a swallowed one here would show up only as a dead connection."""
        exc = sys.exc_info()[1]
        if isinstance(exc, (BrokenPipeError, ConnectionResetError, TimeoutError)):
            _log(f"connection from {client_address[0]} ended early", xbmc.LOGDEBUG)
            return
        _log(f"request from {client_address[0]} failed:\n"
             f"{traceback.format_exc()}", xbmc.LOGERROR)


class WebDashboard:
    """Owns the server's lifecycle: start it, restart it when its settings
    change, stop it when Kodi shuts down."""

    def __init__(self) -> None:
        self._server: _Server | None = None
        self._thread: threading.Thread | None = None
        self._producer: _Producer | None = None
        self._stop: threading.Event | None = None
        self._port  = 0
        self._token = ""
        # Kodi saves its settings on the way out, and the settings callback
        # arrives on a thread of its own: without this lock a change landing
        # while the service is stopping could start the server back up behind
        # the shutdown and leave a listening socket nobody owns.
        self._lock  = threading.RLock()
        self._done  = False

    @property
    def running(self) -> bool:
        return self._server is not None

    def apply_settings(self) -> None:
        with self._lock:
            self._apply_settings()

    def _apply_settings(self) -> None:
        """Bring the server in line with the settings: start, stop, or restart
        it on a port or token change, and pick up the rest in place."""
        if self._done:
            # Stopped for good; a late settings callback must not undo that.
            return

        addon   = _addon()
        enabled = addon.getSetting("web_enabled") == "true"

        if not enabled:
            self.stop()
            return

        port  = configured_port(addon)
        token = ensure_token(addon)

        if self.running and (port != self._port or token != self._token):
            _log("port or token changed, restarting")
            self.stop()

        if not self.running:
            self.start(port, token)
        elif self._server is not None:
            self._server.refresh_settings(addon)

    def start(self, port: int, token: str) -> None:
        if self.running or self._done:
            return
        self._stop     = threading.Event()
        self._producer = _Producer(self._stop)
        try:
            server = _Server(("0.0.0.0", port), self._producer, self._stop, token)
        except OSError as exc:
            _log(f"cannot bind port {port}: {exc}", xbmc.LOGERROR)
            self._stop = None
            self._producer = None
            return

        server.refresh_settings()
        self._server = server
        self._port   = port
        self._token  = token
        self._producer.start()
        self._thread = threading.Thread(
            target=server.serve_forever,
            # Polled often enough that shutdown() returns promptly: this wait
            # is spent inside the five seconds Kodi gives the script to stop.
            kwargs={"poll_interval": 0.1},
            name="TinyPPI-web-server",
            daemon=True,
        )
        self._thread.start()
        _log(f"dashboard listening on {local_address(port)}")

    def stop(self, final: bool = False) -> None:
        """Close the server down and leave no thread of it running.

        Every step is guarded, and the ones that matter most come first: Kodi
        allows a service script five seconds to stop and then raises
        SystemExit in it, so anything skipped here is skipped for good.  What
        must not be skipped is closing the listening socket -- a socket still
        accepting is a browser reconnecting, and every reconnect is another
        thread for Kodi to wait on before it can finish shutting down.
        """
        with self._lock:
            if final:
                self._done = True

            server   = self._server
            thread   = self._thread
            producer = self._producer
            stop     = self._stop

            self._server   = None
            self._thread   = None
            self._producer = None
            self._stop     = None
            self._port     = 0
            self._token    = ""

            if server is None and producer is None:
                return
            _log("stopping dashboard")

            # First, and before anything that can block: the streams read this
            # between snapshots and unwind on their own, and the server reads
            # it in verify_request and stops taking connections.
            if stop is not None:
                stop.set()
            if producer is not None:
                producer.wake()

            if server is not None:
                # shutdown() ends the accept loop; server_close() drops the
                # listening socket.  The close is what stops new threads
                # appearing, so it runs even if the first call goes wrong.
                try:
                    server.shutdown()
                except Exception as exc:
                    _log(f"server shutdown failed: {exc}", xbmc.LOGWARNING)
                finally:
                    try:
                        server.server_close()
                    except Exception as exc:
                        _log(f"server close failed: {exc}", xbmc.LOGWARNING)

            # Then wait for the threads themselves.  Kodi's own wait for them
            # has no timeout, so a thread left running here is a Kodi that
            # never finishes shutting down; ours is bounded because by then
            # there is nothing further the add-on can do about it.
            if thread is not None:
                thread.join(timeout=_JOIN_TIMEOUT)
                if thread.is_alive():
                    _log("web server thread did not stop", xbmc.LOGWARNING)
            if producer is not None:
                producer.join(timeout=_JOIN_TIMEOUT)
                if producer.is_alive():
                    _log("snapshot producer did not stop", xbmc.LOGWARNING)
            if server is not None:
                left = server.join_workers(_JOIN_TIMEOUT)
                if left:
                    _log(f"{left} request thread(s) still running",
                         xbmc.LOGWARNING)
