# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (c) 2026 U3knOwn

"""The film list and starting a film."""

import xbmc
from web.library import cache, common
from web.library.common import log
from web.library.entries import ArtPaths, Film, FilmListing, Films
from web.values import Json, Unchecked, library_id

# Film properties the tiles need.  ``dateadded`` feeds the "recently added"
# row (see ``common.added``), read here so the row matches the wall; the
# genres and the stream details are what the page sorts and filters by; the
# ids find a film again from TMDb's side (see ``by_tmdb``).
_PROPERTIES = ("title", "year", "art", "runtime", "playcount", "resume",
               "ratings", "dateadded", "genre", "streamdetails", "uniqueid")


def catalogue() -> Films:
    """Return the films as ``{"movies": [...], "art": {...}, "tag": str}``.

    ``tag`` changes only with the list (for 304 answers).
    """
    return cache.lists.films.get()


def movies() -> FilmListing:
    """Return the film list for clients (without the art paths)."""
    held = catalogue()
    return {"movies": held["movies"], "count": len(held["movies"]),
            "tag": held["tag"]}


def by_tmdb() -> dict[int, Film]:
    """Return the library's films by their TMDb ids."""
    return catalogue()["tmdb"]


def art_path(movie_id: int, kind: str) -> str:
    """Return a film's raw artwork path from the cached list, or ''."""
    entry = catalogue()["art"].get(int(movie_id)) or {}
    return entry.get(kind, "")


def read() -> Films:
    """Read the film list from Kodi (the reader of ``cache.lists.films``)."""
    answer = common.rpc("VideoLibrary.GetMovies", {
        "properties": list(_PROPERTIES),
        # Kodi sorts by sort title, ignoring articles.
        "sort": {"method": "sorttitle", "order": "ascending",
                 "ignorearticle": True},
    })
    error = answer.get("error")
    if error:
        # No database, or one being upgraded: debug only, the page retries.
        log(f"VideoLibrary.GetMovies failed: {error}")
        return {"movies": [], "art": {}, "tmdb": {}, "tag": "none"}

    films: list[Film] = []
    art: ArtPaths = {}
    known: dict[int, Film] = {}
    for row in common.rows_of(answer, "movies"):
        film = _film(row, art)
        if film is not None:
            films.append(film)
            ident = common.tmdb_id(row)
            if ident is not None:
                known.setdefault(ident, film)

    log(f"{len(films)} films read from the video database", xbmc.LOGINFO)
    return {"movies": films, "art": art, "tmdb": known,
            "tag": f"{len(films):x}-{common.signature(films)}"}


def _film(row: Json, art: ArtPaths) -> Film | None:
    """Return a film's tile from its row, registering its art in *art*.

    None without an id or a title.
    """
    movie_id = row.get("movieid")
    if not isinstance(movie_id, int):
        return None
    title = common.clean_title(row)
    if not title:
        return None

    pictures = common.art_of(row)
    poster = common.picture(pictures, common.POSTER_KEYS)
    art[movie_id] = {"poster": poster,
                     "fanart": common.picture(pictures, common.FANART_KEYS)}

    film: Film = {"id": movie_id, "title": title, "poster": common.tag(poster)}
    _describe(film, row)
    return film


def _describe(film: Film, row: Json) -> None:
    """Add the optional fields Kodi has meaningful values for."""
    if (year := common.number(row, "year")) is not None:
        film["year"] = year
    if (duration := common.number(row, "runtime")) is not None:
        film["duration"] = duration
    if isinstance(row.get("playcount"), int) and row["playcount"] > 0:
        film["watched"] = True
    resume = common.resume_of(row.get("resume"))
    if resume:
        film["resume"] = resume
    common.rate(film, row.get("ratings"))
    added = common.added(row.get("dateadded"))
    if added:
        film["added"] = added
    _classify(film, row)


def _classify(film: Film, row: Json) -> None:
    """Add what the page sorts and filters by: genres and formats."""
    genres = common.names(row, "genre")
    if genres:
        film["genres"] = genres
    common.add_formats(film, row.get("streamdetails"))


def play(movie_id: Unchecked, resume: bool = True) -> bool:
    """Play a film and return whether Kodi accepted it.

    Resumes when a resume point exists, unless *resume* is False; the option
    is always explicit so Kodi does not ask on the TV.  JSON-RPC reports
    success, unlike a builtin.
    """
    wanted = library_id(movie_id)
    if not wanted:
        return False
    return common.open_item({"movieid": wanted},
                            common.resume_option(resume, lambda: _resume_point(wanted)),
                            f"film {wanted}")


def _resume_point(movie_id: int) -> int:
    for film in catalogue()["movies"]:
        if film["id"] == movie_id:
            return int(film.get("resume") or 0)
    return 0
