"""
overlay.py – Core logic for the TinyPPI overlay dialog and its entry points.

Imported by the root launcher (main.py).  Do not add sys.path manipulation
here — that is handled by main.py before this module is imported.
"""

import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import fonts  # noqa: F401 – imported for its side effect: installs skin fonts
import properties
from theme import apply_theme
from utils import (
    PROP_ACTIVE,
    PROP_DIALOG_MODE,
    PROP_RUNNING,
    clear_overlay_state,
    set_window_properties,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ADDON      = xbmcaddon.Addon()
_ADDON_PATH = _ADDON.getAddonInfo("path")

_dialog_lock = False

# Raise to True to allow launching on non-CoreELEC platforms (e.g. for testing).
_ALLOW_NON_COREELEC = False

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _is_coreelec() -> bool:
    """Return True when running on a CoreELEC installation."""
    if os.path.isdir("/etc/coreelec"):
        return True
    try:
        with open("/etc/os-release") as f:
            return any("coreelec" in line.lower() for line in f)
    except OSError:
        return False


def _notify_error(message_id: int) -> None:
    """Show a Kodi error notification using a localised string ID."""
    xbmcgui.Dialog().notification(
        "TinyPPI",
        _ADDON.getLocalizedString(message_id),
        xbmcgui.NOTIFICATION_ERROR,
        4000,
    )


def _set_overlay_state(home, dialog_mode: bool = False) -> None:
    """Publish the Home-window properties that mark TinyPPI as open."""
    set_window_properties(
        home,
        (
            (PROP_RUNNING, "true"),
            (PROP_ACTIVE, "true"),
        ),
    )

    if dialog_mode:
        home.setProperty(PROP_DIALOG_MODE, "true")
    else:
        home.clearProperty(PROP_DIALOG_MODE)


def _preflight(home, player, toggle_log: str) -> bool:
    """
    Run the environment and playback guards shared by both entry points.

    Returns True when the overlay may open.  Otherwise shows the appropriate
    error notification (or triggers the toggle-close action) and returns False.
    """
    if not _ALLOW_NON_COREELEC:
        if not _is_coreelec():
            _notify_error(32016)
            return False

        build_version = xbmc.getInfoLabel("System.BuildVersion")
        try:
            major_version = int(build_version.split(".")[0])
        except (ValueError, IndexError):
            _notify_error(32017)
            return False

        if major_version < 22:
            _notify_error(32016)
            return False

    skin_path = xbmcvfs.translatePath("special://skin/")
    if os.path.exists(os.path.join(skin_path, "720p")):
        _notify_error(32012)
        xbmc.log("TinyPPI: 720p skin detected – unsupported", xbmc.LOGWARNING)
        return False

    if not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
        return False

    if not player.isPlaying():
        return False

    if home.getProperty(PROP_RUNNING) == "true":
        xbmc.log(toggle_log, xbmc.LOGINFO)
        xbmc.executebuiltin("Action(Back)")
        return False

    return not _dialog_lock


def _elements_visible() -> str:
    """
    Return the "1"/"0" visibility flag for the header title, header icon and
    separator lines.

    These elements follow the background: they stay shown with any visible
    background and are hidden when the background is fully transparent
    (0 % opacity).
    """
    return "0" if _ADDON.getSettingInt("background_opacity") == 0 else "1"


def _release_overlay(home) -> None:
    """Briefly hold the re-entry lock, then clear the overlay state properties."""
    global _dialog_lock
    _dialog_lock = True
    xbmc.Monitor().waitForAbort(0.2)
    _dialog_lock = False

    clear_overlay_state(home)


# ---------------------------------------------------------------------------
# Overlay dialog
# ---------------------------------------------------------------------------

class TinyPPIDialog(xbmcgui.WindowXMLDialog):
    """
    Overlay window that displays live player information while a video is
    playing in fullscreen.

    The dialog auto-closes when playback stops or the user navigates away
    from the fullscreen video window.
    """

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._running   = False
        self._monitor   = xbmc.Monitor()
        self._opened_at = 0.0
        self._offset    = None

    # ------------------------------------------------------------------
    # Kodi callbacks

    def onInit(self) -> None:
        self._running   = True
        self._opened_at = time.time()

        # Publish properties first so the HDR type is known before the initial
        # position is applied (relevant when reopening during the same playback,
        # where the hdrprobe result is already cached).
        properties.update_properties(self)
        self._apply_position_offset()
        self._start_update_loop()

    def _apply_position_offset(self) -> None:
        """
        Shift the overlay content by the configured offsets.

        Origin is the default bottom-left layout: the horizontal offset moves
        the content to the right, the vertical offset moves it up.  100 % maps
        to the maximum travel that keeps the content on screen: 30.9 % / 28.1 %
        of the screen size.

        The horizontal offset only applies to SDR playback; for any HDR type
        (HDR10, HDR10+, HLG, Dolby Vision) the content stays left-aligned.  As
        the HDR type is detected asynchronously, this is re-applied each polling
        cycle so it settles once detection completes; the last applied position
        is cached so the (unchanged) common case skips the setPosition call.
        """
        max_x = 0.309
        max_y = 0.281
        offset_x = round(1920 * max_x * _ADDON.getSettingInt("offset_x") / 100)
        offset_y = -round(1080 * max_y * _ADDON.getSettingInt("offset_y") / 100)
        if xbmcgui.Window(10000).getProperty("TinyPPI.HdrType"):
            offset_x = 0
        if (offset_x, offset_y) == self._offset:
            return
        self._offset = (offset_x, offset_y)
        self.getControl(5000).setPosition(offset_x, offset_y)

    def onClick(self, control_id: int) -> None:
        self.close_dialog()

    def onAction(self, action: xbmcgui.Action) -> None:
        if time.time() - self._opened_at < 0.3:
            return
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self.close_dialog()

    # ------------------------------------------------------------------
    # Update loop

    def _start_update_loop(self) -> None:
        t = threading.Thread(target=self._update_loop, daemon=True)
        t.start()

    def _update_loop(self) -> None:
        player = xbmc.Player()

        while self._running and not self._monitor.abortRequested():
            if not player.isPlaying():
                break
            if not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)"):
                break

            properties.update_properties(self)
            self._apply_position_offset()

            if self._monitor.waitForAbort(1):
                break

        self.close_dialog()

    # ------------------------------------------------------------------
    # Close

    def close_dialog(self) -> None:
        self._running = False
        try:
            self.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------

def open_tinyppi() -> None:
    """
    Validate the environment and open the TinyPPI overlay window.

    Skips silently when:
    - Not running on CoreELEC (unless ``_ALLOW_NON_COREELEC`` is True).
    - Kodi build version is older than 22.
    - A 720p skin is active.
    - Fullscreen video is not currently active.
    - No media is playing.
    - The overlay is already open (acts as a toggle-close instead).
    """
    home   = xbmcgui.Window(10000)
    player = xbmc.Player()

    if not _preflight(home, player, "TinyPPI: Toggle close"):
        return

    elements_visible = _elements_visible()
    _set_overlay_state(home)
    set_window_properties(
        home,
        (
            ("TinyPPI.Filename", _ADDON.getSetting("filename")),
            (
                "TinyPPI.ShowL5Icon",
                "0" if _ADDON.getSetting("show_l5_icon") == "false" else "1",
            ),
            ("TinyPPI.ShowLine", elements_visible),
            ("TinyPPI.ShowHeaderTitle", elements_visible),
            ("TinyPPI.ShowHeaderIcon", elements_visible),
        ),
    )
    apply_theme(home, _ADDON)

    try:
        dialog = TinyPPIDialog(
            "script-tinyppi-main.xml",
            _ADDON_PATH,
            "Default",
            "1080i",
        )
        dialog.doModal()
        del dialog
    finally:
        _release_overlay(home)


def open_dialog_mode() -> None:
    """Open the VS10-mode selection dialog."""
    home   = xbmcgui.Window(10000)
    player = xbmc.Player()

    if not _preflight(home, player, "TinyPPI: Toggle close (dialog mode)"):
        return

    elements_visible = _elements_visible()
    _set_overlay_state(home, dialog_mode=True)
    set_window_properties(
        home,
        (
            ("TinyPPI.ShowLine", elements_visible),
            ("TinyPPI.ShowHeaderTitle", elements_visible),
            ("TinyPPI.ShowHeaderIcon", elements_visible),
        ),
    )
    apply_theme(home, _ADDON)

    try:
        from mode_select import open_dialog
        open_dialog()
    finally:
        _release_overlay(home)
