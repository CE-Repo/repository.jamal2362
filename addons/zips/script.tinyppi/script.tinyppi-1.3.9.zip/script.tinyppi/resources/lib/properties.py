"""
properties.py – Compute and publish Window properties for TinyPPI.

Call ``update_properties(window)`` once per polling interval from your
``WindowXMLDialog`` subclass.
"""

import re

import xbmc

from maps import (
    _AUDIO_CODEC_MAP,
    _CHANNELS_INPUT_MAP,
    _CHANNELS_MAP,
    _LANGUAGE_MAP,
    _VIDEO_CODEC_MAP,
)
from utils import _cond, _info, _clean
from helpers import (
    _normalize_fps,
    _format_fps,
    _read_hdr_status,
    _read_last_dovi_log_line,
    format_fps,
    get_fps_data,
    set_ui_position,
)
from dvinfo import (
    fetch_label,
    get_cm_version,
    get_l5_offsets,
    get_l6_rpu_mdl,
    get_l6_rpu_max_cll_fall,
    get_source_hdr_format,
    is_status_label,
    source_detection_pending,
    source_is_dv,
)

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

# Previous /proc/stat snapshot for delta-based CPU usage calculation.
_cpu_prev: tuple[int, int] | None = None

# ---------------------------------------------------------------------------
# Video properties
# ---------------------------------------------------------------------------

def get_VideoDecoderVar() -> str:
    """Return 'HW' or 'SW' based on the active video decoder type."""
    return "HW" if _cond("Player.Process(videohwdecoder)") else "SW"


def get_VideoDecoderExtVar() -> str:
    """Return 'Hardware' or 'Software' based on the active video decoder type."""
    return "Hardware" if _cond("Player.Process(videohwdecoder)") else "Software"


def get_VideoPixelFormatVar() -> str:
    """
    Parse ``amlogic.pixformat`` and return a human-readable string such as
    ``10-bit (YUV 4:2:0)`` or ``8-bit, RGB``.
    """
    val = _info("Player.Process(amlogic.pixformat)").strip()
    if not val:
        return ""

    match = re.search(
        r"(\d+)-bit\s*,\s*(RGB|YUV420|YUV422|YUV444)",
        val,
        re.IGNORECASE,
    )
    if not match:
        return val

    bits, fmt = match.groups()
    fmt = fmt.upper()

    if fmt == "RGB":
        return f"{bits}-bit, RGB"

    yuv_map = {
        "YUV420": "YUV 4:2:0",
        "YUV422": "YUV 4:2:2",
        "YUV444": "YUV 4:4:4",
    }
    return f"{bits}-bit ({yuv_map.get(fmt, fmt)})"


def get_DisplayModeVar() -> str:
    """
    Parse ``amlogic.displaymode`` and return a compact string like
    ``1080p 23.976Hz``.
    """
    val = _info("Player.Process(amlogic.displaymode)").strip()
    if not val:
        return ""

    compact = re.sub(r"\s+",  "",  val)
    match = re.match(
        r"(\d+(?:x\d+)?)(p|i)(\d+(?:\.\d+)?)[Hh][Zz]",
        compact,
        re.IGNORECASE,
    )
    if not match:
        return val

    res, scan, raw_fps = match.groups()
    return f"{res}{scan} {_normalize_fps(raw_fps)}Hz"


def get_VideoResolutionVar() -> str:
    """Return a string like ``1920x1080p 23.976FPS``."""
    width  = _clean(_info("Player.Process(videowidth)"))
    height = _clean(_info("Player.Process(videoheight)"))
    scan   = _clean(_info("Player.Process(videoscantype)"))
    fps    = _clean(_info("Player.Process(videofps)"))

    if not width or not height:
        return ""

    return f"{width}x{height}{scan} {_format_fps(fps)}FPS"


def get_VideoBitrateMBVar() -> str:
    """Convert the video bitrate from kb/s to Mb/s and return a display string."""
    bitrate = _clean(_info("VideoPlayer.VideoBitrate"))
    try:
        mbit = float(bitrate) / 1000.0
    except (TypeError, ValueError):
        return ""

    value = f"{mbit:.2f}".rstrip("0").rstrip(".")
    return f"{value} Mb/s"


def get_VideoLiveBitrateVar() -> str:
    """Format live video bitrate without failing on malformed Kodi values."""
    bitrate = _info("Player.Process(videolivebitrate)").strip()

    if not bitrate:
        return ""

    # Match a valid decimal number, not arbitrary combinations such as ".".
    match = re.search(r"\d+(?:[.,]\d+)?|[.,]\d+",  bitrate)
    if not match:
        return ""

    try:
        value = float(match.group(0).replace(",",  "."))
    except (TypeError, ValueError):
        return ""

    if value < 0:
        return ""

    if value < 1.0:
        return f"{int(round(value * 1000))} Kb/s"

    formatted = f"{value:.2f}".rstrip("0").rstrip(".")
    return f"{formatted} Mb/s"


def get_VideoCodecVar() -> str:
    """Return the mapped display name for the current video codec."""
    codec = _info("VideoPlayer.VideoCodec").lower().strip()
    if not codec:
        return ""
    return _VIDEO_CODEC_MAP.get(codec, codec.upper())


# ---------------------------------------------------------------------------
# HDR / Dolby Vision properties
# ---------------------------------------------------------------------------

def _format_dovi_profile(text: str) -> str:
    """
    Build a Dolby Vision profile string (incl. coloured FEL/MEL tag) from a
    DV decoder log line, e.g. ``Dolby Vision Profile 7 [COLOR lightgreen]FEL[/COLOR]``.

    Falls back to ``Dolby Vision Profile 8.1`` when no profile number is found.
    """
    prof = re.search(r"profile\s*(\d+)",  text)
    profile_num = prof.group(1) if prof else "8"
    if profile_num in ("0",  "8"):
        profile_num = "8.1"

    if "minimum enhancement layer" in text:
        return f"Dolby Vision Profile {profile_num} [COLOR orange]MEL[/COLOR]"
    if "full enhancement layer" in text:
        return f"Dolby Vision Profile {profile_num} [COLOR lightgreen]FEL[/COLOR]"
    return f"Dolby Vision Profile {profile_num}"


def _plain(value: str) -> str:
    """Strip ``[COLOR ...]`` tags for content comparisons (display keeps them)."""
    return re.sub(r"\[/?COLOR[^\]]*\]",  "",  value).strip()


def get_HdmiHdrStatusVar() -> str:
    """
    Return the non-Dolby HDR format currently active on the HDMI output:
    ``HDR10+``, ``HLG``, ``HDR10``, or ``SDR``.

    Returns an empty string when Dolby Vision is active or the sysfs node
    is unavailable.
    """
    status = _read_hdr_status()
    if not status or "dolby" in status:
        return ""

    if "hdr10plus" in status or "hdr10+" in status:
        return "HDR10+"
    if "hlg" in status:
        return "HLG"
    if "hdr10" in status:
        return "HDR10"
    if "sdr" in status:
        return "SDR"
    return ""


def get_DoviProfileVar() -> str:
    """
    Return the Dolby Vision profile string active on the HDMI *output*.

    The Amlogic VS10 / DV tunnel always emits Dolby Vision Profile 8.1 over
    HDMI, regardless of the source profile (5/7/8) and whether the source was
    DV at all (HDR10/SDR -> DV conversions included).  It is therefore fixed
    here rather than parsed from the decoder log line, which describes the
    *source* and may even be stale from a previously played DV file.

    Returns an empty string when DV is not active on the output.
    """
    if "dolby" not in _read_hdr_status():
        return ""
    return "Dolby Vision Profile 8.1"


def get_SourceHdrVar() -> str:
    """
    Return the *source* HDR format.

    Prefers Kodi's own stream hint (reliable for local / Direct-Play), and
    only falls back to the addon's per-file probe for plugin sources
    (PM4K/Plex), where VideoPlayer.HdrType is empty for DV, HDR10 and SDR
    alike — which the old skin logic mistook for "SDR".
    """
    hdr = _info("VideoPlayer.HdrType").lower().strip()

    # 1. Dolby Vision *source*?  Only trust source-side evidence:
    #    dovi_tool confirmed a real RPU, or Kodi reports the stream as
    #    dolbyvision.  source_is_dv() is value-based, so a 'fetching' status is
    #    not mistaken for a DV result.  NOT the HDMI HDR status — that is the
    #    OUTPUT and stays "dolby" even when VS10 converts HDR10/SDR up to DV.
    if source_is_dv() or hdr == "dolbyvision":
        return _format_dovi_profile(_read_last_dovi_log_line())

    # 2. Non-DV HDR. Trust Kodi's hint when present; otherwise probe the
    #    source colour transfer (PM4K/Plex with empty HdrType).
    mapping = {"hdr10plus": "HDR10+", "hdr10": "HDR10", "hlg": "HLG"}
    if hdr in mapping:
        return mapping[hdr]

    return get_source_hdr_format() or "SDR"


def format_output_mode(source: str, output: str) -> str:
    """
    Build the ``source -> output`` string for the Output-mode line.

    The arrow marks a real conversion only.  Native Dolby Vision playback
    (DV source -> DV output) is collapsed to a single entry even though the
    source profile (e.g. 7 FEL) differs from the 8.1 tunnel output, because no
    format conversion takes place.  Identical non-DV formats collapse too; on
    collapse the variant carrying the coloured FEL/MEL tag is kept.
    """
    if not output:
        return source

    source_dv = "Dolby Vision" in _plain(source)
    output_dv = "Dolby Vision" in _plain(output)

    # DV in, DV out -> native playback, not a conversion.
    if source_dv and output_dv:
        return source

    # Same non-DV format on both sides -> single entry.
    if _plain(source) == _plain(output):
        return source if "[COLOR" in source else output

    return f"{source} -> {output}"


def _compose_output_mode(source: str, output: str) -> str:
    """
    Build the Output-mode string, showing a 'fetching' placeholder while the
    real source is still being detected.

    When the HDMI output already indicates HDR/DV but the source has not yet
    resolved (it would briefly fall back to SDR), rendering ``SDR -> HDR10`` or
    ``SDR -> Dolby Vision Profile 8.1`` would be wrong.  In that window show the
    fetching label instead.  Plain SDR output is exempt — there is nothing to
    resolve, so it never shows a placeholder.
    """
    if (output
            and _plain(output) != "SDR"
            and "Dolby Vision" not in _plain(source)
            and _plain(source) != _plain(output)
            and source_detection_pending()):
        return fetch_label()
    return format_output_mode(source, output)


def get_OutputModeVar() -> str:
    """Thin wrapper: build the Output-mode string from the current state."""
    return _compose_output_mode(
        get_SourceHdrVar(),
        get_HdmiHdrStatusVar() or get_DoviProfileVar(),
    )


def get_DoviFelVar() -> str:
    """Return ``'FEL'`` when a full-enhancement-layer DV stream is active, else ``''``."""
    if "dolby" not in _read_hdr_status():
        return ""
    text = _read_last_dovi_log_line()
    return "FEL" if "full enhancement layer" in text else ""


def get_DoviTunnelVar() -> str:
    """
    Read Dolby Vision mode from sysfs.

    Returns:
        "DV Tunnel" if the value is 1.
        "" otherwise.
    """
    path = "/sys/module/aml_media/parameters/dolby_vision_mode"

    try:
        with open(path, encoding="utf-8",  errors="ignore") as f:
            value = f.read().strip()
    except OSError:
        return ""

    return "DV Tunnel" if value == "1" else ""


def get_DoviCmVersionVar() -> str:
    """
    Return the source Dolby Vision Content-Mapping version
    (``'CMv2.9'`` or ``'CMv4.0'``), a localized status while/after detection,
    or ``''`` when the source is not Dolby Vision.

    Detection runs once per file in a background thread (see dvinfo.py), so
    this call never blocks the polling loop.
    """
    return get_cm_version()


def get_DoviLevel5OffsetsVar() -> str:
    """
    Return the source Dolby Vision Level 5 active-area offsets, a localized
    status while/after detection, or ``''`` when the source is not Dolby Vision.
    """
    return get_l5_offsets()


def get_DoviLevel6RpuMdlVar() -> str:
    """
    Return the source Dolby Vision Level 6 RPU mastering-display luminance, a
    localized status while/after detection, or ``''`` when the source is not
    Dolby Vision.
    """
    return get_l6_rpu_mdl()


def get_DoviLevel6RpuMaxCllFallVar() -> str:
    """
    Return the source Dolby Vision Level 6 RPU MaxCLL/MaxFALL, a localized
    status while/after detection, or ``''`` when the source is not Dolby Vision.
    """
    return get_l6_rpu_max_cll_fall()


def _with_unit(value: str, unit: str) -> str:
    """Append a unit only to real metadata values, not status labels."""
    if not value or is_status_label(value):
        return value
    return f"{value} {unit}"


# ---------------------------------------------------------------------------
# Amlogic EOFT / gamut
# ---------------------------------------------------------------------------

def get_ModeVar() -> str:
    """Return the first token of ``amlogic.eoft_gamut`` (the mode field)."""
    parts = _info("Player.Process(amlogic.eoft_gamut)").split()
    return parts[0] if parts else ""


def get_GamutVar() -> str:
    """Return the second token of ``amlogic.eoft_gamut`` (the gamut field)."""
    parts = _info("Player.Process(amlogic.eoft_gamut)").split()
    return parts[1] if len(parts) > 1 else ""


# ---------------------------------------------------------------------------
# Vdec bitrate  (Amlogic kernel sysfs)
# ---------------------------------------------------------------------------

def get_VdecBitrateVar() -> tuple[str, str]:
    """
    Read the hardware decoder bitrate from sysfs and return a
    ``(value, unit)`` tuple, e.g. ``('23.45', 'Mb/s')`` or ``('850', 'Kb/s')``.

    Returns ``('', '')`` when the node is unavailable or contains no data.
    """
    path = "/sys/class/vdec/vdec_status"
    try:
        with open(path, encoding="utf-8",  errors="ignore") as f:
            data = f.read()
    except OSError:
        return "",  ""

    matches = re.findall(r"bit rate\s*:\s*(\d+)\s*kbps",  data, re.IGNORECASE)
    if not matches:
        return "",  ""

    kbps = max(float(m) for m in matches)
    if kbps <= 0:
        return "",  ""

    if kbps < 1000:
        return f"{kbps:.0f}",  "Kb/s"

    mbps = kbps / 1000.0
    return f"{mbps:.2f}".rstrip("0").rstrip("."), "Mb/s"


# ---------------------------------------------------------------------------
# Audio properties
# ---------------------------------------------------------------------------

def get_AudioBitrateKBVar() -> str:
    """Convert the audio bitrate from kb/s to Kb/s and return a display string."""
    bitrate = _clean(_info("VideoPlayer.AudioBitrate"))
    try:
        kbps = int(float(bitrate))
    except (TypeError, ValueError):
        return ""
    return f"{kbps:,} Kb/s".replace(",",  ".")


def get_AudioLiveBitrateVar() -> str:
    """Return audio live bitrate with dot instead of comma."""
    bitrate = _info("Player.Process(audiolivebitrate)")
    if not bitrate:
        return ""

    return str(bitrate).replace(",",  ".")


def get_AudioCodecVar() -> str:
    """Return the mapped display name for the current audio codec."""
    codec = _info("VideoPlayer.AudioCodec")
    if not codec:
        return xbmc.getLocalizedString(13205)
    return _AUDIO_CODEC_MAP.get(codec, codec)


def get_AudioCodecSpatialVar() -> str:
    """Return the spatial-audio suffix: ``'(Atmos)'``, ``'(IMAX Enhanced)'``, or ``''``."""
    codec = _info("VideoPlayer.AudioCodec")
    if codec == "dtshd_ma_x_imax":
        return "(IMAX Enhanced)"
    if codec in ("eac3_ddp_atmos",  "truehd_atmos"):
        return "(Atmos)"
    return ""


def get_AudioChannelsVar() -> str:
    """Return the surround layout string for the current channel count, e.g. ``'7.1'``."""
    try:
        ch = int(_info("VideoPlayer.AudioChannels"))
        return _CHANNELS_MAP.get(ch, "")
    except (ValueError, TypeError):
        return ""


def get_AudioChannelsInputVar() -> str:
    """Return the full speaker-label string for the current channel count."""
    try:
        ch = int(_info("VideoPlayer.AudioChannels"))
        return _CHANNELS_INPUT_MAP.get(ch, xbmc.getLocalizedString(13205))
    except (ValueError, TypeError):
        return xbmc.getLocalizedString(13205)


def get_AudioSampleRateVar() -> str:
    """Convert the audio sample rate from Hz to kHz and return a display string."""
    samplerate = _clean(_info("Player.Process(audiosamplerate)"))
    try:
        hz = float(samplerate)
    except (TypeError, ValueError):
        return ""
    khz = hz / 1000.0
    return f"{int(khz)} kHz" if khz.is_integer() else f"{khz:.1f} kHz"


def get_AudioNameVar() -> str:
    """Return the native language name for the active audio track language code."""
    code = _info("VideoPlayer.AudioLanguage").lower().strip()
    return _LANGUAGE_MAP.get(code, "") if code else ""


# ---------------------------------------------------------------------------
# Subtitle properties
# ---------------------------------------------------------------------------

def get_SubtitleVar() -> str:
    """
    Return the active subtitle language.
    """
    lang = _info("VideoPlayer.SubtitlesLanguage").strip()

    if not lang:
        return _info("VideoPlayer.SubtitleLanguageEx")

    return lang.upper()


def get_SubtitleNameInfoVar() -> str:
    """
    Return the active subtitle track name formatted for display.
    """
    name = _info("VideoPlayer.SubtitleName").strip()

    if not name:
        return ""

    return f"| {name}"

# ---------------------------------------------------------------------------
# System properties
# ---------------------------------------------------------------------------

def get_CpuUsageVar() -> str:
    """
    Parse ``System.CpuUsage`` and return a zero-padded, pipe-separated
    per-core usage string, e.g. ``'12 | 08 | 15 | 10'``.
    """
    raw = _info("System.CpuUsage")
    if not raw:
        return ""

    matches = re.findall(r"#\d+:\s*([\d.]+)%",  raw)
    if not matches:
        return raw

    values = []
    for val in matches:
        try:
            values.append(f"{int(float(val)):02d}")
        except ValueError:
            continue
    return " | ".join(values)


def get_CpuTopUsageVar() -> str:
    """
    Compute total CPU usage from consecutive /proc/stat snapshots and return
    it as a percentage string, e.g. ``'34%'``.

    Returns an empty string on the very first call (no previous sample yet)
    or when /proc/stat cannot be read.
    """
    global _cpu_prev

    try:
        with open("/proc/stat") as f:
            line = f.readline()
    except OSError:
        return ""

    parts = line.split()
    if len(parts) < 8:
        return ""

    try:
        user, nice, system, idle, iowait, irq, softirq = (int(parts[i]) for i in range(1, 8))
    except ValueError:
        return ""

    idle_all = idle + iowait
    total    = user + nice + system + idle_all + irq + softirq
    busy     = total - idle_all

    if _cpu_prev is None:
        _cpu_prev = (busy, total)
        return ""

    prev_busy, prev_total = _cpu_prev
    _cpu_prev = (busy, total)

    diff_total = total - prev_total
    if diff_total <= 0:
        return ""

    usage = (busy - prev_busy) / diff_total * 100.0
    return f"{usage:.0f}%"


def get_CpuTemperatureProgressVar() -> str:
    """
    Map System.CPUTemperature to a progress value from 0 to 100.

    Celsius:    0–115 °C
    Fahrenheit: 32–239 °F
    """
    raw = _info("System.CPUTemperature").strip()
    if not raw:
        return 0.0

    match = re.search(r"-?\d+(?:[.,]\d+)?",  raw)
    if not match:
        return 0.0

    try:
        temperature = float(match.group(0).replace(",",  "."))
    except ValueError:
        return 0.0

    if re.search(r"(?:°\s*)?F\b",  raw, re.IGNORECASE):
        minimum = 32.0
        maximum = 230.0
    else:
        minimum = 0.0
        maximum = 110.0

    temperature = max(minimum, min(temperature, maximum))

    return (
        (temperature - minimum)
        / (maximum - minimum)
        * 100.0
    )
    

def get_queue_level(info_label: str) -> float:
    """
    Read a queue level from Kodi.

    Kodi may report a completely filled queue as only 99%.
    Values of 99 or higher are therefore treated as 100%.
    """
    raw = _info(info_label).strip()

    match = re.search(r"-?\d+(?:[.,]\d+)?",  raw)
    if not match:
        return 0

    try:
        value = float(match.group(0).replace(",",  "."))
    except ValueError:
        return 0

    value = max(0, min(value, 100))

    if value >= 99:
        return 100

    return value


def format_queue_level(value: float) -> str:
    """Queue-Level ohne unnötige Nachkommastellen formatieren."""
    if value.is_integer():
        return str(int(value))

    return f"{value:.1f}".rstrip("0").rstrip(".")

# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def update_properties(window) -> None:
    """
    Compute all player properties and publish them to the given window object
    via ``setProperty``.

    Call this from ``onInit()`` and from a polling loop in your
    ``WindowXMLDialog`` subclass.
    """
    set_ui_position(window)

    video_queue = get_queue_level("Player.Process(videoqueuelevel)")
    video_queue_data = get_queue_level("Player.Process(videoqueuedatalevel)")
    audio_queue = get_queue_level("Player.Process(audioqueuelevel)")
    audio_queue_data = get_queue_level("Player.Process(audioqueuedatalevel)")
    bitrate_value, bitrate_unit = get_VdecBitrateVar()
    fps_info_text, fps_out_text = format_fps()

    l5_offsets = get_DoviLevel5OffsetsVar()
    l5_offsets_icon_visible = (
        "true"
        if l5_offsets and not is_status_label(l5_offsets)
        else "false"
    )

    l6_rpu_mdl = _with_unit(get_DoviLevel6RpuMdlVar(), "cd/m²")
    l6_rpu_max_cll_fall = _with_unit(get_DoviLevel6RpuMaxCllFallVar(), "cd/m²")

    # Compute the source format once (may run ffprobe) and reuse it for the
    # combined Output-mode string to avoid a second per-poll detection pass.
    source_hdr  = get_SourceHdrVar()
    hdmi_output = get_HdmiHdrStatusVar() or get_DoviProfileVar()
    output_mode = _compose_output_mode(source_hdr, hdmi_output)

    window.setProperty("VideoDecoderVar",              get_VideoDecoderVar())
    window.setProperty("VideoDecoderExtVar",           get_VideoDecoderExtVar())
    window.setProperty("VideoPixelFormatVar",          get_VideoPixelFormatVar())
    window.setProperty("DisplayModeVar",               get_DisplayModeVar())
    window.setProperty("VideoResolutionVar",           get_VideoResolutionVar())
    window.setProperty("VideoBitrateMBVar",            get_VideoBitrateMBVar())
    window.setProperty("VideoLiveBitrateVar",          get_VideoLiveBitrateVar())
    window.setProperty("VideoCodecVar",                get_VideoCodecVar())
    window.setProperty("HdmiHdrStatusVar",             get_HdmiHdrStatusVar())
    window.setProperty("DoviProfileVar",               get_DoviProfileVar())
    window.setProperty("SourceHdrVar",                 source_hdr)
    window.setProperty("OutputModeVar",                output_mode)
    window.setProperty("DoviFelVar",                   get_DoviFelVar())
    window.setProperty("DoviTunnelVar",                get_DoviTunnelVar())
    window.setProperty("DoviCmVersionVar",             get_DoviCmVersionVar())
    window.setProperty("DoviLevel5OffsetsVar",         l5_offsets)
    window.setProperty("DoviLevel5OffsetsIconVisible", l5_offsets_icon_visible,)
    window.setProperty("DoviLevel6RpuMdlVar",          l6_rpu_mdl)
    window.setProperty("DoviLevel6RpuMaxCllFallVar",   l6_rpu_max_cll_fall)
    window.setProperty("ModeVar",                      get_ModeVar())
    window.setProperty("GamutVar",                     get_GamutVar())
    window.setProperty("VdecBitrate",                  bitrate_value)
    window.setProperty("VdecBitrateUnit",              bitrate_unit)
    window.setProperty("FpsInfoVar",                   fps_info_text)
    window.setProperty("FpsDropVar",                   fps_out_text)
    window.setProperty("AudioBitrateKBVar",            get_AudioBitrateKBVar())
    window.setProperty("AudioLiveBitrateVar",          get_AudioLiveBitrateVar())
    window.setProperty("AudioCodecVar",                get_AudioCodecVar())
    window.setProperty("AudioCodecSpatialVar",         get_AudioCodecSpatialVar())
    window.setProperty("AudioChannelsVar",             get_AudioChannelsVar())
    window.setProperty("AudioChannelsInputVar",        get_AudioChannelsInputVar())
    window.setProperty("AudioSampleRateVar",           get_AudioSampleRateVar())
    window.setProperty("AudioNameVar",                 get_AudioNameVar())
    window.setProperty("SubtitleVar",                  get_SubtitleVar())
    window.setProperty("SubtitleNameInfoVar",          get_SubtitleNameInfoVar())
    window.setProperty("CpuUsageVar",                  get_CpuUsageVar())
    window.setProperty("CpuTopUsageVar",               get_CpuTopUsageVar())
    window.setProperty("VideoQueueLevelVar",           format_queue_level(video_queue))
    window.setProperty("VideoQueueDataLevelVar",       format_queue_level(video_queue_data))
    window.setProperty("AudioQueueLevelVar",           format_queue_level(audio_queue))
    window.setProperty("AudioQueueDataLevelVar",       format_queue_level(audio_queue_data))
    window.getControl(9100).setPercent(                get_CpuTemperatureProgressVar())
    window.getControl(9101).setPercent(                video_queue)
    window.getControl(9102).setPercent(                video_queue_data)
    window.getControl(9103).setPercent(                audio_queue)
    window.getControl(9104).setPercent(                audio_queue_data)
    window.setProperty("CurrentSkin",                  xbmc.getSkinDir())
