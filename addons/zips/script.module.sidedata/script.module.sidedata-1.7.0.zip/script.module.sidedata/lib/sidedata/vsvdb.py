# Dolby Vision VSVDB (EDID Vendor-Specific Video Data Block) decoder. The
# kernel prints the raw block as a "VSVDB: <hex>" line in the Amlogic dv_cap
# sysfs node, starting at the CTA tag/length byte, CTA-861 extended tag 0x01,
# IEEE OUI 00-D0-46 (little-endian on the wire: 46 d0 00).
#
# Offset | Field             | Notes
# -------------------------------------------------------------
#   0    | Tag/length byte   | top 3 bits = 7 (extended tag), low 5 bits =
#        |                   | declared length of everything from offset 1 on
#   1    | Extended tag      | 0x01 (Vendor-Specific Video Data Block)
#   2-4  | OUI               | 46 d0 00 (Dolby Laboratories, little-endian)
#   5+   | Payload (x[0]...) | version dependent, x[0] = byte at offset 5
#
# x[0] = byte at offset 5. version = (x[0] >> 5) & 7.
#
# Version 0 (declared length 0x19, x[0..20]):
#   x[0] bit 0        yuv422_12bit
#   x[0] bit 1        sup_2160p60
#   x[0] bit 2        global dimming
#   x[1..12]          12-bit packed R/G/B/W primaries (value / 4096)
#   x[13..15]         12-bit packed min/max PQ codewords
#   x[16]             DM version, major = >>4, minor = &0xf
#
# Version 1 (declared length 0x0B compact or 0x0E full primaries):
#   x[0] bit 0        yuv422_12bit
#   x[0] bit 1        sup_2160p60
#   x[0] bits 2-4     DM version minor selector, major = value + 2
#   x[1] bit 0        global dimming
#   x[1] bits 1-7     max luminance code, nits = 100 + 50*code
#   x[2] bit 0        colorimetry, 1 = P3-D65, 0 = BT.709
#   x[2] bits 1-7     min luminance code, nits = (code/127)^2
#   x[3] bit 0        low latency, compact layout only
#   x[3..9] (full) or x[3..6] (compact) primaries
#
# Version 2 (declared length 0x0B, longer declared lengths decode the same
# first 7 bytes):
#   x[0] bit 0        yuv422_12bit
#   x[0] bit 1        backlight control supported
#   x[0] bits 2-4     DM version minor selector, major = value + 2
#   x[1] bits 0-1     backlight min luminance code, nits = 25 + 25*code
#   x[1] bit 2        global dimming
#   x[1] bits 3-7     min luminance code, pq = 20*code
#   x[2] bits 0-1     interface / LLDV capability bits
#   x[2] bits 3-7     max luminance code, pq = 2055 + 65*code
#   x[3] bit 0, x[4] bit 0  10b/12b 444 support (2-bit combined value)
#   x[3..6]           compact primaries
#
# v0 and v2 min/max nits are the ST 2084 inverse EOTF applied to pq/4095. v1
# uses the direct formulas above, no PQ math. Bit layout and nits formulas
# verified against edid-decode (its cta_dolby_video and pq2nits parsers) and
# the 333-block linuxhw/EDID corpus.

import os

__all__ = ['read_vsvdb_raw', 'parse_vsvdb']

_DV_CAP_PATH = '/sys/class/amhdmitx/amhdmitx0/dv_cap'
_VSVDB_MARKER = 'VSVDB: '

_EXTENDED_TAG_TYPE = 0x07
_VSVDB_EXTENDED_TAG = 0x01
_DOLBY_OUI = (0x46, 0xd0, 0x00)
_HEADER_SIZE = 5

_V0_PAYLOAD_LEN = 21
_V1_COMPACT_PAYLOAD_LEN = 7
_V1_FULL_PAYLOAD_LEN = 10
_V2_PAYLOAD_LEN = 7

_HEX_DIGITS = frozenset('0123456789abcdefABCDEF')


def read_vsvdb_raw():
    path = os.environ.get('SIDEDATA_DV_CAP_PATH', _DV_CAP_PATH)
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            contents = f.read()

        pos = contents.find(_VSVDB_MARKER)
        if pos == -1:
            return ''

        hexstr = contents[pos + len(_VSVDB_MARKER):]
        hexstr = hexstr.split('\n', 1)[0]
        return hexstr.rstrip()
    except Exception:
        return ''


def _hex_to_bytes(hex_str):
    if not hex_str or len(hex_str) % 2 != 0:
        return None

    data = bytearray(len(hex_str) // 2)
    for i in range(0, len(hex_str), 2):
        a, b = hex_str[i], hex_str[i + 1]
        if a not in _HEX_DIGITS or b not in _HEX_DIGITS:
            return None
        data[i // 2] = int(hex_str[i:i + 2], 16)
    return bytes(data)


def _pq2nits(pq):
    m1 = 2610.0 / 16384.0
    m2 = 128.0 * (2523.0 / 4096.0)
    c1 = 3424.0 / 4096.0
    c2 = 32.0 * (2413.0 / 4096.0)
    c3 = 32.0 * (2392.0 / 4096.0)

    e = pq ** (1.0 / m2)
    v = e - c1
    if v < 0:
        v = 0.0
    v = v / (c2 - c3 * e)
    v = v ** (1.0 / m1)
    return v * 10000.0


def _decode_v0(x, info):
    info['yuv422_12bit'] = bool(x[0] & 0x01)
    info['sup_2160p60'] = bool(x[0] & 0x02)
    info['global_dimming'] = bool(x[0] & 0x04)

    info['primaries'] = {
        'rx': ((x[1] >> 4) | (x[2] << 4)) / 4096.0,
        'ry': ((x[1] & 0x0f) | (x[3] << 4)) / 4096.0,
        'gx': ((x[4] >> 4) | (x[5] << 4)) / 4096.0,
        'gy': ((x[4] & 0x0f) | (x[6] << 4)) / 4096.0,
        'bx': ((x[7] >> 4) | (x[8] << 4)) / 4096.0,
        'by': ((x[7] & 0x0f) | (x[9] << 4)) / 4096.0,
        'wx': ((x[10] >> 4) | (x[11] << 4)) / 4096.0,
        'wy': ((x[10] & 0x0f) | (x[12] << 4)) / 4096.0,
    }

    pq_min = (x[14] << 4) | (x[13] >> 4)
    pq_max = (x[15] << 4) | (x[13] & 0x0f)
    info['min_pq_codeword'] = pq_min
    info['max_pq_codeword'] = pq_max
    info['min_nits'] = _pq2nits(pq_min / 4095.0)
    info['max_nits'] = _pq2nits(pq_max / 4095.0)

    info['dm_version_major'] = x[16] >> 4
    info['dm_version_minor'] = x[16] & 0x0f


def _decode_v1(x, payload_len, info):
    info['yuv422_12bit'] = bool(x[0] & 0x01)
    info['sup_2160p60'] = bool(x[0] & 0x02)
    info['dm_version_major'] = ((x[0] >> 2) & 0x07) + 2

    info['global_dimming'] = bool(x[1] & 0x01)
    max_code = x[1] >> 1
    info['max_code_raw'] = max_code
    info['max_nits'] = 100.0 + max_code * 50.0

    info['colorimetry_p3d65'] = bool(x[2] & 0x01)
    min_code = x[2] >> 1
    info['min_code_raw'] = min_code
    lm = min_code / 127.0
    info['min_nits'] = lm * lm

    if payload_len == _V1_COMPACT_PAYLOAD_LEN:
        info['low_latency'] = bool(x[3] & 0x01)

    if payload_len == _V1_FULL_PAYLOAD_LEN:
        info['primaries'] = {
            'rx': x[4] / 256.0, 'ry': x[5] / 256.0,
            'gx': x[6] / 256.0, 'gy': x[7] / 256.0,
            'bx': x[8] / 256.0, 'by': x[9] / 256.0,
        }
        return

    x_min_r, x_step_r = 0.625, (0.74609375 - 0.625) / 31.0
    y_min_r, y_step_r = 0.25, (0.37109375 - 0.25) / 31.0
    x_step_g = 0.49609375 / 127.0
    y_min_g, y_step_g = 0.5, (0.99609375 - 0.5) / 127.0
    x_min_b, x_step_b = 0.125, (0.15234375 - 0.125) / 7.0
    y_min_b, y_step_b = 0.03125, (0.05859375 - 0.03125) / 7.0

    info['primaries'] = {
        'rx': x_min_r + x_step_r * (x[6] >> 3),
        'ry': y_min_r + y_step_r * (((x[6] & 0x07) << 2) | (x[4] & 0x01) | ((x[5] & 0x01) << 1)),
        'gx': x_step_g * (x[4] >> 1),
        'gy': y_min_g + y_step_g * (x[5] >> 1),
        'bx': x_min_b + x_step_b * (x[3] >> 5),
        'by': y_min_b + y_step_b * ((x[3] >> 2) & 0x07),
    }


def _decode_v2(x, info):
    info['yuv422_12bit'] = bool(x[0] & 0x01)
    info['backlight_control'] = bool(x[0] & 0x02)
    info['dm_version_major'] = ((x[0] >> 2) & 0x07) + 2

    backlight_code = x[1] & 0x03
    info['backlight_min_luma_nits'] = 25 + backlight_code * 25
    info['global_dimming'] = bool(x[1] & 0x04)

    min_code = x[1] >> 3
    info['min_code_raw'] = min_code
    pq_min = 20 * min_code
    info['min_pq_codeword'] = pq_min
    info['min_nits'] = _pq2nits(pq_min / 4095.0)

    info['interface_bits'] = x[2] & 0x03

    max_code = x[2] >> 3
    info['max_code_raw'] = max_code
    pq_max = 2055 + 65 * max_code
    info['max_pq_codeword'] = pq_max
    info['max_nits'] = _pq2nits(pq_max / 4095.0)

    info['sup_10b_12b_444'] = ((x[3] & 0x01) << 1) | (x[4] & 0x01)

    info['primaries'] = {
        'rx': 0.625 + (x[5] >> 3) / 256.0,
        'ry': 0.25 + (x[6] >> 3) / 256.0,
        'gx': (x[3] >> 1) / 256.0,
        'gy': 0.5 + (x[4] >> 1) / 256.0,
        'bx': 0.125 + (x[5] & 0x07) / 256.0,
        'by': 0.03125 + (x[6] & 0x07) / 256.0,
    }


def _decode_bytes(data):
    if len(data) < _HEADER_SIZE:
        return None

    if (data[0] >> 5) != _EXTENDED_TAG_TYPE:
        return None

    declared_len = data[0] & 0x1f
    if declared_len < _HEADER_SIZE - 1 or len(data) < declared_len + 1:
        return None

    if data[1] != _VSVDB_EXTENDED_TAG:
        return None

    if tuple(data[2:5]) != _DOLBY_OUI:
        return None

    payload_len = declared_len - (_HEADER_SIZE - 1)
    if payload_len < 1:
        # no version byte to read; no version below accepts a 0-length payload
        return None

    x = data[_HEADER_SIZE:]
    version = (x[0] >> 5) & 0x07
    info = {'version': version}

    if version == 0:
        if payload_len != _V0_PAYLOAD_LEN:
            return None
        _decode_v0(x, info)
    elif version == 1:
        if payload_len not in (_V1_COMPACT_PAYLOAD_LEN, _V1_FULL_PAYLOAD_LEN):
            return None
        _decode_v1(x, payload_len, info)
    elif version == 2:
        if payload_len < _V2_PAYLOAD_LEN:
            return None
        _decode_v2(x, info)
    else:
        return None

    return info


def parse_vsvdb(hex_str):
    try:
        data = _hex_to_bytes(hex_str)
        if data is None:
            return None
        return _decode_bytes(data)
    except Exception:
        return None
