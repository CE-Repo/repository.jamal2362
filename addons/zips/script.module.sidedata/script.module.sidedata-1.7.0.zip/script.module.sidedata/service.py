"""service.py, the sidedata addon's Kodi service: publishes parse_sidedata's
output as Home window properties so skins and other non-python consumers can
read the same fields the python module exposes. See README.md's "From a skin"
section for the naming rules this mirrors from FIELDS.md.

It also publishes the display's Dolby Vision VSVDB block, decoded by
sidedata.parse_vsvdb, under the vsvdb.* prefix rather than sidedata.*: it
describes the sink, not the playing frame, and it is refreshed on its own
slower cadence independent of playback.

The flattening functions (flatten_sidedata, flatten_vsvdb and their helpers)
take a plain dict and return a plain {property_name: string_value} dict; they
touch no xbmc API and are unit-tested directly against representative dicts.
The run loop below is the only part that talks to xbmc/xbmcgui.
"""

import math
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lib'))

import sidedata  # noqa: E402

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402

_WINDOW_ID = 10000
_INFO_LABEL = 'Player.Process(video.sidedata)'
# 100ms so property updates track scene cuts; the unchanged-json skip below
# keeps idle ticks cheap
_POLL_INTERVAL = 0.1


def _format_float(value):
    if not math.isfinite(value):
        return None
    text = repr(value)
    if 'e' in text or 'E' in text:
        text = format(value, '.10f')
    if '.' in text:
        text = text.rstrip('0').rstrip('.')
    if text in ('', '-', '-0'):
        text = '0'
    return text


def _format_scalar(value):
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, float):
        return _format_float(value)
    if isinstance(value, int):
        return str(value)
    if isinstance(value, str):
        return value
    return None


def _flatten_dict(prefix, value, out):
    for key, val in value.items():
        _flatten_value(prefix + '.' + key, val, out)


def _flatten_value(prop, value, out):
    if value is None:
        return
    if isinstance(value, dict):
        _flatten_dict(prop, value, out)
        return
    if isinstance(value, tuple):
        if len(value) == 2:
            _flatten_value(prop + '.x', value[0], out)
            _flatten_value(prop + '.y', value[1], out)
        return
    if isinstance(value, list):
        if not value:
            return
        formatted = [_format_scalar(v) for v in value]
        if all(f is not None for f in formatted):
            out[prop] = ' '.join(formatted)
        return
    formatted = _format_scalar(value)
    if formatted is not None:
        out[prop] = formatted


# target nits snapping (convert.py) and duplicate target_display_index
# blocks both let two entries land on the same key; later ones get a -N
# ordinal suffix instead of silently overwriting the first entry's fields
def _ordinal_key(base, counts):
    counts[base] = counts.get(base, 0) + 1
    ordinal = counts[base]
    if ordinal == 1:
        return str(base)
    return '%s-%d' % (base, ordinal)


def _flatten_trim_list(prefix, entries, index_prop, out):
    if not entries:
        return
    out[prefix + '.count'] = str(len(entries))
    tokens = []
    counts = {}
    for entry in entries:
        nits = entry.get('nits')
        if nits is None:
            continue
        key = _ordinal_key(nits, counts)
        tokens.append(key)
        _flatten_dict(prefix + '.' + key, entry, out)
    if tokens:
        out[index_prop] = ' '.join(tokens)
    _flatten_dict(prefix + '.first', entries[0], out)
    _flatten_dict(prefix + '.last', entries[-1], out)


def _flatten_l10(prefix, entries, index_prop, out):
    if not entries:
        return
    out[prefix + '.count'] = str(len(entries))
    tokens = []
    counts = {}
    for entry in entries:
        index = entry.get('target_display_index')
        if index is None:
            continue
        key = _ordinal_key(index, counts)
        tokens.append(key)
        _flatten_dict(prefix + '.' + key, entry, out)
    if tokens:
        out[index_prop] = ' '.join(tokens)


def _flatten_distribution(prefix, entries, out):
    if not entries:
        return
    out[prefix + '.count'] = str(len(entries))
    tokens = []
    counts = {}
    for entry in entries:
        percentage = entry.get('percentage')
        if percentage is None:
            continue
        key = _ordinal_key(percentage, counts)
        tokens.append(key)
        _flatten_value(prefix + '.' + key, entry.get('nits'), out)
    if tokens:
        out[prefix + '.percentages'] = ' '.join(tokens)


def _flatten_rpu(prefix, rpu, out):
    if rpu is None:
        return
    for key, value in rpu.items():
        if key == 'l2':
            _flatten_trim_list(prefix + '.l2', value, prefix + '.l2.nits', out)
        elif key == 'l8':
            _flatten_trim_list(prefix + '.l8', value, prefix + '.l8.nits', out)
        elif key == 'l10':
            _flatten_l10(prefix + '.l10', value, prefix + '.l10.indexes', out)
        else:
            _flatten_value(prefix + '.' + key, value, out)


def _flatten_hdr10plus(prefix, hdr10plus, out):
    if hdr10plus is None:
        return
    for key, value in hdr10plus.items():
        if key == 'distribution':
            _flatten_distribution(prefix + '.distribution', value, out)
        else:
            _flatten_value(prefix + '.' + key, value, out)


def _is_present(value):
    if value is None:
        return False
    if isinstance(value, (list, dict)):
        return bool(value)
    return True


def _flatten_presence(parsed, out):
    config = parsed.get('config')
    rpu = parsed.get('rpu')
    hdr10plus = parsed.get('hdr10plus')
    mdcv = parsed.get('mdcv')
    cll = parsed.get('cll')

    sections = (parsed.get('flags'), parsed.get('structure'), config, rpu, hdr10plus, mdcv, cll)
    if any(_is_present(section) for section in sections):
        out['sidedata.present'] = 'true'
    if _is_present(config) or _is_present(rpu):
        out['sidedata.dovi.present'] = 'true'
    if _is_present(hdr10plus):
        out['sidedata.hdr10plus.present'] = 'true'
    if _is_present(mdcv):
        out['sidedata.mdcv.present'] = 'true'
    if _is_present(cll):
        out['sidedata.cll.present'] = 'true'


def flatten_sidedata(parsed):
    out = {}
    if not isinstance(parsed, dict):
        return out
    _flatten_value('sidedata.flags', parsed.get('flags'), out)
    _flatten_value('sidedata.structure', parsed.get('structure'), out)
    _flatten_value('sidedata.config', parsed.get('config'), out)
    _flatten_rpu('sidedata.rpu', parsed.get('rpu'), out)
    _flatten_hdr10plus('sidedata.hdr10plus', parsed.get('hdr10plus'), out)
    _flatten_value('sidedata.mdcv', parsed.get('mdcv'), out)
    _flatten_value('sidedata.cll', parsed.get('cll'), out)
    _flatten_presence(parsed, out)
    return out


# vsvdb is display/sink data, not per-frame sidedata, so it publishes under
# its own prefix rather than sidedata.* (see FIELDS.md's vsvdb section)
def flatten_vsvdb(parsed):
    out = {}
    if not isinstance(parsed, dict):
        return out
    _flatten_dict('vsvdb', parsed, out)
    out['vsvdb.present'] = 'true'
    return out


def _clear_keys(window, published, keys):
    # published must track exactly what's really on the window at every
    # step, not just at the end, so a setProperty/clearProperty raising
    # partway through never orphans a key that _clear later forgets about
    for key in keys:
        try:
            window.clearProperty(key)
        except Exception:
            continue
        published.pop(key, None)


def _publish(window, published, flat):
    for key, value in flat.items():
        if published.get(key) != value:
            window.setProperty(key, value)
            published[key] = value
    _clear_keys(window, published, [key for key in published if key not in flat])


def _clear(window, published):
    _clear_keys(window, published, list(published))


def _read_label(player):
    if not player.isPlayingVideo():
        return ''
    return xbmc.getInfoLabel(_INFO_LABEL)


def _tick(player, window, state):
    try:
        label = _read_label(player)
        if label == state['label']:
            return
        state['label'] = label

        if not label:
            if state['published']:
                _clear(window, state['published'])
            return

        flat = flatten_sidedata(sidedata.parse_sidedata(label, include_mapping=False))
        _publish(window, state['published'], flat)
    except Exception:
        try:
            _clear(window, state['published'])
        except Exception:
            pass
        state['label'] = None
        raise


# a per-tick sysfs read is wasteful for something that only changes on
# hotplug; every ~100th tick (~10s at _POLL_INTERVAL) is due, plus tick 0 so
# properties exist promptly after service start
_VSVDB_TICK_TICKS = 100


def _vsvdb_tick_due(tick_count):
    return tick_count % _VSVDB_TICK_TICKS == 0


def _vsvdb_tick(window, state, read_raw=None, parse=None):
    if read_raw is None:
        read_raw = sidedata.read_vsvdb_raw
    if parse is None:
        parse = sidedata.parse_vsvdb
    try:
        raw = read_raw()
        if raw == state['vsvdb_raw']:
            return
        state['vsvdb_raw'] = raw

        if not raw:
            if state['vsvdb_published']:
                _clear(window, state['vsvdb_published'])
            return

        flat = flatten_vsvdb(parse(raw))
        _publish(window, state['vsvdb_published'], flat)
    except Exception:
        try:
            _clear(window, state['vsvdb_published'])
        except Exception:
            pass
        state['vsvdb_raw'] = None
        raise


def run():
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    window = xbmcgui.Window(_WINDOW_ID)
    state = {'label': None, 'published': {}, 'vsvdb_raw': None, 'vsvdb_published': {}}
    # only warn on the first tick of a failing run, not every 100ms of it;
    # tracked per tick type so one kind failing doesn't mute the other
    tick_failed = False
    vsvdb_tick_failed = False
    tick_count = 0

    while not monitor.abortRequested():
        try:
            _tick(player, window, state)
        except Exception:
            if not tick_failed:
                xbmc.log('script.module.sidedata: service tick failed, clearing properties',
                         xbmc.LOGWARNING)
            tick_failed = True
        else:
            tick_failed = False

        if _vsvdb_tick_due(tick_count):
            try:
                _vsvdb_tick(window, state)
            except Exception:
                if not vsvdb_tick_failed:
                    xbmc.log('script.module.sidedata: vsvdb tick failed, clearing properties',
                             xbmc.LOGWARNING)
                vsvdb_tick_failed = True
            else:
                vsvdb_tick_failed = False
        tick_count += 1

        if monitor.waitForAbort(_POLL_INTERVAL):
            break

    # best-effort so a service stopped independently of Kodi doesn't leave
    # frozen properties behind
    _clear(window, state['published'])
    _clear(window, state['vsvdb_published'])


if __name__ == '__main__':
    run()
