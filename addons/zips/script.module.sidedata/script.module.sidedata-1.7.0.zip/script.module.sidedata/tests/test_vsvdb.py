import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'lib'))

from sidedata import vsvdb  # noqa: E402

# Golden fixtures are the 333-block linuxhw/EDID VSVDB corpus plus matching
# golden JSON from the reference C++ decoder; they live on disk outside this public
# repo (see .github/UPDATING.md). SIDEDATA_FIXTURES_DIR overrides the
# default location.
_FIXTURES_DIR = os.environ.get(
    'SIDEDATA_FIXTURES_DIR',
    os.path.expanduser('~/ce/dvhdr-testdata/module-fixtures'),
)
_BLOCKS_TSV = os.path.join(_FIXTURES_DIR, 'vsvdb-blocks.tsv')
_GOLDEN_JSONL = os.path.join(_FIXTURES_DIR, 'vsvdb-golden.jsonl')
_GOLDEN_AVAILABLE = os.path.isfile(_BLOCKS_TSV) and os.path.isfile(_GOLDEN_JSONL)
_GOLDEN_SKIP_REASON = (
    'no vsvdb golden fixtures found - place vsvdb-blocks.tsv and '
    'vsvdb-golden.jsonl at ' + _FIXTURES_DIR +
    ' or point SIDEDATA_FIXTURES_DIR at them; see .github/UPDATING.md'
)

# snake_case rename of the golden JSON's camelCase keys
_KEY_MAP = {
    'version': 'version',
    'dmVersionMajor': 'dm_version_major',
    'dmVersionMinor': 'dm_version_minor',
    'maxCodeRaw': 'max_code_raw',
    'maxPqCodeword': 'max_pq_codeword',
    'maxNits': 'max_nits',
    'minCodeRaw': 'min_code_raw',
    'minPqCodeword': 'min_pq_codeword',
    'minNits': 'min_nits',
    'interfaceBits': 'interface_bits',
    'globalDimming': 'global_dimming',
    'colorimetryP3D65': 'colorimetry_p3d65',
    'lowLatency': 'low_latency',
    'sup2160p60': 'sup_2160p60',
    'yuv42212Bit': 'yuv422_12bit',
    'sup10b12b444': 'sup_10b_12b_444',
    'backlightControl': 'backlight_control',
    'backlightMinLumaNits': 'backlight_min_luma_nits',
}


def _remap_golden(entry):
    remapped = {}
    for key, value in entry.items():
        if key == 'primaries':
            remapped['primaries'] = dict(value)
            continue
        remapped[_KEY_MAP[key]] = value
    return remapped


class TestParseVsvdbRealVectors(unittest.TestCase):
    def test_real_v1_vector(self):
        info = vsvdb.parse_vsvdb('eb0146d0002618039182697c')
        self.assertIsNotNone(info)
        self.assertEqual(info['version'], 1)
        self.assertAlmostEqual(info['max_nits'], 700.0, delta=0.1)
        self.assertAlmostEqual(info['min_nits'], 0.000062, delta=0.000001)

    def test_real_v2_vectors(self):
        vectors = (
            ('eb0146d000480376825e6d95', 774.9),
            ('eb0146d0004403609248458f', 578.3),
            ('eb0146d0004d4e4a725a7776', 371.6),
            ('eb0146d000480a7e86607694', 896.5),
            ('eb0146d00048039e5898aa5c', 1604.7),
        )
        for hex_str, expected_nits in vectors:
            info = vsvdb.parse_vsvdb(hex_str)
            self.assertIsNotNone(info)
            self.assertEqual(info['version'], 2)
            self.assertAlmostEqual(info['max_nits'], expected_nits, delta=0.1)

    def _v0_vector(self, pq_min, pq_max):
        v = bytearray(26)
        v[0] = 0xf9
        v[1] = 0x01
        v[2] = 0x46
        v[3] = 0xd0
        v[4] = 0x00
        v[18] = ((pq_min & 0x0f) << 4) | (pq_max & 0x0f)
        v[19] = pq_min >> 4
        v[20] = pq_max >> 4
        return bytes(v).hex()

    def test_synthetic_v0_low_anchors(self):
        info = vsvdb.parse_vsvdb(self._v0_vector(2081, 3079))
        self.assertIsNotNone(info)
        self.assertEqual(info['version'], 0)
        self.assertAlmostEqual(info['min_nits'], 100.0, delta=1.0)
        self.assertAlmostEqual(info['max_nits'], 1000.0, delta=5.0)

    def test_synthetic_v0_high_anchors(self):
        info = vsvdb.parse_vsvdb(self._v0_vector(3696, 4095))
        self.assertIsNotNone(info)
        self.assertEqual(info['version'], 0)
        self.assertAlmostEqual(info['min_nits'], 4000.0, delta=20.0)
        self.assertAlmostEqual(info['max_nits'], 10000.0, delta=0.1)

    def test_v1_full_has_no_low_latency(self):
        info = vsvdb.parse_vsvdb('ee0146d00020000001404040404040')
        self.assertIsNotNone(info)
        self.assertEqual(info['version'], 1)
        self.assertNotIn('low_latency', info)

    def test_hex_decode_stable(self):
        hex_str = 'eb0146d0002618039182697c'
        first = vsvdb.parse_vsvdb(hex_str)
        second = vsvdb.parse_vsvdb(hex_str)
        self.assertEqual(first, second)


class TestParseVsvdbCorpusVectors(unittest.TestCase):
    # hand-derived from ~/ce22-docs/vsvdb-corpus-blocks.tsv against the
    # documented byte layout, real blocks from the linuxhw/EDID corpus

    def test_v0_vizio(self):
        info = vsvdb.parse_vsvdb('f90146d0000034ad4ee641a80b270c145054cc07b52800000000')
        self.assertIsNotNone(info)
        self.assertEqual(info['version'], 0)
        self.assertEqual(info['min_pq_codeword'], 124)
        self.assertEqual(info['max_pq_codeword'], 2908)
        self.assertAlmostEqual(info['min_nits'], 0.020154205325833903, places=6)
        self.assertAlmostEqual(info['max_nits'], 681.6906715703623, places=6)
        self.assertEqual(info['dm_version_major'], 2)
        self.assertEqual(info['dm_version_minor'], 8)
        self.assertFalse(info['global_dimming'])
        self.assertFalse(info['sup_2160p60'])
        self.assertFalse(info['yuv422_12bit'])
        self.assertAlmostEqual(info['primaries']['wx'], 0.312744140625, places=9)
        self.assertAlmostEqual(info['primaries']['wy'], 0.3291015625, places=9)

    def test_v1_compact(self):
        info = vsvdb.parse_vsvdb('eb0146d00022082b515999aa')
        self.assertIsNotNone(info)
        self.assertEqual(info['version'], 1)
        self.assertEqual(info['max_code_raw'], 4)
        self.assertAlmostEqual(info['max_nits'], 300.0, places=6)
        self.assertEqual(info['min_code_raw'], 21)
        self.assertAlmostEqual(info['min_nits'], 0.02734205468410937, places=6)
        self.assertTrue(info['colorimetry_p3d65'])
        self.assertTrue(info['low_latency'])
        self.assertTrue(info['sup_2160p60'])

    def test_v1_full(self):
        info = vsvdb.parse_vsvdb('ee0146d000200fa300a6554e9d270c')
        self.assertIsNotNone(info)
        self.assertEqual(info['version'], 1)
        self.assertEqual(info['max_code_raw'], 7)
        self.assertAlmostEqual(info['max_nits'], 450.0, places=6)
        self.assertEqual(info['min_code_raw'], 81)
        self.assertAlmostEqual(info['min_nits'], 0.4067828135656271, places=6)
        self.assertTrue(info['global_dimming'])
        self.assertNotIn('low_latency', info)
        self.assertAlmostEqual(info['primaries']['rx'], 0.6484375, places=9)

    def test_v2(self):
        info = vsvdb.parse_vsvdb('eb0146d00044035094444c8f')
        self.assertIsNotNone(info)
        self.assertEqual(info['version'], 2)
        self.assertEqual(info['backlight_min_luma_nits'], 100)
        self.assertEqual(info['interface_bits'], 0)
        self.assertEqual(info['max_pq_codeword'], 2705)
        self.assertAlmostEqual(info['max_nits'], 430.8741061215729, places=6)
        self.assertAlmostEqual(info['min_nits'], 0.0, places=6)
        self.assertEqual(info['sup_10b_12b_444'], 0)

    # the LG C4, device-verified in ~/ce22-docs/dv-vsvdb-plan.md: "VSVDB v2
    # peak 1037.1 nits, min 0.000000 nits, LLDV 3", PQ 3095, backlight min 75
    def test_lg_c4_real_block(self):
        info = vsvdb.parse_vsvdb('eb0146d000480287835c6d8e')
        self.assertIsNotNone(info)
        self.assertEqual(info['version'], 2)
        self.assertEqual(info['dm_version_major'], 4)
        self.assertEqual(info['max_pq_codeword'], 3095)
        self.assertAlmostEqual(info['max_nits'], 1037.11, delta=0.01)
        self.assertAlmostEqual(info['min_nits'], 0.0, places=6)
        self.assertEqual(info['backlight_min_luma_nits'], 75)
        self.assertEqual(info['interface_bits'], 3)
        self.assertEqual(info['sup_10b_12b_444'], 2)


class TestParseVsvdbMalformed(unittest.TestCase):
    # reject cases, each mutated from the same real V1 vector used above
    _BASE = 'eb0146d0002618039182697c'

    def test_rejects_empty(self):
        self.assertIsNone(vsvdb.parse_vsvdb(''))

    def test_rejects_none(self):
        self.assertIsNone(vsvdb.parse_vsvdb(None))

    def test_rejects_truncated_block(self):
        self.assertIsNone(vsvdb.parse_vsvdb('eb0146d0002618'))

    def test_rejects_wrong_oui(self):
        self.assertIsNone(vsvdb.parse_vsvdb('eb0147d0002618039182697c'))

    def test_rejects_wrong_extended_tag(self):
        self.assertIsNone(vsvdb.parse_vsvdb('eb0246d0002618039182697c'))

    def test_rejects_undefined_version(self):
        self.assertIsNone(vsvdb.parse_vsvdb('eb0146d000a618039182697c'))

    def test_rejects_wrong_tag_type(self):
        self.assertIsNone(vsvdb.parse_vsvdb('0b0146d0002618039182697c'))

    def test_rejects_v0_length_mismatch(self):
        # declared length 0x14, not the v0 0x19
        self.assertIsNone(vsvdb.parse_vsvdb('f40146d000000000000000000000000000000000000000000000'))

    def test_rejects_v1_length_mismatch(self):
        # declared length 0x09, matches neither v1 compact nor full
        self.assertIsNone(vsvdb.parse_vsvdb('e90146d0002618039182697c'))

    def test_rejects_v2_length_mismatch(self):
        # declared length 0x05, shorter than the v2 payload
        self.assertIsNone(vsvdb.parse_vsvdb('e50146d000480376825e6d95'))

    def test_accepts_v2_longer_declared_length(self):
        short_info = vsvdb.parse_vsvdb('eb0146d000480376825e6d95')
        long_info = vsvdb.parse_vsvdb('ec0146d000480376825e6d95ff')

        self.assertIsNotNone(short_info)
        self.assertIsNotNone(long_info)
        self.assertEqual(long_info['version'], short_info['version'])
        self.assertAlmostEqual(long_info['max_nits'], short_info['max_nits'], places=9)
        self.assertAlmostEqual(long_info['min_nits'], short_info['min_nits'], places=9)

    def test_rejects_hex_odd_length(self):
        self.assertIsNone(vsvdb.parse_vsvdb('eb0146d000261803918269'))

    def test_rejects_hex_non_hex_chars(self):
        self.assertIsNone(vsvdb.parse_vsvdb('zz0146d0002618039182697c'))

    def test_rejects_hex_empty(self):
        self.assertIsNone(vsvdb.parse_vsvdb(''))

    def test_rejects_zero_length_payload(self):
        # declared length 0x04: header only, no version byte to read
        self.assertIsNone(vsvdb.parse_vsvdb('e40146d000'))


class TestVsvdbJsonKeyPresence(unittest.TestCase):
    def test_v1_compact_has_version_appropriate_keys(self):
        info = vsvdb.parse_vsvdb('eb0146d0002618039182697c')
        self.assertIsNotNone(info)
        for key in ('version', 'max_nits', 'min_nits', 'global_dimming', 'yuv422_12bit',
                    'dm_version_major', 'max_code_raw', 'min_code_raw', 'colorimetry_p3d65',
                    'low_latency', 'sup_2160p60'):
            self.assertIn(key, info)
        for key in ('dm_version_minor', 'max_pq_codeword', 'min_pq_codeword', 'interface_bits',
                    'sup_10b_12b_444', 'backlight_control', 'backlight_min_luma_nits'):
            self.assertNotIn(key, info)

    def test_v2_has_version_appropriate_keys(self):
        info = vsvdb.parse_vsvdb('eb0146d000480376825e6d95')
        self.assertIsNotNone(info)
        for key in ('version', 'max_nits', 'min_nits', 'global_dimming', 'yuv422_12bit',
                    'dm_version_major', 'max_code_raw', 'max_pq_codeword', 'min_code_raw',
                    'min_pq_codeword', 'interface_bits', 'sup_10b_12b_444', 'backlight_control',
                    'backlight_min_luma_nits'):
            self.assertIn(key, info)
        for key in ('dm_version_minor', 'colorimetry_p3d65', 'low_latency', 'sup_2160p60'):
            self.assertNotIn(key, info)

    def test_v0_has_version_appropriate_keys(self):
        info = vsvdb.parse_vsvdb('f90146d0000034ad4ee641a80b270c145054cc07b52800000000')
        self.assertIsNotNone(info)
        for key in ('version', 'max_nits', 'min_nits', 'global_dimming', 'yuv422_12bit',
                    'dm_version_major', 'dm_version_minor', 'max_pq_codeword', 'min_pq_codeword',
                    'sup_2160p60'):
            self.assertIn(key, info)
        for key in ('max_code_raw', 'min_code_raw', 'interface_bits', 'colorimetry_p3d65',
                    'low_latency', 'sup_10b_12b_444', 'backlight_control',
                    'backlight_min_luma_nits'):
            self.assertNotIn(key, info)
        self.assertIn('wx', info['primaries'])
        self.assertIn('wy', info['primaries'])

    def test_v1_full_has_no_wx_wy(self):
        info = vsvdb.parse_vsvdb('ee0146d000200fa300a6554e9d270c')
        self.assertIsNotNone(info)
        self.assertNotIn('wx', info['primaries'])
        self.assertNotIn('wy', info['primaries'])


class TestReadVsvdbRaw(unittest.TestCase):
    def setUp(self):
        self._old_override = os.environ.get('SIDEDATA_DV_CAP_PATH')

    def tearDown(self):
        if self._old_override is None:
            os.environ.pop('SIDEDATA_DV_CAP_PATH', None)
        else:
            os.environ['SIDEDATA_DV_CAP_PATH'] = self._old_override

    def _write_dv_cap(self, contents):
        f = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.dv_cap')
        f.write(contents)
        f.close()
        os.environ['SIDEDATA_DV_CAP_PATH'] = f.name
        return f.name

    def test_extracts_hex_after_marker(self):
        path = self._write_dv_cap(
            'DV support: 1\nDV_2160p60hz: 1\nVSVDB: eb0146d0002618039182697c\n')
        try:
            self.assertEqual(vsvdb.read_vsvdb_raw(), 'eb0146d0002618039182697c')
        finally:
            os.unlink(path)

    def test_no_trailing_newline(self):
        path = self._write_dv_cap('VSVDB: eb0146d000260318')
        try:
            self.assertEqual(vsvdb.read_vsvdb_raw(), 'eb0146d000260318')
        finally:
            os.unlink(path)

    def test_trailing_whitespace_stripped(self):
        path = self._write_dv_cap('VSVDB: eb0146d000260318  \r\n')
        try:
            self.assertEqual(vsvdb.read_vsvdb_raw(), 'eb0146d000260318')
        finally:
            os.unlink(path)

    def test_missing_file_returns_empty(self):
        os.environ['SIDEDATA_DV_CAP_PATH'] = '/nonexistent/path/to/dv_cap'
        self.assertEqual(vsvdb.read_vsvdb_raw(), '')

    def test_no_vsvdb_line_returns_empty(self):
        path = self._write_dv_cap('DV support: 1\nDV_2160p60hz: 1\n')
        try:
            self.assertEqual(vsvdb.read_vsvdb_raw(), '')
        finally:
            os.unlink(path)

    def test_empty_file_returns_empty(self):
        path = self._write_dv_cap('')
        try:
            self.assertEqual(vsvdb.read_vsvdb_raw(), '')
        finally:
            os.unlink(path)


@unittest.skipUnless(_GOLDEN_AVAILABLE, _GOLDEN_SKIP_REASON)
class TestGoldenVsvdbDifferential(unittest.TestCase):
    # differential against the reference C++ decoder's JSON for the 333-block
    # linuxhw/EDID corpus (see tools/vsvdb-golden-gen.cpp in the fixtures
    # dir). float comparison uses relative tolerance 1e-6, matching the
    # precision the golden generator prints doubles at (17 significant
    # digits, well past what 1e-6 needs)
    @classmethod
    def setUpClass(cls):
        with open(_BLOCKS_TSV, encoding='utf-8') as f:
            lines = [line.rstrip('\n') for line in f]
        header, rows = lines[0].split('\t'), lines[1:]
        hex_idx = header.index('hex')
        cls.hex_blocks = [row.split('\t')[hex_idx] for row in rows if row]

        with open(_GOLDEN_JSONL, encoding='utf-8') as f:
            cls.golden = [json.loads(line) for line in f if line.strip()]

    def test_counts_match(self):
        self.assertEqual(len(self.hex_blocks), len(self.golden))
        self.assertEqual(len(self.hex_blocks), 333)

    def test_every_block_matches_golden(self):
        mismatches = []
        for i, (hex_str, golden_entry) in enumerate(zip(self.hex_blocks, self.golden)):
            parsed = vsvdb.parse_vsvdb(hex_str)
            expected = _remap_golden(golden_entry)

            if parsed is None:
                mismatches.append('row %d (%s): parse_vsvdb returned None' % (i, hex_str))
                continue

            for key, expected_value in expected.items():
                if key == 'primaries':
                    actual_primaries = parsed.get('primaries')
                    if not isinstance(actual_primaries, dict):
                        mismatches.append('row %d (%s): primaries missing or not a dict, got %r' %
                                           (i, hex_str, actual_primaries))
                        continue

                    expected_pkeys = set(expected_value.keys())
                    actual_pkeys = set(actual_primaries.keys())
                    if expected_pkeys != actual_pkeys:
                        mismatches.append(
                            'row %d (%s): primaries key set expected %s got %s '
                            '(missing %s, extra %s)' %
                            (i, hex_str, sorted(expected_pkeys), sorted(actual_pkeys),
                             sorted(expected_pkeys - actual_pkeys),
                             sorted(actual_pkeys - expected_pkeys)))

                    for pkey in expected_pkeys & actual_pkeys:
                        pvalue = expected_value[pkey]
                        actual = actual_primaries[pkey]
                        if abs(actual - pvalue) > max(1e-6 * abs(pvalue), 1e-9):
                            mismatches.append(
                                'row %d (%s): primaries.%s expected %r got %r' %
                                (i, hex_str, pkey, pvalue, actual))
                    continue

                actual = parsed.get(key)
                if isinstance(expected_value, float):
                    if actual is None or abs(actual - expected_value) > max(
                            1e-6 * abs(expected_value), 1e-9):
                        mismatches.append('row %d (%s): %s expected %r got %r' %
                                           (i, hex_str, key, expected_value, actual))
                elif actual != expected_value:
                    mismatches.append('row %d (%s): %s expected %r got %r' %
                                       (i, hex_str, key, expected_value, actual))

            for key in parsed:
                if key not in expected and key != 'primaries':
                    mismatches.append('row %d (%s): unexpected key %s=%r' %
                                       (i, hex_str, key, parsed[key]))

        self.assertEqual(mismatches, [], '%d mismatches:\n%s' %
                          (len(mismatches), '\n'.join(mismatches[:20])))


if __name__ == '__main__':
    unittest.main()
